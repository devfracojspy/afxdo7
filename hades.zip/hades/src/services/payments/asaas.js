const request = require('request-promise')
const database = require('../../database')

const { bot } = require('../../bot')

const { Transactions, User } = database

const channels = [process.env.GIFTS_LOG_CHANNEL]

exports.createPayment = async ({ user, amount, expiration }) => {
  const response = await request({
    method: 'POST',
    url: 'https://www.asaas.com/api/v3/pix/qrCodes/static',
    body: JSON.stringify({
      addressKey: process.env.ASAAS_KEY,
      description: `Recarga de saldo R$${amount} #${user.id}`,
      value: amount,
      format: 'ALL',
      expirationDate: expiration,
      expirationSeconds: null,
    }),
    headers: {
      'Content-Type': 'application/json',
      access_token: process.env.ASAAS_TOKEN,
    },
  })

  const tarnsaction = new Transactions({
    type: 'pix',
    provider: 'asaas',
    data: {
      paid: false,
      ...JSON.parse(response),
    },
    payer: user._id,
  })

  console.log(JSON.parse(response))

  await tarnsaction.save()

  return JSON.parse(response)
}

exports.verifyPayment = async (payment) => {
  const paymentId = payment.pixQrCodeId

  const localPayment = await Transactions.findOne({
    'data.id': paymentId,
  }).populate('payer')

  const payer = localPayment?.payer

  if (!localPayment || localPayment.paid) return

  const { user: userDb } = new DataBaseFunctions(database, {
    from: {
      id: localPayment.payer.id,
      first_name: localPayment.payer.name,
    },
  })

  const referral = async () => {
    const { success, response } = await userDb().creditarComissao(
      parseFloat(amount)
    )

    if (success) {
      await bot.sendMessage(
        response.affiliated_id,
        response.affiliated_feedback_message,
        { parse_mode: 'HTML' }
      )
      channels.forEach(
        async (channel) =>
          await bot.sendMessage(
            channel,
            `👥 <b>O usuario ${response.affiliated_name} ganhou R$${response.comission} de comissão\n\nAfiliado: ${localPayment.payer.name}\nValor Total: ${payment.value}</b>`,
            { parse_mode: 'HTML' }
          )
      )
    }
  }

  await Transactions.updateOne(
    {
      _id: localPayment._id,
    },
    {
      data: { paid: true, ...payment },
    }
  )

  await User.updateOne(
    {
      _id: payer._id,
    },
    {
      $inc: {
        credits: payment.value,
        current_transactions: -1,
      },
    }
  )

  await referral()

  await bot.sendMessage(
    payer.id,
    `✅ <b>Pagamento recebido.</>\n` +
      `<b>Valor:</> <code>R$${payment.value}</>\n\n` +
      `<b>Sua recarga foi creditada em sua conta.</>`,
    {
      parse_mode: 'HTML',
    }
  )

  const notifyRecharge = (channel) =>
    bot
      .sendMessage(
        channel,
        `✅ <b>Recarga realizada!</b>\n\n` +
          `<b>Usuário</b>: <code>${payer.name}</code>\n` +
          `<b>Id:</b> <code>${payer.id}</code>\n` +
          `<b>Valor:</b> <code>R$${payment.value}</>\n` +
          `<b>Provedor:</> <code>asaas</>`,
        { parse_mode: 'HTML' }
      )
      .catch(Function())

  channels.forEach(notifyRecharge)
}
