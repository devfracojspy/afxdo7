const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function generic(card, currentRetry = 0) {
  const { retrys, generic: configs } = getConfig('checkers')

  console.log(configs)

  try {
    const options = {
      url: `${configs.baseUrl}=${card.number}|${card.month}|${card.year}|${card.cvv}`,
      method: 'GET',
      followAllRedirects: true,
      strictSSL: false,
      timeout: 100000,
    }

    if (currentRetry >= retrys)
      return {
        active: true,
        skip: true,
        output: 'Error on call api',
      }

    const result = await request(options)
    const response = JSON.stringify(result)

    console.log(response)

    if (response.includes(configs.liveMatch)) {
      return {
        active: true,
        card: card,
        live: true,
        output: result,
      }
    } else if (response.includes(configs.dieMatch)) {
      return {
        active: true,
        card: card,
        live: false,
        output: result,
      }
    } else {
      currentRetry++
      return generic(card, currentRetry)
    }
  } catch (e) {
    console.log(e)

    currentRetry++
    return generic(card, currentRetry)
  }
}
