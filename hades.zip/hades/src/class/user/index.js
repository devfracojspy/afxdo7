class User {
  constructor(db, message = {}) {
    this.User = db.User
    this.Gift = db.Gift
    this.Cards = db.Cards
    this.message = message
    this.Store = db.Store
    this.Transaction = db.Transactions
    this.ownerId = process.env.ROOT_USERS.split(' ').map((user) =>
      Number(user.trim())
    )
  }

  async verificarEadicionar(settings) {
    try {
      const { id: userId, first_name: name = '' } = this.message.from
      const { success: isAdmin } = await this.admin()
      let exists = await this.User.exists({ id: userId })
      let Store = await this.Store.findOne({
        name: process.env.STORE_NAME,
      })
      let returned

      if (exists) {
        const user = await this.User.findOne({ id: userId })
        if (this?.message.from?.first_name) {
          user.name = this.message.from?.first_name
          await user.save()
        }

        if (user.restrict)
          returned = { success: false, message: 'Conta restrita.' }
        else
          returned = {
            success: true,
            message: 'Usuário já existente',
          }

        if (user.in_purchase)
          returned = {
            success: false,
            message: 'Espere o termino da compra anterior.',
          }
      } else {
        let [, affiliateId = 0] =
          this.message.text.split(' ').length > 1
            ? this.message.text.split(' ')
            : [0, 0]

        if (!/[0-9]+$/.test(affiliateId)) {
          affiliateId = 0
        }

        const affiliate = await this.User.findOne({
          id: affiliateId,
        })

        var newUser = new this.User()
        newUser.id = userId
        newUser.name = name
        newUser.historic = []
        newUser.credits = 0
        newUser.current_transactions = 0
        newUser.restrict = false
        newUser.admin = false
        newUser.shopping.credits = 0
        newUser.shopping.cards = 0
        newUser.shopping.gifts = 0
        newUser.in_purchase = false

        if (affiliate) {
          newUser.affiliated = affiliate._id
        } else {
          newUser.affiliated = newUser._id
        }

        await newUser.save()

        returned = {
          success: true,
          message: 'Usuário criado com sucesso',
        }
      }

      if (Store.test_mode && !isAdmin)
        return { success: false, message: 'Store em manutenção' }

      return returned
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  get admins() {
    return this.ownerId
  }

  async atualizar(config) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      await this.User.findOneAndUpdate({ id: userInfo.id }, config)
      return {
        success: true,
        message: `Usuario atualizado`,
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async informacoes() {
    try {
      const { id: userId } = this.message.from

      const userInfo = await this.User.findOne({ id: userId })

      return { success: true, response: userInfo }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async verificarEdeduzirSaldo(value, quantity = 1) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      if (userInfo.credits < value) {
        return { success: false, message: 'Saldo insuficiente' }
      } else {
        await this.User.findOneAndUpdate(
          { id: userInfo.id },
          { $inc: { credits: -value, 'shopping.cards': quantity } },
          { new: true }
        )
        return {
          success: true,
          message: `${value}, foram creditados de ${userInfo.name}`,
        }
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async deletarConta() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      const deleteUser = await this.User.deleteOne({
        id: userInfo.id,
      })

      return {
        success: true,
        message: 'Usuario deletado com sucesso',
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async restringirUsuario() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      await this.User.findOneAndUpdate(
        { id: userInfo.id },
        { restrict: true },
        { new: true }
      )

      return {
        success: true,
        message: 'Usuario restringido com sucesso',
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async reativarConta() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      await this.User.findOneAndUpdate(
        { id: userInfo.id },
        { restrict: false },
        { new: true }
      )

      return {
        success: true,
        message: 'Restrição removida com sucesso',
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async promoverUsuario() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      await this.User.findOneAndUpdate(
        { id: userInfo.id },
        { admin: true },
        { new: true }
      )

      return {
        success: true,
        message: 'Usuario promovido com sucesso',
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async despromoverUsuario() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      await this.User.findOneAndUpdate(
        { id: userInfo.id },
        { admin: false },
        { new: true }
      )

      return {
        success: true,
        message: 'Usuário despromovido com sucesso',
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async resgatarGift(gift) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      const Gift = await this.Gift.findOne({ code: gift })

      const redeemed = await this.Gift.findOneAndUpdate(
        { code: gift },
        { redeem: true, $inc: { redeemed: 1 } },
        { new: true }
      )

      if (redeemed.redeemed > 1)
        return {
          success: false,
          message:
            '<b>Gift já resgatado. (Tentativa de burlamento detectada)</b>',
        }

      await this.User.findOneAndUpdate(
        { id: userInfo.id },
        {
          $inc: {
            credits: Gift.value,
            'shopping.credits': Gift.value,
            'shopping.gifts': 1,
          },
        },
        { new: true }
      )

      return {
        success: true,
        gift: {
          value: Gift.value,
          code: gift,
        },
        user: userInfo,
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async adicionarSaldo(value) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      await this.User.findOneAndUpdate(
        { id: userInfo.id },
        { $inc: { credits: value, 'shopping.credits': value } },
        { new: true }
      )

      return {
        success: true,
        credits: {
          value: value,
          message: 'Creditos adicionados.',
        },
        user: userInfo,
      }
    } catch (e) {
      return { success: false, message: e.message }
    }
  }

  async admin(id = null) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      if (
        this.ownerId.includes(id ?? userInfo.id) ||
        userInfo.admin
      ) {
        return { success: true, message: 'Acesso autorizado.' }
      } else {
        return { success: false, message: '<b>Acesso negado.</b>' }
      }
    } catch (e) {
      return {
        success: false,
        message: '<b>Ocorreu um erro ao executar este comando.</b>',
      }
    }
  }

  async cartoesComprados() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      const cards = await this.Cards.find({
        purshased: userInfo.id,
      }).populate('level')

      return { success: false, response: cards }
    } catch (e) {
      console.log(e.message)
      return {
        success: false,
        response: '<b>Ocorreu um erro ao executar este comando.</b>',
      }
    }
  }

  async baixarHistorico() {
    try {
      var { response: userInfo, success } = await this.informacoes()

      var { response: cards } = await this.cartoesComprados()

      const fs = require('fs')

      var cardsString = cards
        .map((card) => {
          return `${card.number}|${card.month}|${card.year}|${
            card.cvv
          }|${
            card.bin.bank ? card.bin.bank.name : 'Não especificado'
          }|${card.bin.type ? card.bin.type : 'Não especificado'}|${
            card.bin.brand ? card.bin.brand : 'Não especificado'
          }|${card.name ? card.name : 'Não registrado'}|${
            card.cpf ? card.cpf : 'Não registrado'
          }|${new Date(card.updatedAt).toString()}`
        })
        .join('\n')

      var userHistoric = `Histórico de transações.\n\nCartões: ${
        userInfo.shopping.cards
      }\n\nSaldo: R$${userInfo.shopping.credits}\n\nGifts: ${
        userInfo.shopping.gifts
      }\n\nTodos os cartões comprados:\n\n${
        cardsString.length < 1 ? 'Nada consta' : cardsString
      }`

      fs.writeFileSync(
        `${__dirname}/users/${userInfo.id}.txt`,
        userHistoric,
        { flag: 'w' }
      )
      const confirm = fs.readFileSync(
        `${__dirname}/users/${userInfo.id}.txt`,
        'utf-8'
      )

      //console.log('confirmed: ', confirm)

      return { success: true, response: userHistoric }
    } catch (e) {
      console.log(e.message)
      return {
        success: false,
        message: '<b>Ocorreu um erro ao executar este comando.</b>',
      }
    }
  }

  async usuarios(ignoreAny = true) {
    try {
      var users = await this.User.find({})

      if (ignoreAny) users = users.filter((user) => !user.restrict)

      return { success: true, response: users }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async deduzirTaxa(value) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      if (!success) return { success: false, response: userInfo }

      if (userInfo.credits < value) {
        return { success: false, message: 'Saldo insuficiente' }
      } else {
        await this.User.findOneAndUpdate(
          { id: userInfo.id },
          { $inc: { credits: -value } },
          { new: true }
        )
        return {
          success: true,
          message: `${value}, foram creditados de ${userInfo.name}`,
        }
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async registrarTransacao(paymentData) {
    try {
      var { response: userInfo } = await this.informacoes()

      const transaction = new this.Transaction({
        ...paymentData,
        payer: userInfo._id,
      })

      return transaction.save()
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async alterarTransacao(txid, query) {
    try {
      var { response: userInfo, success } = await this.informacoes()

      const transaction = await this.Transaction.findOneAndUpdate(
        { txid: txid },
        query
      )
      const normalizeCurrentTransactions =
        await this.User.findOneAndUpdate(
          { id: userInfo.id },
          { current_transactions: 0 },
          { new: true }
        )

      return {
        success: true,
        response: transaction,
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async afiliados() {
    try {
      const { response: userInfo } = await this.informacoes()

      if (!userInfo.affiliated) {
        return {
          success: false,
          response:
            'Sua conta foi criada antes da construção do sistema de afiliados, se deseja entrar na promoção, encerre sua conta no bot (Informações > Encerrar Conta) e tente novamente.',
        }
      }

      const { affiliated } = await this.User.findOne({
        id: userInfo.id,
      }).populate('affiliated')

      const { affiliates } = await this.User.findOne({
        id: userInfo.id,
      }).populate({ path: 'affiliates' })

      if (affiliated.id == userInfo.id) {
        return {
          success: true,
          response: {
            affiliated: 'Não afiliado',
            affiliates: affiliates.filter(
              (user) => user.id != userInfo.id
            ),
          },
        }
      } else {
        return {
          success: true,
          response: {
            affiliated: affiliated ? affiliated.name : 'Não afiliado',
            affiliates: affiliates.filter(
              (user) => user.id != userInfo.id
            ),
          },
        }
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async creditarComissao(value) {
    try {
      const percentage = (num, per) => (num / 100) * per

      const { response: userInfo } = await this.informacoes()

      const { affiliated } = await this.User.findOne({
        id: userInfo.id,
      }).populate('affiliated')

      if (affiliated.id == userInfo.id) {
        return {
          success: false,
          response: 'Você não nenhum afiliado',
        }
      } else {
        await this.User.findOneAndUpdate(
          { id: affiliated.id },
          {
            $inc: {
              credits: percentage(
                value,
                parseInt(process.env.REFERRAL_PERCENT)
              ).toFixed(2),
              'shopping.credits': value,
            },
          },
          { new: true }
        )

        return {
          success: true,
          response: {
            message: 'Seu afiliado ganhou uma comissão de 10%',
            affiliated_feedback_message: `🔔 <b>Você recebeu uma comissão de R$${percentage(
              value,
              parseInt(process.env.REFERRAL_PERCENT)
            ).toFixed(
              2
            )} referente a uma recarga do seu afiliado </b><a href='tg://user?id=${
              userInfo.id
            }'>${
              userInfo.name
            }</a>!\n\n<b>Valor total: R$${value}\nPorcentagem: ${parseInt(
              process.env.REFERRAL_PERCENT
            )}%</b>`,
            affiliated_id: affiliated.id,
            affiliated_name: affiliated.name,
            comission: percentage(
              value,
              parseInt(process.env.REFERRAL_PERCENT)
            ).toFixed(2),
          },
        }
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }
}

module.exports = User
