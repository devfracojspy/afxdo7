class DataBase {
    constructor(db, message){
        this.DataBase = db
        this.message = message

        this.User = require('./user')
        this.Card = require('./card')
        this.Level = require('./level')
        this.Gift = require('./gift')
        this.Store = require('./store')
        this.Mix = require('./mix')
    }

    user = () => new this.User(this.DataBase, this.message)
    card = () => new this.Card(this.DataBase, this.message)
    level = () => new this.Level(this.DataBase, this.message)
    gift = () => new this.Gift(this.DataBase.Gift)
    store = () => new this.Store(this.DataBase)
    mix = () => new this.Mix(this.DataBase)
}

module.exports = DataBase