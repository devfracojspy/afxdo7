'use strict'

const mongoose = require('mongoose')

const Schema = mongoose.Schema
const schema = new Schema({
    code: {
        required: true,
        type: String,
        unique: true
    },
    redeem: {
        type: Boolean,
        required: true
    },
    value: {
        type: Number,
        required: true,
        trim: true
    },
    redeemed: {
        type: Number,
        required: true,
        trim: true
    }
}, {timestamps: true})
		
module.exports = schema