'use strict'

const mongoose = require('mongoose')

const Schema = mongoose.Schema
const schema = new Schema(
  {
    name: {
      required: true,
      type: String,
    },
    id: {
      type: Number,
      unique: true,
      required: true,
    },
    historic: {
      type: Array,
      required: true,
    },
    credits: {
      type: Number,
      trim: true,
      required: true,
    },
    restrict: {
      type: Boolean,
      required: true,
    },
    current_transactions: {
      type: Number,
      required: true,
    },
    admin: {
      type: Boolean,
      required: true,
    },
    shopping: {
      credits: {
        type: Number,
        required: true,
      },
      cards: {
        type: Number,
        required: true,
      },
      gifts: {
        type: Number,
        required: true,
      },
    },
    in_purchase: {
      type: Boolean,
      required: true,
    },
    affiliated: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  { timestamps: true }
)

schema.virtual('affiliates', {
  ref: 'User',
  localField: '_id',
  foreignField: 'affiliated',
})

schema.set('toObject', { virtuals: true })
schema.set('toJSON', { virtuals: true })

module.exports = schema
