'use strict'

const mongoose = require('mongoose')

mongoose.connect(process.env.DB_STRING, {
    useNewUrlParser: true,
     useUnifiedTopology: true,
      useCreateIndex: true,
       useFindAndModify: false
})

exports.User = mongoose.model('User', require('./models/user'))
exports.Level = mongoose.model('Level', require('./models/level'))
exports.Cards = mongoose.model('Cards', require('./models/cards'))
exports.Gift = mongoose.model('Gift', require('./models/gift'))
exports.Store = mongoose.model('Store', require('./models/store'))
exports.Transactions = mongoose.model('Transactions', require('./models/transactions'))
exports.Mix = mongoose.model('Mix', require('./models/mix'))
exports.Owner = mongoose.model('Owner', require('./models/owner'))