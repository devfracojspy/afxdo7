require('../../../utils/PrototypeFunctions')

const { setTimeout } = require('timers/promises')
const Data = require('../../../utils/PreferenceFunctions')

class Callback {
  constructor(bot, message, Db = {}) {
    this.bot = bot
    this.data = message
    this.Db = Db
    this.by = process.env.ONWER_USERNAME
    this.owner = process.env.ONWER_USERNAME
  }

  cancelarCompra() {
    console.log(this.data)
    const cancelBuy = {
      message: `Compra cancelada.`,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
      },
    }

    return cancelBuy
  }

  async comprarCartao() {
    const card = this.data.data.split('_')[1]
    const callbackid = this.data.id
    const { response: userInfo } = await this.Db.user().informacoes()
    const { checker: checkerIsActive } =
      await this.Db.store().settings.getSettings()
    const observationMessage = (await checkerIsActive)
      ? `<b>Cartão verificado (Live) ☑️</b>`
      : `<b>Este cartão foi comprado com o checker indisponível ℹ️</b>`

    const notificarCompra = async (cardPurshased) => {
      const channelId = process.env.CARDS_SOLD_LOG_CHANNEL
      this.bot.sendMessage(
        channelId,
        `<b>Compra efetuada (Inline)</b>\n\n<b>Usuário: </b><a href='tg://user?id=${
          userInfo.id
        }'>${userInfo.name}</a> - <b>R$${userInfo.credits} (- R$${
          cardPurshased.level.price
        })</b>\n<b>Id:</b><code>${
          userInfo.id
        }</code>\n\n<b>Cartão: </b><code>${cardPurshased.number
          .slice(0, 6)
          .padEnd(
            cardPurshased.number.toString().length,
            '*'
          )}</code>\n<b>Expiração: </b><code>${cardPurshased.month.replace(
          /[0-9]/g,
          '*'
        )}/${cardPurshased.year.replace(
          /[0-9]/g,
          '*'
        )}</code>\n<b>Cvv:</b> <code>${cardPurshased.cvv.replace(
          /[0-9]/g,
          '*'
        )}</code>`,
        { parse_mode: 'HTML' }
      )
    }

    const Dados = Data.getData()
    const fullData = await Data.getFullData(Dados.cpf)
    const setInPurchase = (state) =>
      this.Db.user().atualizar({ in_purchase: state })

    var buyCardOptions = {
      message: String,
      options: {
        parse_mode: 'html',
        inline_message_id: this.data.inline_message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    var { response: cartao } = await this.Db.card().cartao(card)

    if (cartao.level.price == 'A combinar')
      return this.bot.answerCallbackQuery(
        callbackid,
        'Cartão disponível apenas para compra manual.',
        { show_alert: true }
      )

    if (userInfo.credits >= cartao.level.price) {
      await setInPurchase(true)
      buyCardOptions.message = `<i>Obtendo cartão...</i>`
      buyCardOptions.options.reply_markup.inline_keyboard = [
        [
          {
            text: '🔄 Verificando',
            callback_data: 'none',
          },
        ],
      ]

      await this.bot.editMessageText(
        buyCardOptions.message,
        buyCardOptions.options
      )

      const check = await this.Db.card().cartao(card, true)

      cartao = check.response

      if (cartao.restrict) {
        await setInPurchase(false)
        buyCardOptions.message = `<b>Cartão não disponível para venda.</b>`
        buyCardOptions.options.reply_markup = undefined

        this.bot.editMessageText(
          buyCardOptions.message,
          buyCardOptions.options
        )
      } else {
        let updateUser = await this.Db.user().verificarEdeduzirSaldo(
          cartao.level.price
        )

        if (!updateUser.success)
          return this.bot.answerCallbackQuery(callbackid, {
            text: `Saldo insuficiente`,
            show_alert: true,
          })

        buyCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
          cartao.number
        }|${cartao.month}|${cartao.year}|${
          cartao.cvv
        }</code>\n<b>Banco:</b> <code>${
          cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado'
        }</code>\n<b>Nivel: </b><code>${
          cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
        }</code>\n<b>Tipo: </b><code>${
          cartao.bin.type ? cartao.bin.type : 'Não especificado'
        }</code>\n\n${
          fullData.success
            ? fullData.response
            : `<b>Nome: </b><code>${Dados.name}</code>\n<b>Cpf: </b><code>${Dados.cpf}</code>`
        }\n\n${observationMessage}\n\n<b>Prazo de reembolso: 10m</>`

        buyCardOptions.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '💰 reembolso',
                callback_data: `reembolso ${cartao._id} ${Dados.cpf}`,
              },
            ],
          ],
        }

        await setInPurchase(false)

        await this.Db.level().restringirCartao(card, userInfo.id)

        await this.bot.editMessageText(
          buyCardOptions.message,
          buyCardOptions.options
        )

        await notificarCompra(cartao)
      }
    } else {
      this.bot.answerCallbackQuery(callbackid, {
        text: `Saldo insuficiente`,
        show_alert: true,
      })
    }
  }

  async reembolso(callbackData) {
    const [, cardId, cardHolderCpf] = callbackData.split(' ')
    const callbackId = this.data.id

    await this.bot.answerCallbackQuery(callbackId, {
      text: 'Processando reembolso...',
      show_alert: true,
    })

    const setInPurchase = (state) =>
      this.Db.user().atualizar({ in_purchase: state })

    await setInPurchase(true)

    const card = await this.Db.card().find({ _id: cardId })
    const test = await this.Db.card().checar(card.number, true)
    const isLive = test.success
    const cardPrice = card.level.price
    const cardHolder = Data.find(cardHolderCpf)

    let refundMessage = String()

    const createInlineButton = function (...buttonsArray) {
      return {
        inline_keyboard: buttonsArray.map(([text, data]) => [
          {
            text: text,
            callback_data: data,
          },
        ]),
      }
    }

    const options = {
      parse_mode: 'html',
      inline_message_id: this.data.inline_message_id,
    }

    const nowDate = new Date().getTime()
    const cardBuyDate = new Date(card.updatedAt).getTime()

    const timeDifference = (nowDate - cardBuyDate) / 1000

    if (timeDifference > Number(process.env.REFUND_CARD_TIME) * 60) {
      refundMessage = 'Tempo de reembolso expirado!'
    } else if (!isLive) {
      await this.Db.user().adicionarSaldo(cardPrice)
      refundMessage = `Cartão die, reembolso de R$${cardPrice} foi efetuado.`
    } else {
      refundMessage = `Cartão live, reembolso cancelado.`
    }

    await this.bot.editMessageText(
      `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
        card.number
      }|${card.month}|${card.year}|${
        card.cvv
      }</code>\n<b>Banco:</b> <code>${
        card.bin.bank ? card.bin.bank.name : 'Não especificado'
      }</code>\n<b>Nivel: </b><code>${
        card.bin.brand ? card.bin.brand : 'Não especificado'
      }</code>\n<b>Tipo: </b><code>${
        card.bin.type ? card.bin.type : 'Não especificado'
      }</code>\n\n<b>Nome: </b><code>${
        cardHolder.name
      }</code>\n<b>Cpf: </b><code>${
        cardHolder.cpf
      }</code>\n\n<b>${refundMessage}</>`,
      {
        ...options,
        reply_markup: createInlineButton(['❤️', 'compraFinalizada']),
      }
    )

    await setInPurchase(false)
  }

  async callbackType(d) {
    const data = d.includes('_') ? d.split('_')[0] : d
    const isInPurchase = async () => {
      const userInfos = (await this.Db.user().informacoes()).response
      if (userInfos.in_purchase) {
        await this.bot.answerCallbackQuery(this.data.id, {
          show_alert: true,
          text: 'Você so pode comprar uma unitária  por vez.',
        })
        return false
      }
      return true
    }

    try {
      const types = {
        cancelarCompra: () => this.cancelarCompra(),
        comprarCartao: async () =>
          (await isInPurchase()) && this.comprarCartao(),
      }

      if (data.includes('reembolso'))
        (await isInPurchase()) && (await this.reembolso(data))

      if (types[data]) {
        const { message, options } = await types[data]()
        this.bot.editMessageText(message, options)
      }
    } catch (e) {
      console.log(e)
      console.log('Funcão sem retorno')
    }
  }
}

module.exports = Callback
