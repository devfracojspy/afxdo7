const fs = require('fs')
const csvFile = fs.readFileSync(`${__dirname}/bins.csv`, 'utf-8')
const binEntries = csvFile.split('\n')

exports.getBinData = (bin) => {
  const targetBinArray =
    binEntries.find((line) => line.includes(bin)) ?? String()

  const lines = targetBinArray.split(':')

  const defaultValue = 'NÃO ENCONTRADO'
  const [, type, brand, scheme, bank, country_code] = lines.map(
    (line) =>
      line
        .replaceAll(
          [
            'SEM INFORMAÃÃO',
            'SEM INFORMAÇÃO',
            'SEM INFORMÃÃO',
            'SEM INFORMÃÃO',
          ].find((el) => line.includes(el)),
          defaultValue
        )
        .trim()
  )

  return Object.fromEntries([
    ['scheme', scheme || defaultValue],
    ['brand', brand?.includes?.(defaultValue) ? 'MISTERIOSA' : brand],
    ['type', type || defaultValue],
    ['bank', { name: bank || defaultValue }],
    ['bin', bin],
    [
      'country',
      {
        country_code: country_code || defaultValue,
      },
    ],
  ])
}
