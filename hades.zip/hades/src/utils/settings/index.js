const editJsonFile = require('edit-json-file')
const file = editJsonFile(`${__dirname}/../../../store-settings.json`)

exports.editPaymentMessage = (text) => {
    const tagsObject = {
        n: 'b',
        negrito: 'b',
        c: 'code',
        copiar: 'code',
        italico: 'i',
        i: 'i',
    }

    Object.entries(tagsObject).forEach(([before, after]) => {
        const regEx = new RegExp('(<\\/?)(' + before + ')(>)', 'g')
        text = text.replace(regEx, `$1${after}$3`)
    })

    file.set('lara', text)
    file.save()

    return file.get()
}

exports.getPaymentSettings = () => {
    return file.get()
}

exports.pixSettings = (key, value) => 
    key ? file.set(key, value) && file.save() : file.get()

