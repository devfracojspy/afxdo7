exports.getData = () => {
  const Data = require('fs')
    .readFileSync(`${__dirname}/data/dados.txt`, 'utf-8')
    .split('\n')
    .map((data) => {
      const [cpf, name] = data.trim().split(',')
      return {
        name: name,
        cpf: cpf,
      }
    })

  return Data.shuffle()[0]
}

exports.find = (cpf) => {
  const Data = require('fs')
    .readFileSync(`${__dirname}/data/dados.txt`, 'utf-8')
    .split('\n')
    .map((data) => {
      const [cpf, name] = data.trim().split(',')
      return {
        name: name,
        cpf: cpf,
      }
    })

  const found = Data.find((person) => person.cpf == cpf)

  return found ? found : false
}

exports.getFullData = async (cpf) => {
  try {
    return {
      success: false,
      response: '',
    }
  } catch (e) {
    return {
      success: false,
      response: '',
    }
  }
}
