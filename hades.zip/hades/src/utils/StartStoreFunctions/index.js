const checkerUnavalaibleMessage = 'Checagem antes da compra está indisponível.'

exports.createStoreModel = async function (database){

    if(!await database.Store.exists({name: process.env.STORE_NAME})){
        
        let store = new database.Store()
        
        store.name = process.env.STORE_NAME
        store.alerts = {
            checker: 'Checker disponível'
        }
        store.statistics = {}
        store.version  = '4.0'
        store.test_mode = false
        store.settings = {
            checker: true
        }
        store.about = {}
        store.save()
    }
}
