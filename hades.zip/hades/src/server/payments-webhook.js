const fastify = require('fastify')({ logger: true })
const mpService = require('../services/payments/mercadopago')
const pgService = require('../services/payments/pagseguro')
const port = process.env.PORT
const asaasService = require('../services/payments/asaas')

fastify.post(
  `/${process.env.WEBHOOK_ID}/webhooks/mercadopago`,
  async (request, reply) => {
    const body = request.body

    console.log(body)

    if (body?.data) await mpService.verifyPayment(body.data.id)

    return {
      ok: true,
    }
  }
)

fastify.post(
  `/${process.env.WEBHOOK_ID}/webhooks/pagseguro`,
  async (request) => {
    const body = request.body

    console.log(body)

    if (body) await pgService.verifyPayment(body)

    return {
      ok: true,
    }
  }
)

fastify.post(
  `/${process.env.WEBHOOK_ID}/webhooks/asaas`,
  async (request, reply) => {
    const body = request.body

    console.log(body)

    if (body.event == 'PAYMENT_RECEIVED') {
      await asaasService.verifyPayment(body.payment)
    }

    return {
      ok: true,
    }
  }
)

exports.startServer = async () => {
  await fastify.listen(port).catch(fastify.log.error)
}
