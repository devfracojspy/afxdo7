"use strict";

var company = require('./company');
var confidence = require('./confidence');
var azkabancenter = require('./azkabancenter');
var warlock = require('./warklock');
var allcenter = require('./allcenter');
var falselive = require('./falselive');
var blackcenter = require('./blackcenter');
var dbf = require('./dbf');
var theunknown = require('./theunknown');
module.exports = {
  company: company,
  confidence: confidence,
  azkabancenter: azkabancenter,
  warlock: warlock,
  allcenter: allcenter,
  falselive: falselive,
  dbf: dbf,
  blackcenter: blackcenter,
  theunknown: theunknown
};