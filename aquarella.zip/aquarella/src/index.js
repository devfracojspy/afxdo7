'use strict';

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
var _templateObject;
function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toArray(arr) { return _arrayWithHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableRest(); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
process.env.UV_THREADPOOL_SIZE = 164;
process.env.NTBA_FIX_319 = 1;

//process.exit(1)

require('dotenv').config();
var _require = require('grammy'),
  InlineKeyboard = _require.InlineKeyboard;
var TelegramBot = require('node-telegram-bot-api');
var bot = new TelegramBot(process.env.TELEGRAM_BOT_API_KEY, {
  polling: true
});
var Callback = require('./callbacks');
var inline = require('./inline');
var database = require('./database');
var DataBaseFunctions = require('./class');
var start = require('./utils/StartStoreFunctions');
var PrototypeFunctions = require('./utils/PrototypeFunctions');
start.createStoreModel(database);
_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
  return _regeneratorRuntime().wrap(function _callee$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return database.User.updateMany({
            in_purchase: false
          });
        case 2:
          return _context.abrupt("return", _context.sent);
        case 3:
        case "end":
          return _context.stop();
      }
    }
  }, _callee);
}))();
bot.onText(/(^\/start|^\/menu)/, /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(message) {
    var callbackInitial, messageId, userId, DBF, validar;
    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            callbackInitial = new Callback(bot, message);
            messageId = message.message_id;
            userId = message.from.id;
            DBF = new DataBaseFunctions(database, message);
            _context2.next = 6;
            return DBF.user().verificarEadicionar();
          case 6:
            validar = _context2.sent;
            if (validar.success) {
              _context2.next = 9;
              break;
            }
            return _context2.abrupt("return", bot.sendMessage(message.chat.id, "<b>Falha ao executar este comando.</b>\n<b>Poss\xEDves motivos:</b> <i>".concat(validar.message, "</i>"), {
              parse_mode: 'HTML'
            }));
          case 9:
            bot.sendMessage(message.chat.id, callbackInitial.start().message, callbackInitial.start().options);
            bot.on('callback_query', function (data) {
              var callbackid = data.id;
              try {
                if (data.message && data.message.reply_to_message.message_id == messageId && data.from.id != userId) return bot.answerCallbackQuery(callbackid, {
                  text: 'Este menu não foi solicitado por você.',
                  show_alert: true
                });
                if (data.message && data.message.reply_to_message.message_id == messageId && data.from.id == userId) {
                  var callback = new Callback(bot, data, DBF);
                  var callbackdata = data.data;
                  if (!validar.success) return bot.answerCallbackQuery(callbackid, {
                    text: 'Sua conta está restrita',
                    show_alert: true
                  });
                  callback.callbackType(callbackdata);
                }
              } catch (e) {
                console.log('Error: ', e.message);
                //return bot.answerCallbackQuery(callbackid, {text: 'Algo deu errado...', show_alert: false})
              }
            });
          case 11:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return function (_x) {
    return _ref2.apply(this, arguments);
  };
}());
bot.onText(/^\/adicionar/, /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4(message) {
    var https, fs, options, DBF, validar, autorizacao, getFile, replyMessage, _message$reply_to_mes, _message$reply_to_mes2, _start, _yield$bot$sendMessag, message_id, cards, add;
    return _regeneratorRuntime().wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            https = require('https');
            fs = require('fs');
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            DBF = new DataBaseFunctions(database, message);
            _context4.next = 6;
            return DBF.user().verificarEadicionar();
          case 6:
            validar = _context4.sent;
            _context4.next = 9;
            return DBF.user().admin();
          case 9:
            autorizacao = _context4.sent;
            if (!message.reply_to_message) {
              _context4.next = 44;
              break;
            }
            getFile = function getFile() {
              return new Promise( /*#__PURE__*/function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(resolve, reject) {
                  var _replyMessage$documen;
                  var id, file_id, fileLink, path, file;
                  return _regeneratorRuntime().wrap(function _callee3$(_context3) {
                    while (1) {
                      switch (_context3.prev = _context3.next) {
                        case 0:
                          id = Math.floor(Math.random() * 999);
                          file_id = replyMessage === null || replyMessage === void 0 ? void 0 : (_replyMessage$documen = replyMessage.document) === null || _replyMessage$documen === void 0 ? void 0 : _replyMessage$documen.file_id;
                          _context3.next = 4;
                          return bot.getFileLink(file_id);
                        case 4:
                          fileLink = _context3.sent;
                          path = "".concat(__dirname, "/class/card/add/").concat(id, ".txt");
                          file = fs.createWriteStream(path);
                          https.get(fileLink, function (response) {
                            return response.pipe(file);
                          });
                          file.on('finish', function () {
                            var fileContent = fs.readFileSync(path, 'utf-8');
                            fs.unlinkSync(path);
                            resolve(fileContent);
                          });
                        case 9:
                        case "end":
                          return _context3.stop();
                      }
                    }
                  }, _callee3);
                }));
                return function (_x3, _x4) {
                  return _ref4.apply(this, arguments);
                };
              }());
            };
            replyMessage = message.reply_to_message;
            if (!(!replyMessage.text && !replyMessage.document)) {
              _context4.next = 15;
              break;
            }
            return _context4.abrupt("return");
          case 15:
            if (!autorizacao.success) {
              _context4.next = 43;
              break;
            }
            _start = Date.now();
            _context4.next = 19;
            return bot.sendMessage(message.chat.id, "\u23F3 <b> Adicionando na base...</b>", options);
          case 19:
            _yield$bot$sendMessag = _context4.sent;
            message_id = _yield$bot$sendMessag.message_id;
            _context4.t0 = DBF.card();
            if (!((_message$reply_to_mes = (_message$reply_to_mes2 = message.reply_to_message) === null || _message$reply_to_mes2 === void 0 ? void 0 : _message$reply_to_mes2.text) !== null && _message$reply_to_mes !== void 0)) {
              _context4.next = 26;
              break;
            }
            _context4.t1 = _message$reply_to_mes;
            _context4.next = 29;
            break;
          case 26:
            _context4.next = 28;
            return getFile();
          case 28:
            _context4.t1 = _context4.sent;
          case 29:
            _context4.t2 = _context4.t1;
            _context4.next = 32;
            return _context4.t0.formatarCartoes.call(_context4.t0, _context4.t2);
          case 32:
            cards = _context4.sent;
            if (!cards.success) {
              _context4.next = 40;
              break;
            }
            _context4.next = 36;
            return DBF.level().adicionarCartoes(cards.response);
          case 36:
            add = _context4.sent;
            bot.editMessageText("\u2705 <b>Cart\xF5es adicionados com sucesso.\n" + "\uD83D\uDCB3 Total</b>: ".concat(cards.total, "\n") + "<b>\u23F1 Tempo decorrido: </b>".concat(((Date.now() - _start) / 1000).toFixed(1), "\n") + "<b>\u203C\uFE0F Cart\xF5es existentes: ".concat(cards.details.exists, "</b>\n") + "<b>\u2049\uFE0F Cart\xF5es inv\xE1lidos: ".concat(cards.details.invalids, "</b>\n") + "<b>\uD83D\uDD87 Cart\xF5es repetidos: ".concat(cards.details.repeats, "</b>"), {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
            _context4.next = 41;
            break;
          case 40:
            bot.editMessageText("".concat(cards.response, "\n") + "<b>\u2699\uFE0F Debug: </b><code>".concat(cards.debug, "</code>"), {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
          case 41:
            _context4.next = 44;
            break;
          case 43:
            return _context4.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 44:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return function (_x2) {
    return _ref3.apply(this, arguments);
  };
}());
bot.onText(/^\/gift (.*)/, /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6(message, match) {
    var DBF, giftValue, options, validar, autorizacao, _validar, generateGift, giftCreatedOptions;
    return _regeneratorRuntime().wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            DBF = new DataBaseFunctions(database, message);
            giftValue = parseInt(match[1]).toFixed(2);
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!(giftValue < 0.01)) {
              _context6.next = 5;
              break;
            }
            return _context6.abrupt("return", bot.sendMessage(message.chat.id, '<b>Valor incorreto. Crie um gift de no mínimo R$1</b>', options));
          case 5:
            _context6.next = 7;
            return DBF.user().verificarEadicionar();
          case 7:
            validar = _context6.sent;
            _context6.next = 10;
            return DBF.user().admin();
          case 10:
            autorizacao = _context6.sent;
            if (!autorizacao.success) {
              _context6.next = 22;
              break;
            }
            _context6.next = 14;
            return DBF.user().verificarEadicionar();
          case 14:
            _validar = _context6.sent;
            _context6.next = 17;
            return DBF.gift().gift(giftValue);
          case 17:
            generateGift = _context6.sent;
            giftCreatedOptions = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html',
              reply_markup: {
                inline_keyboard: [[{
                  text: '❌ Cancelar',
                  callback_data: "deleteGift_".concat(generateGift.message.code)
                }]]
              }
            };
            if (generateGift.success) {
              bot.sendMessage(message.chat.id, "\uD83C\uDF81 <b>Gift criado com sucesso.</b>\n\n<b>Valor: </b><i>R$".concat(giftValue, "</i>\n<b>Gift: </b><code>/resgatar ").concat(generateGift.message.code, "</code>"), giftCreatedOptions);
              bot.on('callback_query', /*#__PURE__*/function () {
                var _ref6 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5(callback) {
                  var _callback$data$split, _callback$data$split2, gift, deleteGift;
                  return _regeneratorRuntime().wrap(function _callee5$(_context5) {
                    while (1) {
                      switch (_context5.prev = _context5.next) {
                        case 0:
                          if (!(callback.data.includes('deleteGift') && callback.message.reply_to_message.message_id == message.message_id)) {
                            _context5.next = 11;
                            break;
                          }
                          _callback$data$split = callback.data.split('_'), _callback$data$split2 = _slicedToArray(_callback$data$split, 2), gift = _callback$data$split2[1];
                          if (!(callback.from.id == message.from.id)) {
                            _context5.next = 10;
                            break;
                          }
                          _context5.next = 5;
                          return database.Gift.deleteOne({
                            code: gift
                          });
                        case 5:
                          deleteGift = _context5.sent;
                          bot.editMessageText('<b>Gift deletado.</b>', {
                            message_id: callback.message.message_id,
                            chat_id: callback.message.chat.id,
                            parse_mode: 'html'
                          });
                          bot.removeListener('callback_query', function (calbackListenerDeleted) {
                            return calbackListenerDeleted;
                          });
                          _context5.next = 11;
                          break;
                        case 10:
                          return _context5.abrupt("return", bot.answerCallbackQuery(callback.id, {
                            text: 'Acesso restrito.',
                            show_alert: true
                          }));
                        case 11:
                        case "end":
                          return _context5.stop();
                      }
                    }
                  }, _callee5);
                }));
                return function (_x7) {
                  return _ref6.apply(this, arguments);
                };
              }());
            } else {
              bot.sendMessage(message.chat.id, '<b>Houve uma falha ao criar este gift. </b>', options);
            }
            _context6.next = 23;
            break;
          case 22:
            return _context6.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 23:
          case "end":
            return _context6.stop();
        }
      }
    }, _callee6);
  }));
  return function (_x5, _x6) {
    return _ref5.apply(this, arguments);
  };
}());
bot.on('message', /*#__PURE__*/function () {
  var _ref7 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7(message) {
    var Checker, DBF, _yield$DBF$store$sett, checkerIsActive, checker;
    return _regeneratorRuntime().wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            Checker = require('./checker');
            DBF = new DataBaseFunctions(database, message);
            _context7.next = 4;
            return DBF.store().settings.getSettings();
          case 4:
            _yield$DBF$store$sett = _context7.sent;
            checkerIsActive = _yield$DBF$store$sett.checker;
            if (!checkerIsActive) {
              _context7.next = 9;
              break;
            }
            console.log('Checker online');
            return _context7.abrupt("return");
          case 9:
            console.log('Checker offline');
            checker = new Checker(database);
            _context7.next = 13;
            return checker.testChecker();
          case 13:
          case "end":
            return _context7.stop();
        }
      }
    }, _callee7);
  }));
  return function (_x8) {
    return _ref7.apply(this, arguments);
  };
}());
bot.onText(/^\/resgatar (.*)|([\w]{4})\-([\w]{4})\-([\w]{4})\-([\w]{4})\-([\w]{4})/gm, /*#__PURE__*/function () {
  var _ref8 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8(message, match) {
    var _match$;
    var DBF, options, gift, Gift, validar, redeem, channels, _i2, _channels, channel;
    return _regeneratorRuntime().wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            DBF = new DataBaseFunctions(database, message);
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            gift = (_match$ = match[1]) !== null && _match$ !== void 0 ? _match$ : match[0];
            _context8.next = 5;
            return DBF.gift().resgatado(gift);
          case 5:
            Gift = _context8.sent;
            _context8.next = 8;
            return DBF.user().verificarEadicionar();
          case 8:
            validar = _context8.sent;
            if (!Gift.success) {
              _context8.next = 25;
              break;
            }
            _context8.next = 12;
            return DBF.user().resgatarGift(gift);
          case 12:
            redeem = _context8.sent;
            if (!redeem.success) {
              _context8.next = 19;
              break;
            }
            bot.sendMessage(message.chat.id, "\uD83C\uDF81 <b>Gift resgatado com sucesso!\n\n- O valor de <i>R$".concat(redeem.gift.value, "</i> foi creditado em sua conta, use /info para ver seu saldo.\n</b>\n- <b>N\xE3o sabe como comprar?</b>\n\n<b>Digite /menu para exibir o menu do bot, aperte em \uD83D\uDCB3 Comprar, escolha o tipo de compra:</b>\n\n<b>\uD83D\uDCB3 Unit\xE1ria [Classificadas por n\xEDvel]:</b> \n<i>Aperte no n\xEDvel desejado, logo em seguida em \u2705 Comprar.</i>\n\n<b>\uD83D\uDD00 Mix:</b>\n<i>Escolha a mix de sua prefer\xEAncia, e aperte em \u2705 Comprar.</i>\n\n<b>\uD83C\uDFB2 Cart\xE3o aleat\xF3rio [N\xEDvel/Bandeira aleat\xF3rio(a)]:</b>\n<i>Aperte em \u2705 Comprar, se desejar uma alet\xF3ria diferente, aperte em \uD83D\uDD19 Voltar, e selecione \uD83C\uDFB2 Aleat\xF3ria novamente.</i>"), options);
            channels = [-1001800801900];
            for (_i2 = 0, _channels = channels; _i2 < _channels.length; _i2++) {
              channel = _channels[_i2];
              bot.sendMessage(channel, "<b>\uD83C\uDF81 Gift resgatado!\n\nUsu\xE1rio: <i>".concat(redeem.user.name, "</i>\nId: ").concat(redeem.user.id.toString().slice(redeem.user.id.toString().length - 3, redeem.user.id.toString().length).padStart(redeem.user.id.toString().length, '*'), "\nValor: R$").concat(redeem.gift.value, "\nGift: ").concat(redeem.gift.code.split('').map(function (c) {
                return Math.random() > 0.5 ? '*' : c;
              }).join(''), "\n\n</b><i>Esse gift \xE9 destinado apenas para compra de info cc</i>\n\n@LOJAAQUARELLA"), {
                parse_mode: 'html'
              });
            }
            _context8.next = 23;
            break;
          case 19:
            _context8.next = 21;
            return bot.sendMessage(message.chat.id, redeem.message, options);
          case 21:
            _context8.next = 23;
            return DBF.user().restringirUsuario();
          case 23:
            _context8.next = 26;
            break;
          case 25:
            bot.sendMessage(message.chat.id, Gift.message, options);
          case 26:
          case "end":
            return _context8.stop();
        }
      }
    }, _callee8);
  }));
  return function (_x9, _x10) {
    return _ref8.apply(this, arguments);
  };
}());
bot.onText(/^\/editar (.*)/, /*#__PURE__*/function () {
  var _ref9 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9(message, match) {
    var DBF, validar, autorizacao, options, _match$1$split, _match$1$split2, level, prices, nivel, _yield$bot$sendMessag2, message_id, editar;
    return _regeneratorRuntime().wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context9.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context9.sent;
            _context9.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context9.sent;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context9.next = 24;
              break;
            }
            _match$1$split = match[1].split('['), _match$1$split2 = _slicedToArray(_match$1$split, 2), level = _match$1$split2[0], prices = _match$1$split2[1];
            nivel = {
              type: level.trim(),
              prices: prices.replace(/[^0-9,]/g, '').split(',')
            };
            if (!(nivel.prices[0].length < 1 || nivel.prices[1].length < 1)) {
              _context9.next = 14;
              break;
            }
            return _context9.abrupt("return", bot.sendMessage(message.chat.id, "<b>Comando inv\xE1lido.</b>", options));
          case 14:
            _context9.next = 16;
            return bot.sendMessage(message.chat.id, "\uD83D\uDD04 <b> Editando...</b>", options);
          case 16:
            _yield$bot$sendMessag2 = _context9.sent;
            message_id = _yield$bot$sendMessag2.message_id;
            _context9.next = 20;
            return DBF.level().editarNivel(nivel.type, nivel.prices);
          case 20:
            editar = _context9.sent;
            if (editar.success) {
              bot.editMessageText("\u2705 <b>N\xEDvel editado com sucesso.</b>\n\n<b>Valor:</b> <i>".concat(nivel.prices[0], "</i>\n<b>Valor alternativo:</b> <i>").concat(nivel.prices[1], "</i>"), {
                message_id: message_id,
                chat_id: message.chat.id,
                parse_mode: 'HTML'
              });
            } else {
              bot.editMessageText(editar.response, {
                message_id: message_id,
                chat_id: message.chat.id,
                parse_mode: 'HTML'
              });
            }
            _context9.next = 25;
            break;
          case 24:
            return _context9.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 25:
            _context9.next = 30;
            break;
          case 27:
            _context9.prev = 27;
            _context9.t0 = _context9["catch"](0);
            console.log(_context9.t0.message);
          case 30:
          case "end":
            return _context9.stop();
        }
      }
    }, _callee9, null, [[0, 27]]);
  }));
  return function (_x11, _x12) {
    return _ref9.apply(this, arguments);
  };
}());
bot.onText(/^\/notificar (.*)/, /*#__PURE__*/function () {
  var _ref10 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10(message, match) {
    var DBF, validar, autorizacao, options, mensagem, users, _yield$bot$sendMessag3, message_id, _iterator, _step, user;
    return _regeneratorRuntime().wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            _context10.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context10.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context10.sent;
            _context10.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context10.sent;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context10.next = 23;
              break;
            }
            mensagem = match['input'].replace('/notificar ', '');
            _context10.next = 13;
            return DBF.user().usuarios();
          case 13:
            users = _context10.sent;
            _context10.next = 16;
            return bot.sendMessage(message.chat.id, "\uD83D\uDD04 <b> Notificando...</b>", options);
          case 16:
            _yield$bot$sendMessag3 = _context10.sent;
            message_id = _yield$bot$sendMessag3.message_id;
            _iterator = _createForOfIteratorHelper(users.response);
            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                user = _step.value;
                bot.sendMessage(user.id, mensagem, {
                  parse_mode: 'Markdown'
                })["catch"](function (error) {
                  return error;
                });
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }
            bot.editMessageText("\u2705 <b>Notifica\xE7\xE3o enviada com sucesso.</b>\n<b>Usuarios:</b><i> ".concat(users.response.length, "</i>"), {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
            _context10.next = 24;
            break;
          case 23:
            return _context10.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 24:
            _context10.next = 29;
            break;
          case 26:
            _context10.prev = 26;
            _context10.t0 = _context10["catch"](0);
            console.log(_context10.t0.message);
          case 29:
          case "end":
            return _context10.stop();
        }
      }
    }, _callee10, null, [[0, 26]]);
  }));
  return function (_x13, _x14) {
    return _ref10.apply(this, arguments);
  };
}());
bot.on('message', /*#__PURE__*/function () {
  var _ref11 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14(message) {
    var caption, askOptions, chatId, messageId, userId, DBF, validar, autorizacao;
    return _regeneratorRuntime().wrap(function _callee14$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            _context15.next = 2;
            return Function.sleep(500);
          case 2:
            if (!(message.chat.type != 'private')) {
              _context15.next = 4;
              break;
            }
            return _context15.abrupt("return");
          case 4:
            caption = message.caption ? message.caption : '';
            askOptions = {
              parse_mode: 'html',
              reply_to_message_id: message.message_id,
              reply_markup: {
                inline_keyboard: [[{
                  text: '✅',
                  callback_data: 'notificarMensagem'
                }, {
                  text: '❌',
                  callback_data: 'cancelarOperacao'
                }]]
              }
            };
            chatId = message.chat.id;
            messageId = message.message_id;
            userId = message.from.id;
            DBF = new DataBaseFunctions(database, message);
            _context15.next = 12;
            return DBF.user().verificarEadicionar();
          case 12:
            validar = _context15.sent;
            _context15.next = 15;
            return DBF.user().admin();
          case 15:
            autorizacao = _context15.sent;
            if (!autorizacao.success) {
              _context15.next = 20;
              break;
            }
            return _context15.delegateYield( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13() {
              var MediaTypes, _loop, type, _ret;
              return _regeneratorRuntime().wrap(function _callee13$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      MediaTypes = {
                        photo: function photo(id) {
                          var _message$photo = _slicedToArray(message.photo, 1),
                            file = _message$photo[0];
                          bot.sendPhoto(id, file.file_id, caption.length > 1 ? {
                            caption: caption
                          } : {})["catch"](function (error) {
                            return error;
                          });
                        },
                        video: function video(id) {
                          var fileId = message.video.file_id;
                          bot.sendVideo(id, fileId, caption.length > 1 ? {
                            caption: caption
                          } : {})["catch"](function (error) {
                            return error;
                          });
                        },
                        document: function document(id) {
                          var fileId = message.document.file_id;
                          bot.sendDocument(id, fileId, caption.length > 1 ? {
                            caption: caption
                          } : {})["catch"](function (error) {
                            return error;
                          });
                        }
                      };
                      _loop = /*#__PURE__*/_regeneratorRuntime().mark(function _loop(type) {
                        var _yield$bot$sendMessag4, message_id;
                        return _regeneratorRuntime().wrap(function _loop$(_context13) {
                          while (1) {
                            switch (_context13.prev = _context13.next) {
                              case 0:
                                if (!MediaTypes[type]) {
                                  _context13.next = 7;
                                  break;
                                }
                                _context13.next = 3;
                                return bot.sendMessage(chatId, '<b>Deseja notificar esta mensagem?</b>', askOptions);
                              case 3:
                                _yield$bot$sendMessag4 = _context13.sent;
                                message_id = _yield$bot$sendMessag4.message_id;
                                bot.on('callback_query', function (callbackData) {
                                  if (callbackData.message && callbackData.message.reply_to_message.message_id == messageId && callbackData.from.id != userId) return bot.answerCallbackQuery(callbackData.id, {
                                    text: 'Este menu não foi solicitado por você.',
                                    show_alert: true
                                  });
                                  if (callbackData.message && callbackData.message.reply_to_message.message_id == messageId && callbackData.from.id == userId) {
                                    var actions = {
                                      notificarMensagem: function () {
                                        var _notificarMensagem = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11() {
                                          var users, _iterator2, _step2, user;
                                          return _regeneratorRuntime().wrap(function _callee11$(_context11) {
                                            while (1) {
                                              switch (_context11.prev = _context11.next) {
                                                case 0:
                                                  _context11.next = 2;
                                                  return DBF.user().usuarios();
                                                case 2:
                                                  users = _context11.sent;
                                                  _context11.next = 5;
                                                  return bot.editMessageText("\uD83D\uDD04 <b> Notificando...</b>", {
                                                    parse_mode: 'HTML',
                                                    message_id: message_id,
                                                    chat_id: chatId
                                                  });
                                                case 5:
                                                  _iterator2 = _createForOfIteratorHelper(users.response);
                                                  try {
                                                    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                                                      user = _step2.value;
                                                      MediaTypes[type](user.id);
                                                    }
                                                  } catch (err) {
                                                    _iterator2.e(err);
                                                  } finally {
                                                    _iterator2.f();
                                                  }
                                                  bot.editMessageText("\u2705 <b>Notifica\xE7\xE3o enviada com sucesso.</b>\n<b>Usuarios:</b><i> ".concat(users.response.length, "</i>"), {
                                                    parse_mode: 'HTML',
                                                    message_id: message_id,
                                                    chat_id: chatId
                                                  });
                                                case 8:
                                                case "end":
                                                  return _context11.stop();
                                              }
                                            }
                                          }, _callee11);
                                        }));
                                        function notificarMensagem() {
                                          return _notificarMensagem.apply(this, arguments);
                                        }
                                        return notificarMensagem;
                                      }(),
                                      cancelarOperacao: function () {
                                        var _cancelarOperacao = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12() {
                                          return _regeneratorRuntime().wrap(function _callee12$(_context12) {
                                            while (1) {
                                              switch (_context12.prev = _context12.next) {
                                                case 0:
                                                  bot.editMessageText("<b>Opera\xE7\xE3o cancelada.</b>", {
                                                    parse_mode: 'HTML',
                                                    message_id: message_id,
                                                    chat_id: chatId
                                                  });
                                                case 1:
                                                case "end":
                                                  return _context12.stop();
                                              }
                                            }
                                          }, _callee12);
                                        }));
                                        function cancelarOperacao() {
                                          return _cancelarOperacao.apply(this, arguments);
                                        }
                                        return cancelarOperacao;
                                      }()
                                    };
                                    actions[callbackData.data]();
                                  }
                                });
                                return _context13.abrupt("return", "break");
                              case 7:
                              case "end":
                                return _context13.stop();
                            }
                          }
                        }, _loop);
                      });
                      _context14.t0 = _regeneratorRuntime().keys(message);
                    case 3:
                      if ((_context14.t1 = _context14.t0()).done) {
                        _context14.next = 11;
                        break;
                      }
                      type = _context14.t1.value;
                      return _context14.delegateYield(_loop(type), "t2", 6);
                    case 6:
                      _ret = _context14.t2;
                      if (!(_ret === "break")) {
                        _context14.next = 9;
                        break;
                      }
                      return _context14.abrupt("break", 11);
                    case 9:
                      _context14.next = 3;
                      break;
                    case 11:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee13);
            })(), "t0", 18);
          case 18:
            _context15.next = 20;
            break;
          case 20:
          case "end":
            return _context15.stop();
        }
      }
    }, _callee14);
  }));
  return function (_x15) {
    return _ref11.apply(this, arguments);
  };
}());
bot.on('inline_query', function (inline_data) {
  return inline.inlineSearch(inline_data, database, bot);
});
bot.on('chosen_inline_result', /*#__PURE__*/function () {
  var _ref12 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee16(data) {
    var inlineMessageId, inlineUserId;
    return _regeneratorRuntime().wrap(function _callee16$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            inlineMessageId = data.inline_message_id;
            inlineUserId = data.from.id;
            bot.on('callback_query', /*#__PURE__*/function () {
              var _ref13 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee15(callback_data) {
                var receivedInlineMessageId, _data$query$trim$toLo, _data$query$trim$toLo2, inline_type, CallbackAdmin, DBF, autorizacao, message, callback, callbackdata, _callbackdata, _DBF, validar, CallbackInlineUser;
                return _regeneratorRuntime().wrap(function _callee15$(_context16) {
                  while (1) {
                    switch (_context16.prev = _context16.next) {
                      case 0:
                        receivedInlineMessageId = callback_data.inline_message_id ? callback_data.inline_message_id : 0;
                        if (!(receivedInlineMessageId === inlineMessageId)) {
                          _context16.next = 23;
                          break;
                        }
                        _data$query$trim$toLo = data.query.trim().toLowerCase().split(' '), _data$query$trim$toLo2 = _slicedToArray(_data$query$trim$toLo, 1), inline_type = _data$query$trim$toLo2[0];
                        if (!(inline_type == 'usuario' || inline_type == 'gift' || inline_type == 'admins')) {
                          _context16.next = 12;
                          break;
                        }
                        CallbackAdmin = require('./callbacks/inline/admin');
                        DBF = new DataBaseFunctions(database, callback_data);
                        _context16.next = 8;
                        return DBF.user().admin();
                      case 8:
                        autorizacao = _context16.sent;
                        if (autorizacao.success) {
                          message = {
                            from: {
                              id: data.result_id
                            }
                          };
                          callback = new CallbackAdmin(bot, callback_data, new DataBaseFunctions(database, message));
                          callbackdata = callback_data.data;
                          callback.callbackType(callbackdata);
                        } else {
                          bot.answerCallbackQuery(callback_data.id, {
                            text: 'Acesso não permitido.\nCode: 1',
                            show_alert: true
                          });
                        }
                        _context16.next = 23;
                        break;
                      case 12:
                        if (!(inline_type == 'bin' || inline_type == 'bandeira' || inline_type == 'banco')) {
                          _context16.next = 23;
                          break;
                        }
                        _callbackdata = callback_data.data;
                        if (!(callback_data.from.id != inlineUserId)) {
                          _context16.next = 16;
                          break;
                        }
                        return _context16.abrupt("return", bot.answerCallbackQuery(callback_data.id, {
                          text: 'Acesso não permitido.\nCode: 2',
                          show_alert: true
                        }));
                      case 16:
                        _DBF = new DataBaseFunctions(database, callback_data);
                        _context16.next = 19;
                        return _DBF.user().verificarEadicionar();
                      case 19:
                        validar = _context16.sent;
                        CallbackInlineUser = require('./callbacks/inline/user');
                        callback = new CallbackInlineUser(bot, callback_data, new DataBaseFunctions(database, callback_data));
                        callback.callbackType(_callbackdata);
                      case 23:
                      case "end":
                        return _context16.stop();
                    }
                  }
                }, _callee15);
              }));
              return function (_x17) {
                return _ref13.apply(this, arguments);
              };
            }());
          case 3:
          case "end":
            return _context17.stop();
        }
      }
    }, _callee16);
  }));
  return function (_x16) {
    return _ref12.apply(this, arguments);
  };
}());
bot.onText(/^\/user/, /*#__PURE__*/function () {
  var _ref14 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee17(message) {
    var DBF, validar, autorizacao, options, userId, user, button;
    return _regeneratorRuntime().wrap(function _callee17$(_context18) {
      while (1) {
        switch (_context18.prev = _context18.next) {
          case 0:
            _context18.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context18.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context18.sent;
            _context18.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context18.sent;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context18.next = 18;
              break;
            }
            if (!(message.reply_to_message && !message.reply_to_message.from.is_bot)) {
              _context18.next = 16;
              break;
            }
            userId = message.reply_to_message.from.id;
            user = message.reply_to_message;
            button = {
              reply_to_message_id: message.reply_to_message.message_id,
              parse_mode: 'html',
              reply_markup: {
                inline_keyboard: [[{
                  text: '🔍',
                  switch_inline_query_current_chat: 'usuario ' + userId
                }]]
              }
            };
            _context18.next = 16;
            return bot.sendMessage(message.chat.id, "<b>Nome: <code>".concat(user.name, "</code>\nId: <code>").concat(userId, "</code></b>"), button);
          case 16:
            _context18.next = 19;
            break;
          case 18:
            return _context18.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 19:
            _context18.next = 24;
            break;
          case 21:
            _context18.prev = 21;
            _context18.t0 = _context18["catch"](0);
            console.log(_context18.t0.message);
          case 24:
          case "end":
            return _context18.stop();
        }
      }
    }, _callee17, null, [[0, 21]]);
  }));
  return function (_x18) {
    return _ref14.apply(this, arguments);
  };
}());
bot.onText(/^\/ranking/, /*#__PURE__*/function () {
  var _ref15 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee18(message, match) {
    var options, DBF, validar, _yield$DBF$user$infor, user, _yield$DBF$user$usuar, users, RANKING_EMOJIS, rankingString, self, CREDITS, CARDS, GIFTS, RANKING;
    return _regeneratorRuntime().wrap(function _callee18$(_context19) {
      while (1) {
        switch (_context19.prev = _context19.next) {
          case 0:
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            DBF = new DataBaseFunctions(database, message);
            _context19.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context19.sent;
            _context19.next = 7;
            return DBF.user().informacoes();
          case 7:
            _yield$DBF$user$infor = _context19.sent;
            user = _yield$DBF$user$infor.response;
            _context19.next = 11;
            return DBF.user().usuarios();
          case 11:
            _yield$DBF$user$usuar = _context19.sent;
            users = _yield$DBF$user$usuar.response;
            if (!validar.success) {
              _context19.next = 23;
              break;
            }
            RANKING_EMOJIS = ['🥇', '🥈', '🥉'];
            rankingString = function rankingString(array, type) {
              var rankTypes = {
                credits: function credits(u) {
                  return "R$".concat(u.credits);
                },
                cards: function cards(u) {
                  return "".concat(u.shopping.cards);
                },
                gifts: function gifts(u) {
                  return "".concat(u.shopping.gifts);
                }
              };
              return array.map(function (u, i) {
                return "".concat(RANKING_EMOJIS[i] ? RANKING_EMOJIS[i] : '👤', " <a href='tg://user?id=").concat(u.id, "'>").concat(u.name, "</a> - ").concat(rankTypes[type](u));
              }).join('\n');
            };
            self = function self(arr) {
              var self = {};
              arr.forEach(function (e, p) {
                if (e.id == user.id) {
                  self.position = p + 1;
                }
              });
              self.position = self.position ? self.position : 'Não rankeado';
              return self;
            };
            users = users.filter(function (u) {
              return !u.admin;
            }).map(function (u) {
              return {
                id: u.id,
                name: u.name,
                credits: u.credits,
                shopping: u.shopping
              };
            });
            CREDITS = _toConsumableArray(users).sort(function (a, b) {
              return a.credits - b.credits;
            }).reverse(), CARDS = _toConsumableArray(users).sort(function (a, b) {
              return a.shopping.cards - b.shopping.cards;
            }).reverse(), GIFTS = _toConsumableArray(users).sort(function (a, b) {
              return a.shopping.gifts - b.shopping.gifts;
            }).reverse();
            RANKING = {
              credits: {
                ranking_string: CREDITS.length > 10 ? rankingString(CREDITS.slice(0, 10), 'credits') : rankingString(CREDITS, 'credits'),
                self: self(CREDITS)
              },
              cards: {
                ranking_string: CARDS.length > 10 ? rankingString(CARDS.slice(0, 10), 'cards') : rankingString(CARDS, 'cards'),
                self: self(CARDS)
              },
              gifts: {
                ranking_string: GIFTS.length > 10 ? rankingString(GIFTS.slice(0, 10), 'gifts') : rankingString(GIFTS, 'gifts'),
                self: self(GIFTS)
              },
              ranking_total: users.length
            };
            bot.sendMessage(message.chat.id, "<b>Nome:</b> <code>".concat(user.name, "</code>\n<b>Id: </b><code>").concat(user.id, "</code>\n<b>Conta restrita</b>: <code>").concat(user.restrict ? 'sim' : 'não', "</code>\n<b>Saldo: </b><code>R$").concat(user.credits, "</code>\n<b>Cart\xF5es: </b><code>").concat(user.shopping.cards, "</code>\n<b>Gifts: </b><code>").concat(user.shopping.gifts, "</code>\n\n<b>Ranking (Compras e saldo):\n</b><b>Saldo: </b><code>").concat(RANKING.credits.self.position, " de ").concat(RANKING.ranking_total, "</code>\n\n").concat(RANKING.credits.ranking_string, "\n\n<b>Cart\xF5es: </b><code>").concat(RANKING.cards.self.position, " de ").concat(RANKING.ranking_total, "</code>\n\n").concat(RANKING.cards.ranking_string, "\n\n<b>Gifts: </b><code>").concat(RANKING.gifts.self.position, " de ").concat(RANKING.ranking_total, "</code>\n\n").concat(RANKING.gifts.ranking_string), options);
            _context19.next = 24;
            break;
          case 23:
            return _context19.abrupt("return", bot.sendMessage(message.chat.id, "<b>Falha ao executar este comando.</b>\n<b>Poss\xEDves motivos:</b> <i>".concat(validar.message, "</i>"), options));
          case 24:
          case "end":
            return _context19.stop();
        }
      }
    }, _callee18);
  }));
  return function (_x19, _x20) {
    return _ref15.apply(this, arguments);
  };
}());
bot.onText(/^\/limpar (.*)/, /*#__PURE__*/function () {
  var _ref16 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee23(message, match) {
    var DBF, validar, autorizacao, type, _options, types;
    return _regeneratorRuntime().wrap(function _callee23$(_context24) {
      while (1) {
        switch (_context24.prev = _context24.next) {
          case 0:
            _context24.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context24.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context24.sent;
            _context24.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context24.sent;
            type = match[1];
            _options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context24.next = 20;
              break;
            }
            types = {
              todos_os_cartoes: function todos_os_cartoes() {
                return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee19() {
                  var clearCards, updateLevels;
                  return _regeneratorRuntime().wrap(function _callee19$(_context20) {
                    while (1) {
                      switch (_context20.prev = _context20.next) {
                        case 0:
                          _context20.next = 2;
                          return database.Cards.deleteMany({});
                        case 2:
                          clearCards = _context20.sent;
                          _context20.next = 5;
                          return database.Level.updateMany({}, {
                            total_cards: 0
                          });
                        case 5:
                          updateLevels = _context20.sent;
                          bot.sendMessage(message.chat.id, "Todos os cart\xF5es foram removidos.", _options);
                        case 7:
                        case "end":
                          return _context20.stop();
                      }
                    }
                  }, _callee19);
                }))();
              },
              creditos: function creditos() {
                return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee20() {
                  var clearCredits;
                  return _regeneratorRuntime().wrap(function _callee20$(_context21) {
                    while (1) {
                      switch (_context21.prev = _context21.next) {
                        case 0:
                          _context21.next = 2;
                          return database.User.updateMany({}, {
                            credits: 0
                          });
                        case 2:
                          clearCredits = _context21.sent;
                          bot.sendMessage(message.chat.id, "O credito de todos os usu\xE1rios foi zerado.", _options);
                        case 4:
                        case "end":
                          return _context21.stop();
                      }
                    }
                  }, _callee20);
                }))();
              },
              usuarios: function usuarios() {
                return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee21() {
                  return _regeneratorRuntime().wrap(function _callee21$(_context22) {
                    while (1) {
                      switch (_context22.prev = _context22.next) {
                        case 0:
                          bot.sendMessage(message.chat.id, "Comando n\xE3o desenvolvido.", _options);
                        case 1:
                        case "end":
                          return _context22.stop();
                      }
                    }
                  }, _callee21);
                }))();
              },
              cartoes_disponiveis: function cartoes_disponiveis() {
                return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee22() {
                  var clearCards, editLevls;
                  return _regeneratorRuntime().wrap(function _callee22$(_context23) {
                    while (1) {
                      switch (_context23.prev = _context23.next) {
                        case 0:
                          _context23.next = 2;
                          return database.Cards.deleteMany({
                            restrict: false
                          });
                        case 2:
                          clearCards = _context23.sent;
                          _context23.next = 5;
                          return database.Level.updateMany({}, {
                            total_cards: 0
                          });
                        case 5:
                          editLevls = _context23.sent;
                          bot.sendMessage(message.chat.id, "Todos os cart\xF5es dispon\xEDveis foram removidos.", _options);
                        case 7:
                        case "end":
                          return _context23.stop();
                      }
                    }
                  }, _callee22);
                }))();
              }
            };
            if (types[type]) {
              _context24.next = 16;
              break;
            }
            bot.sendMessage(message.chat.id, "Comando n\xE3o existente.", _options);
            _context24.next = 18;
            break;
          case 16:
            _context24.next = 18;
            return types[type]();
          case 18:
            _context24.next = 21;
            break;
          case 20:
            return _context24.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, _options));
          case 21:
            _context24.next = 26;
            break;
          case 23:
            _context24.prev = 23;
            _context24.t0 = _context24["catch"](0);
            console.log(_context24.t0.message);
          case 26:
          case "end":
            return _context24.stop();
        }
      }
    }, _callee23, null, [[0, 23]]);
  }));
  return function (_x21, _x22) {
    return _ref16.apply(this, arguments);
  };
}());
bot.onText(/^\/excluir (.*)/, /*#__PURE__*/function () {
  var _ref17 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee26(message, match) {
    var DBF, validar, autorizacao, _match$1$split3, _match$1$split4, type, value, target, _options2, types;
    return _regeneratorRuntime().wrap(function _callee26$(_context27) {
      while (1) {
        switch (_context27.prev = _context27.next) {
          case 0:
            _context27.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context27.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context27.sent;
            _context27.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context27.sent;
            _match$1$split3 = match[1].split(' '), _match$1$split4 = _toArray(_match$1$split3), type = _match$1$split4[0], value = _match$1$split4.slice(1);
            target = value.join(' ');
            _options2 = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context27.next = 21;
              break;
            }
            types = {
              cartao: function () {
                var _cartao = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee24() {
                  var clearCard;
                  return _regeneratorRuntime().wrap(function _callee24$(_context25) {
                    while (1) {
                      switch (_context25.prev = _context25.next) {
                        case 0:
                          _context25.next = 2;
                          return database.Cards.deleteOne({
                            number: target
                          });
                        case 2:
                          clearCard = _context25.sent;
                          bot.sendMessage(message.chat.id, "Este cart\xE3o foi removido.", _options2);
                        case 4:
                        case "end":
                          return _context25.stop();
                      }
                    }
                  }, _callee24);
                }));
                function cartao() {
                  return _cartao.apply(this, arguments);
                }
                return cartao;
              }(),
              user: function () {
                var _user = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee25() {
                  return _regeneratorRuntime().wrap(function _callee25$(_context26) {
                    while (1) {
                      switch (_context26.prev = _context26.next) {
                        case 0:
                          bot.sendMessage(message.chat.id, "Comando n\xE3o desenvolvido.", _options2);
                        case 1:
                        case "end":
                          return _context26.stop();
                      }
                    }
                  }, _callee25);
                }));
                function user() {
                  return _user.apply(this, arguments);
                }
                return user;
              }()
            };
            if (types[type]) {
              _context27.next = 17;
              break;
            }
            bot.sendMessage(message.chat.id, "Comando n\xE3o existente.", _options2);
            _context27.next = 19;
            break;
          case 17:
            _context27.next = 19;
            return types[type]();
          case 19:
            _context27.next = 22;
            break;
          case 21:
            return _context27.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, _options2));
          case 22:
            _context27.next = 27;
            break;
          case 24:
            _context27.prev = 24;
            _context27.t0 = _context27["catch"](0);
            console.log(_context27.t0.message);
          case 27:
          case "end":
            return _context27.stop();
        }
      }
    }, _callee26, null, [[0, 24]]);
  }));
  return function (_x23, _x24) {
    return _ref17.apply(this, arguments);
  };
}());
bot.onText(/^\/dies/, /*#__PURE__*/function () {
  var _ref18 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee27(message) {
    var options, DBF, validar, autorizacao, dir, cards, cardsString, dieCards;
    return _regeneratorRuntime().wrap(function _callee27$(_context28) {
      while (1) {
        switch (_context28.prev = _context28.next) {
          case 0:
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            DBF = new DataBaseFunctions(database, message);
            _context28.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context28.sent;
            _context28.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context28.sent;
            if (!autorizacao.success) {
              _context28.next = 28;
              break;
            }
            _context28.prev = 9;
            dir = "".concat(__dirname, "/checker/dies/Dies.txt");
            _context28.next = 13;
            return database.Cards.find({
              purshased: process.env.STORE_ID
            }).populate('level');
          case 13:
            cards = _context28.sent;
            cardsString = cards.map(function (card) {
              return "".concat(card.number, "|").concat(card.month, "|").concat(card.year, "|").concat(card.cvv);
            }).join('\n');
            dieCards = "".concat(cardsString.length < 1 ? 'Nada consta' : cardsString);
            require('fs').writeFileSync(dir, dieCards);
            bot.sendChatAction(message.chat.id, 'upload_document');
            bot.sendDocument(message.chat.id, dir, {
              caption: 'Cartões die'
            });

            //require('fs').unlink(dir, (err) => console.log(err))
            _context28.next = 21;
            return database.Cards.deleteMany({
              purshased: process.env.STORE_ID
            });
          case 21:
            _context28.next = 26;
            break;
          case 23:
            _context28.prev = 23;
            _context28.t0 = _context28["catch"](9);
            return _context28.abrupt("return", bot.sendMessage(message.chat.id, '<b>Houve um erro ao executar este comando.</b>', options));
          case 26:
            _context28.next = 29;
            break;
          case 28:
            return _context28.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 29:
          case "end":
            return _context28.stop();
        }
      }
    }, _callee27, null, [[9, 23]]);
  }));
  return function (_x25) {
    return _ref18.apply(this, arguments);
  };
}());
bot.onText(/^\/backup (.*)/, /*#__PURE__*/function () {
  var _ref19 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee30(message, match) {
    var backupType, options, DBF, validar, autorizacao, types;
    return _regeneratorRuntime().wrap(function _callee30$(_context31) {
      while (1) {
        switch (_context31.prev = _context31.next) {
          case 0:
            backupType = match[1].toLowerCase();
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            DBF = new DataBaseFunctions(database, message);
            _context31.next = 5;
            return DBF.user().verificarEadicionar();
          case 5:
            validar = _context31.sent;
            _context31.next = 8;
            return DBF.user().admin();
          case 8:
            autorizacao = _context31.sent;
            if (!autorizacao.success) {
              _context31.next = 24;
              break;
            }
            _context31.prev = 10;
            types = {
              cards: function () {
                var _cards = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee28() {
                  var dir;
                  return _regeneratorRuntime().wrap(function _callee28$(_context29) {
                    while (1) {
                      switch (_context29.prev = _context29.next) {
                        case 0:
                          _context29.next = 2;
                          return DBF.card().backup({
                            restrict: false
                          });
                        case 2:
                          dir = "".concat(__dirname, "/class/card/backup/cards.txt");
                          bot.sendChatAction(message.chat.id, 'upload_document');
                          bot.sendDocument(message.chat.id, dir, {
                            caption: 'Cartões não comprados'
                          });
                        case 5:
                        case "end":
                          return _context29.stop();
                      }
                    }
                  }, _callee28);
                }));
                function cards() {
                  return _cards.apply(this, arguments);
                }
                return cards;
              }(),
              total: function () {
                var _total = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee29() {
                  var dir;
                  return _regeneratorRuntime().wrap(function _callee29$(_context30) {
                    while (1) {
                      switch (_context30.prev = _context30.next) {
                        case 0:
                          _context30.next = 2;
                          return DBF.card().backup({});
                        case 2:
                          dir = "".concat(__dirname, "/class/card/backup/cards.txt");
                          bot.sendChatAction(message.chat.id, 'upload_document');
                          bot.sendDocument(message.chat.id, dir, {
                            caption: 'Todos os cartões'
                          });
                        case 5:
                        case "end":
                          return _context30.stop();
                      }
                    }
                  }, _callee29);
                }));
                function total() {
                  return _total.apply(this, arguments);
                }
                return total;
              }()
            };
            if (types[backupType]) {
              _context31.next = 16;
              break;
            }
            return _context31.abrupt("return", bot.sendMessage(message.chat.id, '<b>Comando inválido.</b>', options));
          case 16:
            types[backupType]();
          case 17:
            _context31.next = 22;
            break;
          case 19:
            _context31.prev = 19;
            _context31.t0 = _context31["catch"](10);
            return _context31.abrupt("return", bot.sendMessage(message.chat.id, '<b>Houve um erro ao executar este comando.</b>', options));
          case 22:
            _context31.next = 25;
            break;
          case 24:
            return _context31.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 25:
          case "end":
            return _context31.stop();
        }
      }
    }, _callee30, null, [[10, 19]]);
  }));
  return function (_x26, _x27) {
    return _ref19.apply(this, arguments);
  };
}());
bot.onText(/^\/recarga (.*)|^\/recarga/, /*#__PURE__*/function () {
  var _ref21 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee32(message, _ref20) {
    var _ref22, match, paymentSettings, pixSettings, _DataBaseFunctions, user, _yield$user$verificar, success, PagSeguroPix, paymentButtonMessages, createButton, notify, rechargeValue, pagseguro, _yield$pagseguro$crea, response, pixQrcode, checkBilling, reviseBilling, pay, _yield$pixQrcode, copyPast, qrCode, register, _yield$bot$sendPhoto, message_id, timer;
    return _regeneratorRuntime().wrap(function _callee32$(_context33) {
      while (1) {
        switch (_context33.prev = _context33.next) {
          case 0:
            _ref22 = _slicedToArray(_ref20, 2), match = _ref22[1];
            paymentSettings = require('./utils/settings').getPaymentSettings();
            pixSettings = require('./utils/settings').pixSettings();
            _DataBaseFunctions = new DataBaseFunctions(database, message), user = _DataBaseFunctions.user;
            _context33.next = 6;
            return user().verificarEadicionar();
          case 6:
            _yield$user$verificar = _context33.sent;
            success = _yield$user$verificar.success;
            PagSeguroPix = require('./payment/pagseguro');
            if (!pixSettings.disablePix) {
              _context33.next = 11;
              break;
            }
            return _context33.abrupt("return", bot.sendMessage(message.chat.id, "Pix automatico desabilitado.\n\n" + "".concat(paymentSettings.lara), {
              parse_mode: 'HTML'
            }));
          case 11:
            paymentButtonMessages = {
              paymentCompleted: '✅ Pagamento concluído',
              paymentCanceled: '🕧 Prazo esgotado'
            };
            createButton = function createButton(paymentMessage, _ref23) {
              var message_id = _ref23.message_id,
                chat = _ref23.chat;
              return {
                message_id: message_id,
                parse_mode: 'HTML',
                chat_id: chat.id,
                reply_markup: {
                  inline_keyboard: [[{
                    text: paymentMessage,
                    callback_data: 'none'
                  }]]
                }
              };
            };
            notify = function notify(value, _ref24) {
              var from = _ref24.from;
              ;
              [-1001800801900].forEach(function (channel) {
                bot.sendMessage(channel, "\uD83D\uDCB2 <b>Recarga realizada!</b>\n\n" + "<b>Usu\xE1rio</b>: <code>".concat(from.first_name, "</code>\n") + "<b>Id:</b> <code>".concat(from.id, "</code>") + "\n<b>Valor:</b> <i>".concat(value, "</i>"), {
                  parse_mode: 'HTML'
                });
              });
            };
            if (success) {
              _context33.next = 16;
              break;
            }
            return _context33.abrupt("return");
          case 16:
            _context33.prev = 16;
            rechargeValue = Number(match).toFixed(2);
            pagseguro = new PagSeguroPix({
              key_cert: __dirname + '/payment/pagseguro/certs/cert.key',
              client_id: '03fc4caa-2d15-11ed-a261-0242ac120002',
              client_secret: '03fc4f5c-2d15-11ed-a261-0242ac120002',
              pem_cert: __dirname + '/payment/pagseguro/certs/cert.pem',
              key: 'b1d31049-9346-4eed-88d0-e4b2b6914e48'
            });
            if (!(rechargeValue < 15 || !/[0-9]+$/.test(rechargeValue))) {
              _context33.next = 21;
              break;
            }
            return _context33.abrupt("return", bot.sendMessage(message.chat.id, '<b>Valor incorreto. faça uma recarga de no mínimo R$10 ou verifique o valor fornecido.</b>', options));
          case 21:
            _context33.t0 = pagseguro;
            _context33.t1 = {
              expiracao: 600
            };
            _context33.t2 = {
              original: rechargeValue
            };
            _context33.t3 = process.env.STORE_NAME;
            _context33.t4 = "R$ ";
            _context33.next = 28;
            return user().informacoes();
          case 28:
            _context33.t5 = _context33.sent.response.credits;
            _context33.t6 = _context33.t4.concat.call(_context33.t4, _context33.t5);
            _context33.t7 = {
              nome: 'Saldo Atual (Store)',
              valor: _context33.t6
            };
            _context33.t8 = [_context33.t7];
            _context33.t9 = {
              calendario: _context33.t1,
              valor: _context33.t2,
              solicitacaoPagador: _context33.t3,
              infoAdicionais: _context33.t8
            };
            _context33.next = 35;
            return _context33.t0.createPixBilling.call(_context33.t0, _context33.t9);
          case 35:
            _yield$pagseguro$crea = _context33.sent;
            response = _yield$pagseguro$crea.response;
            pixQrcode = _yield$pagseguro$crea.pixQrcode;
            checkBilling = _yield$pagseguro$crea.checkBilling;
            reviseBilling = _yield$pagseguro$crea.reviseBilling;
            pay = _yield$pagseguro$crea.pay;
            _context33.next = 43;
            return pixQrcode();
          case 43:
            _yield$pixQrcode = _context33.sent;
            copyPast = _yield$pixQrcode.copyPast;
            qrCode = _yield$pixQrcode.qrCode;
            _context33.next = 48;
            return user().registrarTransacao(response);
          case 48:
            register = _context33.sent;
            if (register.success) {
              _context33.next = 51;
              break;
            }
            throw new Error("Ocorreu um erro ao registrar a transacao: ".concat(register.message));
          case 51:
            _context33.next = 53;
            return bot.sendPhoto(message.chat.id, qrCode, {
              caption: "\u2705 <b> Pagamento criado.</b>\n\n " + "<b>\uD83D\uDCB0 Valor: </b> <i>R$".concat(rechargeValue, "</i>\n") + "<b>\u23F1 Prazo de Pagamento: </b> <i>10 Minutos</i>\n\n" + "\uD83D\uDCA0 <b>Pix \"Copia e Cola\" (QrCode)</b>: <code>".concat(copyPast, "</code>\n\n") + "\uD83D\uDCA1 <b>Dica</b>: <code>Clique no c\xF3digo para copi\xE1-lo</code> \n\n" + "<i>Ap\xF3s o pagamento, seu saldo ser\xE1 creditado automaticamente em no m\xE1ximo 1m</i>",
              reply_markup: {
                inline_keyboard: [[{
                  text: '⏳ Aguardando pagamento',
                  callback_data: 'none'
                }]]
              },
              parse_mode: 'HTML'
            });
          case 53:
            _yield$bot$sendPhoto = _context33.sent;
            message_id = _yield$bot$sendPhoto.message_id;
            timer = /*#__PURE__*/function () {
              var _ref25 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee31() {
                var txid, value, calendario, result, _JSON$parse, status, paymentActions, execute, criacao, expiracao;
                return _regeneratorRuntime().wrap(function _callee31$(_context32) {
                  while (1) {
                    switch (_context32.prev = _context32.next) {
                      case 0:
                        txid = response.txid, value = response.valor.original, calendario = response.calendario;
                        _context32.next = 3;
                        return checkBilling()["catch"](function (err) {
                          return console.log(err);
                        });
                      case 3:
                        result = _context32.sent;
                        _JSON$parse = JSON.parse(result), status = _JSON$parse.status;
                        paymentActions = {
                          CONCLUIDA: function CONCLUIDA() {
                            Promise.all([user().adicionarSaldo(value), user().alterarTransacao(txid, {
                              status: status
                            }), bot.deleteMessage(message.chat.id, message_id)["catch"](console.log), bot.sendMessage(message.from.id, "<b>\uD83E\uDD73 Sua recarga foi creditada!</b>\n\n" + "<b>\uD83D\uDCB0 Valor: </b> <i>R$".concat(value, "</i>\n") + "<b>\uD83C\uDD94 Id da Transa\xE7\xE3o: </b><code>".concat(txid, "</code>\n\n") + "<b>Use </b>/menu <b>para iniciar sua compra.</b>", createButton(paymentButtonMessages.paymentCompleted, message))["catch"](function (e) {
                              return console.log(e.message);
                            })]);
                            notify(value, message);
                          },
                          REMOVIDA_PELO_USUARIO_RECEBEDOR: function REMOVIDA_PELO_USUARIO_RECEBEDOR() {
                            Promise.all([bot.deleteMessage(message.chat.id, message_id)["catch"](function (err) {
                              return err;
                            }), bot.sendMessage(message.chat.id, "<b>\u2639\uFE0F Sua recarga foi cancelada.</b>\n\n" + "<b>\uD83D\uDCB0 Valor: </b> <i>R$".concat(value, "</i>\n"), createButton(paymentButtonMessages.paymentCanceled, message)), user().alterarTransacao(txid, {
                              status: 'EXPIRADO'
                            })]);
                          }
                        };
                        execute = paymentActions[status];
                        criacao = calendario.criacao, expiracao = calendario.expiracao;
                        if (!execute) {
                          _context32.next = 14;
                          break;
                        }
                        _context32.next = 11;
                        return execute();
                      case 11:
                        clearInterval(this);
                        _context32.next = 17;
                        break;
                      case 14:
                        if (!((Date.now() - new Date(criacao).getTime()) / 1000 > expiracao)) {
                          _context32.next = 17;
                          break;
                        }
                        _context32.next = 17;
                        return reviseBilling({
                          status: 'REMOVIDA_PELO_USUARIO_RECEBEDOR'
                        })["catch"](function (err) {
                          return console.log(err);
                        });
                      case 17:
                      case "end":
                        return _context32.stop();
                    }
                  }
                }, _callee31, this);
              }));
              return function timer() {
                return _ref25.apply(this, arguments);
              };
            }();
            setInterval(timer, 15000);
            _context33.next = 63;
            break;
          case 59:
            _context33.prev = 59;
            _context33.t10 = _context33["catch"](16);
            console.log(_context33.t10.message);
            bot.sendMessage(message.chat.id, "N\xE3o foi poss\xEDvel criar seu pagamento.\n\n" + "".concat(paymentSettings.lara), {
              parse_mode: 'HTML'
            });
          case 63:
          case "end":
            return _context33.stop();
        }
      }
    }, _callee32, null, [[16, 59]]);
  }));
  return function (_x28, _x29) {
    return _ref21.apply(this, arguments);
  };
}());
bot.onText(/^\/pix|^\/pix:auto/, /*#__PURE__*/function () {
  var _ref26 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee33(message) {
    var _exec, _exec2, command, _require2, pixSettings, options, DBF, validar, autorizacao, _msg, msg;
    return _regeneratorRuntime().wrap(function _callee33$(_context34) {
      while (1) {
        switch (_context34.prev = _context34.next) {
          case 0:
            _exec = /([A-z:].+)/.exec(message.text), _exec2 = _slicedToArray(_exec, 1), command = _exec2[0];
            _require2 = require('./utils/settings'), pixSettings = _require2.pixSettings;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            DBF = new DataBaseFunctions(database, message);
            _context34.next = 6;
            return DBF.user().verificarEadicionar();
          case 6:
            validar = _context34.sent;
            _context34.next = 9;
            return DBF.user().admin();
          case 9:
            autorizacao = _context34.sent;
            if (!autorizacao.success) {
              _context34.next = 24;
              break;
            }
            _context34.prev = 11;
            if (!(command == 'pix')) {
              _context34.next = 15;
              break;
            }
            _msg = pixSettings().disablePix ? pixSettings('disablePix', false) && '<b>Pix ativado.</b>' : pixSettings('disablePix', true) && '<b>Pix Desativado.</b>';
            return _context34.abrupt("return", bot.sendMessage(message.chat.id, _msg, options));
          case 15:
            msg = pixSettings().autoDisable ? pixSettings('autoDisable', false) && '<b>Auto-desativar pix desativado.</b>' : pixSettings('autoDisable', true) && '<b>Auto-desativar pix ativado.</b>';
            return _context34.abrupt("return", bot.sendMessage(message.chat.id, msg, options));
          case 19:
            _context34.prev = 19;
            _context34.t0 = _context34["catch"](11);
            return _context34.abrupt("return", bot.sendMessage(message.chat.id, '<b>Houve um erro ao executar este comando.</b>', options));
          case 22:
            _context34.next = 25;
            break;
          case 24:
            return _context34.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 25:
          case "end":
            return _context34.stop();
        }
      }
    }, _callee33, null, [[11, 19]]);
  }));
  return function (_x30) {
    return _ref26.apply(this, arguments);
  };
}());
bot.on('text', /*#__PURE__*/function () {
  var _ref27 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee40(message) {
    var messageId, chatId, userId, Checker, checker, finished, DBF, checkerIsActive, isInGroup, options, checkOptions, validar, start, user, cards, response, _cards$response, cardList;
    return _regeneratorRuntime().wrap(function _callee40$(_context41) {
      while (1) {
        switch (_context41.prev = _context41.next) {
          case 0:
            _context41.next = 2;
            return Function.sleep(500);
          case 2:
            messageId = message.message_id;
            chatId = message.chat.id;
            userId = message.from.id;
            Checker = require('./checker');
            checker = new Checker(database);
            finished = false;
            DBF = new DataBaseFunctions(database, message);
            checkerIsActive = /*#__PURE__*/function () {
              var _ref28 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee34() {
                var _yield$DBF$store$sett2, checkerActive;
                return _regeneratorRuntime().wrap(function _callee34$(_context35) {
                  while (1) {
                    switch (_context35.prev = _context35.next) {
                      case 0:
                        _context35.next = 2;
                        return DBF.store().settings.getSettings();
                      case 2:
                        _yield$DBF$store$sett2 = _context35.sent;
                        checkerActive = _yield$DBF$store$sett2.checker;
                        return _context35.abrupt("return", checkerActive);
                      case 5:
                      case "end":
                        return _context35.stop();
                    }
                  }
                }, _callee34);
              }));
              return function checkerIsActive() {
                return _ref28.apply(this, arguments);
              };
            }();
            isInGroup = function isInGroup(id) {
              var test = [].includes(id);
              return test;
            };
            options = {
              reply_to_message_id: messageId,
              parse_mode: 'html'
            };
            checkOptions = {
              reply_to_message_id: messageId,
              parse_mode: 'HTML',
              reply_markup: {
                inline_keyboard: [[{
                  text: '✅ Testar',
                  callback_data: 'iniciarTeste'
                }]]
              }
            };
            _context41.next = 15;
            return DBF.user().verificarEadicionar();
          case 15:
            validar = _context41.sent;
            if (validar.success) {
              _context41.next = 18;
              break;
            }
            return _context41.abrupt("return");
          case 18:
            start = Date.now();
            _context41.next = 21;
            return DBF.user().informacoes();
          case 21:
            user = _context41.sent;
            if (!user.admin) {
              _context41.next = 28;
              break;
            }
            _context41.next = 25;
            return DBF.card().formatarCartoes(message.text, false, false);
          case 25:
            _context41.t0 = _context41.sent;
            _context41.next = 31;
            break;
          case 28:
            _context41.next = 30;
            return DBF.card().formatarCartoes(message.text, false, true);
          case 30:
            _context41.t0 = _context41.sent;
          case 31:
            cards = _context41.t0;
            checkOptions.reply_markup.inline_keyboard.push([{
              text: '❌ Cancelar',
              callback_data: 'cancelarTeste'
            }]);
            response = cards.response;
            if (!cards.success) {
              _context41.next = 44;
              break;
            }
            if (!(response == 'credit card generated')) {
              _context41.next = 39;
              break;
            }
            return _context41.abrupt("return", bot.sendMessage(chatId, "<b>Para de testar gg no bot, filho da puta</b>.", options));
          case 39:
            if (!(user.credits < (cards === null || cards === void 0 ? void 0 : (_cards$response = cards.response) === null || _cards$response === void 0 ? void 0 : _cards$response.length))) {
              _context41.next = 41;
              break;
            }
            return _context41.abrupt("return", bot.sendMessage(chatId, "<b>O seu saldo deve ser maior ou equivalente a quantidade cart\xF5es a serem testados.</b>.", options));
          case 41:
            cardList = cards.response;
            bot.sendMessage(chatId, "<b>Detectei</b> <i>".concat(cardList.length, "</i> <b>").concat(cardList.length > 1 ? 'cartões' : 'cartão', " nesta mensagem.</b>\n\n\u26A0\uFE0F <i>Voc\xEA s\xF3 pode utilizar nosso checker se possuir saldo, cada live ser\xE1 descontado R$1.50 de sua carteira.</i>"), checkOptions);
            //await bot.deleteMessage(message.message_id)

            bot.on('callback_query', /*#__PURE__*/function () {
              var _ref29 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee39(callbackdata) {
                var startCheck, cancelarCheck, callbackMessageId, callbackid, callbackQuery, CheckOptions, _yield$DBF$user$infor2, userInfo, types;
                return _regeneratorRuntime().wrap(function _callee39$(_context40) {
                  while (1) {
                    switch (_context40.prev = _context40.next) {
                      case 0:
                        if (!(callbackdata.message && callbackdata.message.reply_to_message.message_id == messageId && callbackdata.from.id != userId)) {
                          _context40.next = 2;
                          break;
                        }
                        return _context40.abrupt("return", bot.answerCallbackQuery(callbackdata.id, {
                          text: 'Este menu não foi solicitado por você.',
                          show_alert: true
                        }));
                      case 2:
                        if (!(callbackdata.message && callbackdata.message.reply_to_message.message_id == messageId && callbackdata.from.id == userId)) {
                          _context40.next = 24;
                          break;
                        }
                        startCheck = /*#__PURE__*/function () {
                          var _ref30 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee37() {
                            var config, resultArray, processCheckButtons, _processCheckButtons, forceStop, _forceStop, _iterator3, _step3, cardObject, card, bin, _response, creditar, mark, cardsfinal, cardsString;
                            return _regeneratorRuntime().wrap(function _callee37$(_context38) {
                              while (1) {
                                switch (_context38.prev = _context38.next) {
                                  case 0:
                                    _forceStop = function _forceStop3() {
                                      _forceStop = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee36(status, configs) {
                                        return _regeneratorRuntime().wrap(function _callee36$(_context37) {
                                          while (1) {
                                            switch (_context37.prev = _context37.next) {
                                              case 0:
                                                CheckOptions.reply_markup = {
                                                  inline_keyboard: [[{
                                                    text: '✅ Aprovadas',
                                                    callback_data: 'cartoesAprovados'
                                                  }, {
                                                    text: '❌ Reprovadas',
                                                    callback_data: 'cartoesReprovados'
                                                  }], [{
                                                    text: '⚠️ Erros',
                                                    callback_data: 'cartoesErros'
                                                  }]]
                                                };
                                                _context37.next = 3;
                                                return bot.editMessageText("<b>Nome:</b> <code>".concat(userInfo.name, "</code>\n<b>Id: </b><code>").concat(userInfo.id, "</code>\n\n<b>- Total:</b> <i>").concat(configs.total, "</i>\n<b>- Testadas:</b> <i>").concat(configs.tested, "</i>\n<b>- Restantes:</b> <i>").concat(configs.rest, "</i>\n<b>- Aprovadas:</b> <i>").concat(configs.lives, "</i>\n<b>- Reprovadas:</b> <i>").concat(configs.dies, "</i>\n<b>- Erros:</b> <i>").concat(configs.errors, "</i>\n\n<b>\u2699\uFE0F Status</b>: ").concat(status, "\n\n<i>Clique nos bot\xF5es abaixo para fazer o download dos cart\xF5es</i>"), CheckOptions);
                                              case 3:
                                                finished = true;
                                                processCheckButtons();
                                              case 5:
                                              case "end":
                                                return _context37.stop();
                                            }
                                          }
                                        }, _callee36);
                                      }));
                                      return _forceStop.apply(this, arguments);
                                    };
                                    forceStop = function _forceStop2(_x33, _x34) {
                                      return _forceStop.apply(this, arguments);
                                    };
                                    _processCheckButtons = function _processCheckButtons3() {
                                      _processCheckButtons = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee35() {
                                        return _regeneratorRuntime().wrap(function _callee35$(_context36) {
                                          while (1) {
                                            switch (_context36.prev = _context36.next) {
                                              case 0:
                                                bot.on('callback_query', function (data) {
                                                  if (data.message && data.message.reply_to_message.message_id == messageId && data.from.id != userId) return bot.answerCallbackQuery(data.id, {
                                                    text: 'Este menu não foi solicitado por você.',
                                                    show_alert: true
                                                  });
                                                  if (data.message && data.message.reply_to_message.message_id == messageId && data.from.id == userId) {
                                                    try {
                                                      var downlaodTypes = {
                                                        cartoesAprovados: {
                                                          data: resultArray.lives,
                                                          description: 'Cartões live',
                                                          mark: 'APROVADA'
                                                        },
                                                        cartoesReprovados: {
                                                          data: resultArray.dies,
                                                          description: 'Cartões die',
                                                          mark: 'REPROVADA'
                                                        },
                                                        cartoesErros: {
                                                          data: resultArray.errors,
                                                          description: 'Cartões erro',
                                                          mark: 'ERRO'
                                                        }
                                                      };
                                                      if (downlaodTypes[data.data]) {
                                                        var dir = "".concat(__dirname, "/checker/tests/").concat(userId, ".txt");
                                                        var _cardsString = downlaodTypes[data.data].data.map(function (card) {
                                                          return "".concat(downlaodTypes[data.data].mark, " ").concat(card.number, " ").concat(card.month, "/").concat(card.year, " ").concat(card.cvv, " | ").concat(card.bin.scheme, " | ").concat(card.bin.brand ? card.bin.brand : 'DESCONHECIDO', " | ").concat(card.bin.bank ? card.bin.bank.name : 'DESCONHECIDO', " | @AQUARELLA_bot");
                                                        }).join('\n');
                                                        console.log(downlaodTypes[data.data].data);
                                                        var cardsResult = "".concat(_cardsString.length < 1 ? 'Nada consta' : _cardsString);
                                                        require('fs').writeFileSync(dir, cardsResult);
                                                        if (isInGroup(message.chat.id)) return bot.sendMessage(message.chat.id, "".concat(cardsResult, "\n\nTeste de ").concat(userInfo.name));
                                                        bot.sendChatAction(message.from.id, 'upload_document');
                                                        bot.sendDocument(message.from.id, dir, {
                                                          caption: downlaodTypes[data.data].description
                                                        });
                                                      }
                                                    } catch (e) {
                                                      return bot.sendMessage(message.chat.id, '<b>Houve um erro ao executar este comando.</b>', options);
                                                    }
                                                  }
                                                });
                                              case 1:
                                              case "end":
                                                return _context36.stop();
                                            }
                                          }
                                        }, _callee35);
                                      }));
                                      return _processCheckButtons.apply(this, arguments);
                                    };
                                    processCheckButtons = function _processCheckButtons2() {
                                      return _processCheckButtons.apply(this, arguments);
                                    };
                                    _context38.next = 6;
                                    return checkerIsActive();
                                  case 6:
                                    if (_context38.sent) {
                                      _context38.next = 8;
                                      break;
                                    }
                                    return _context38.abrupt("return", bot.answerCallbackQuery(callbackid, {
                                      text: 'Checker indisponível no momento',
                                      show_alert: true
                                    }));
                                  case 8:
                                    config = {
                                      delay: 1,
                                      lives: 0,
                                      dies: 0,
                                      tested: 0,
                                      rest: cardList.length,
                                      total: cardList.length,
                                      errors: 0
                                    };
                                    resultArray = {
                                      dies: [],
                                      lives: [],
                                      errors: []
                                    };
                                    _context38.next = 12;
                                    return bot.editMessageText("<b>Nome:</b> <code>".concat(userInfo.name, "</code>\n<b>Id: </b><code>").concat(userInfo.id, "</code>\n\n<b>- Total:</b> <i>").concat(config.total, "</i>\n<b>- Delay</b>: <i>").concat(config.delay, " (ms)</i>"), CheckOptions);
                                  case 12:
                                    _iterator3 = _createForOfIteratorHelper(cardList);
                                    _context38.prev = 13;
                                    _iterator3.s();
                                  case 15:
                                    if ((_step3 = _iterator3.n()).done) {
                                      _context38.next = 59;
                                      break;
                                    }
                                    cardObject = _step3.value;
                                    card = cardObject.card, bin = cardObject.bin;
                                    card.bin = bin;
                                    console.log(config);
                                    _context38.next = 22;
                                    return checkerIsActive();
                                  case 22:
                                    if (_context38.sent) {
                                      _context38.next = 27;
                                      break;
                                    }
                                    _context38.next = 25;
                                    return bot.answerCallbackQuery(callbackid, {
                                      text: 'Checker indisponível no momento, parando teste...',
                                      show_alert: true
                                    });
                                  case 25:
                                    forceStop('Incompleto (Checker indisponível)', config);
                                    return _context38.abrupt("break", 59);
                                  case 27:
                                    _context38.next = 29;
                                    return Function.sleep(config.delay);
                                  case 29:
                                    _context38.next = 31;
                                    return checker.check(card, false);
                                  case 31:
                                    _response = _context38.sent;
                                    if (!_response.live) {
                                      _context38.next = 53;
                                      break;
                                    }
                                    if (isInGroup(message.chat.id)) {
                                      _context38.next = 39;
                                      break;
                                    }
                                    _context38.next = 36;
                                    return DBF.user().verificarEdeduzirSaldo(1.5);
                                  case 36:
                                    _context38.t0 = _context38.sent;
                                    _context38.next = 40;
                                    break;
                                  case 39:
                                    _context38.t0 = {
                                      success: true
                                    };
                                  case 40:
                                    creditar = _context38.t0;
                                    if (!creditar.success) {
                                      _context38.next = 48;
                                      break;
                                    }
                                    config.lives++;
                                    config.tested++;
                                    config.rest--;
                                    resultArray.lives.push(card);
                                    _context38.next = 51;
                                    break;
                                  case 48:
                                    bot.answerCallbackQuery(callbackid, {
                                      text: 'Saldo insuficiente, parando checker...',
                                      show_alert: true
                                    });
                                    forceStop('Incompleto (Creditos Insuficientes)', config);
                                    return _context38.abrupt("break", 59);
                                  case 51:
                                    _context38.next = 57;
                                    break;
                                  case 53:
                                    config.dies++;
                                    config.tested++;
                                    config.rest--;
                                    resultArray.dies.push(card);
                                  case 57:
                                    _context38.next = 15;
                                    break;
                                  case 59:
                                    _context38.next = 64;
                                    break;
                                  case 61:
                                    _context38.prev = 61;
                                    _context38.t1 = _context38["catch"](13);
                                    _iterator3.e(_context38.t1);
                                  case 64:
                                    _context38.prev = 64;
                                    _iterator3.f();
                                    return _context38.finish(64);
                                  case 67:
                                    CheckOptions.reply_markup = {
                                      inline_keyboard: [[{
                                        text: '✅ Aprovadas',
                                        callback_data: 'cartoesAprovados'
                                      }, {
                                        text: '❌ Reprovadas',
                                        callback_data: 'cartoesReprovados'
                                      }], [{
                                        text: '⚠️ Erros',
                                        callback_data: 'cartoesErros'
                                      }]]
                                    };
                                    if (!(config.total == config.tested)) {
                                      _context38.next = 79;
                                      break;
                                    }
                                    cardsfinal = resultArray.dies.length > 0 ? (mark = 'REPROVADA', resultArray.dies) : resultArray.lives.length > 0 ? (mark = 'APROVADA', resultArray.lives) : (mark = 'ERROR', resultArray.errors);
                                    cardsString = cardsfinal.map(function (card) {
                                      return "<b>".concat(mark, "</b> <code>").concat(card.number, "</code> <code>").concat(card.month, "</code>/<code>").concat(card.year, "</code> <code>").concat(card.cvv, "</code> <b>| ").concat(card.bin.scheme, " | ").concat(card.bin.brand ? card.bin.brand : 'DESCONHECIDO', " | ").concat(card.bin.bank ? card.bin.bank.name : 'DESCONHECIDO', " | @AQUARELLA_bot </b>");
                                    }).join('\n');
                                    finished = true;
                                    if (!isInGroup(message.chat.id)) {
                                      _context38.next = 76;
                                      break;
                                    }
                                    bot.editMessageText(cardsString, {
                                      chat_id: chatId,
                                      message_id: callbackMessageId,
                                      parse_mode: 'html'
                                    });
                                    _context38.next = 79;
                                    break;
                                  case 76:
                                    _context38.next = 78;
                                    return bot.editMessageText("<b>Nome:</b> <code>".concat(userInfo.name, "</code>\n<b>Id: </b><code>").concat(userInfo.id, "</code>\n\n<b>- Total:</b> <i>").concat(config.total, "</i>\n<b>- Testadas:</b> <i>").concat(config.tested, "</i>\n<b>- Restantes:</b> <i>").concat(config.rest, "</i>\n<b>- Aprovadas:</b> <i>").concat(config.lives, "</i>\n<b>- Reprovadas:</b> <i>").concat(config.dies, "</i>\n<b>- Erros:</b> <i>").concat(config.errors, "</i>\n\n<b>\u2699\uFE0F Status: </b><b>Finalizado</b>\n\n<i>Clique nos bot\xF5es abaixo para fazer o download dos cart\xF5es</i>"), CheckOptions);
                                  case 78:
                                    processCheckButtons();
                                  case 79:
                                  case "end":
                                    return _context38.stop();
                                }
                              }
                            }, _callee37, null, [[13, 61, 64, 67]]);
                          }));
                          return function startCheck() {
                            return _ref30.apply(this, arguments);
                          };
                        }();
                        cancelarCheck = /*#__PURE__*/function () {
                          var _ref31 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee38() {
                            return _regeneratorRuntime().wrap(function _callee38$(_context39) {
                              while (1) {
                                switch (_context39.prev = _context39.next) {
                                  case 0:
                                    CheckOptions.reply_markup = undefined;
                                    bot.removeListener('callback_query', function (success) {
                                      return success;
                                    });
                                    return _context39.abrupt("return", bot.editMessageText("<b>Opera\xE7\xE3o cancelada.</b>", CheckOptions));
                                  case 3:
                                  case "end":
                                    return _context39.stop();
                                }
                              }
                            }, _callee38);
                          }));
                          return function cancelarCheck() {
                            return _ref31.apply(this, arguments);
                          };
                        }();
                        callbackMessageId = callbackdata.message.message_id;
                        callbackid = callbackdata.id;
                        callbackQuery = callbackdata.data;
                        if (!(isInGroup(message.chat.id) && cardList.length > 1)) {
                          _context40.next = 12;
                          break;
                        }
                        _context40.next = 11;
                        return bot.editMessageText("<b>Sua lista deve conter no m\xE1ximo 1 cart\xE3o.</b>", {
                          chat_id: chatId,
                          message_id: callbackMessageId,
                          parse_mode: 'html'
                        });
                      case 11:
                        return _context40.abrupt("return", _context40.sent);
                      case 12:
                        CheckOptions = {
                          chat_id: chatId,
                          message_id: callbackMessageId,
                          parse_mode: 'html',
                          reply_markup: {
                            inline_keyboard: [[{
                              text: '⏳  Testando...',
                              callback_data: 'none'
                            }]]
                          }
                        };
                        _context40.next = 15;
                        return DBF.user().informacoes();
                      case 15:
                        _yield$DBF$user$infor2 = _context40.sent;
                        userInfo = _yield$DBF$user$infor2.response;
                        if (finished) {
                          _context40.next = 20;
                          break;
                        }
                        if (!(!isInGroup(message.chat.id) && userInfo.credits < 1)) {
                          _context40.next = 20;
                          break;
                        }
                        return _context40.abrupt("return", bot.answerCallbackQuery(callbackid, {
                          text: 'Saldo insuficiente.',
                          show_alert: true
                        }));
                      case 20:
                        types = {
                          iniciarTeste: function iniciarTeste() {
                            return startCheck();
                          },
                          cancelarTeste: function cancelarTeste() {
                            return cancelarCheck();
                          }
                        };
                        if (!types[callbackQuery]) {
                          _context40.next = 24;
                          break;
                        }
                        _context40.next = 24;
                        return types[callbackQuery]();
                      case 24:
                      case "end":
                        return _context40.stop();
                    }
                  }
                }, _callee39);
              }));
              return function (_x32) {
                return _ref29.apply(this, arguments);
              };
            }());
          case 44:
          case "end":
            return _context41.stop();
        }
      }
    }, _callee40);
  }));
  return function (_x31) {
    return _ref27.apply(this, arguments);
  };
}());
bot.onText(/^\/retirar (.*)/, /*#__PURE__*/function () {
  var _ref32 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee43(message, match) {
    var options, DBF, validar, autorizacao, dir, types, config, getCards, cards, caption;
    return _regeneratorRuntime().wrap(function _callee43$(_context44) {
      while (1) {
        switch (_context44.prev = _context44.next) {
          case 0:
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            DBF = new DataBaseFunctions(database, message);
            _context44.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context44.sent;
            _context44.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context44.sent;
            if (!autorizacao.success) {
              _context44.next = 30;
              break;
            }
            _context44.prev = 9;
            dir = "".concat(__dirname, "/class/card/retirar/cards.txt");
            types = {
              bin: function bin(config) {
                return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee41() {
                  var _yield$DBF$card$retir, cards;
                  return _regeneratorRuntime().wrap(function _callee41$(_context42) {
                    while (1) {
                      switch (_context42.prev = _context42.next) {
                        case 0:
                          _context42.next = 2;
                          return DBF.card().retirar({
                            'bin.bin': config.bin,
                            restrict: false
                          }, parseInt(config.qntd));
                        case 2:
                          _yield$DBF$card$retir = _context42.sent;
                          cards = _yield$DBF$card$retir.cards;
                          return _context42.abrupt("return", cards);
                        case 5:
                        case "end":
                          return _context42.stop();
                      }
                    }
                  }, _callee41);
                }))();
              },
              level: function level(config) {
                return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee42() {
                  var _yield$DBF$card$retir2, cards;
                  return _regeneratorRuntime().wrap(function _callee42$(_context43) {
                    while (1) {
                      switch (_context43.prev = _context43.next) {
                        case 0:
                          _context43.next = 2;
                          return DBF.card().retirar({
                            'bin.brand': config.level,
                            restrict: false
                          }, parseInt(config.qntd));
                        case 2:
                          _yield$DBF$card$retir2 = _context43.sent;
                          cards = _yield$DBF$card$retir2.cards;
                          return _context43.abrupt("return", cards);
                        case 5:
                        case "end":
                          return _context43.stop();
                      }
                    }
                  }, _callee42);
                }))();
              }
            };
            config = {};
            if (!parseInt(match[1].replace(/\s+/g, ''))) config = {
              type: 'level',
              level: match[1].replace(/[^a-zA-Z\s?]/g, '').trim(),
              qntd: match[1].replace(/[^0-9]/g, '')
            };else {
              config = {
                type: 'bin',
                bin: match[1].split(' ')[0].trim(),
                qntd: match[1].split(' ')[1]
              };
            }
            console.log(config);
            getCards = types[config.type];
            _context44.next = 18;
            return getCards(config);
          case 18:
            cards = _context44.sent;
            caption = cards.length > 0 ? {
              caption: "".concat(cards.length, " ").concat(cards.length > 1 ? 'Cartões' : 'Cartão', " da(o) ").concat(config.type, " ").concat(config[config.type], " por R$").concat(cards.reduce(function (acc, curr) {
                return acc + parseInt(curr.level.price);
              }, 0))
            } : {
              caption: "Cart\xE7\xF5es da(o) ".concat(config.type, " ").concat(config[config.type], " ")
            };
            bot.sendChatAction(message.chat.id, 'upload_document');
            bot.sendDocument(message.chat.id, dir, caption);
            _context44.next = 28;
            break;
          case 24:
            _context44.prev = 24;
            _context44.t0 = _context44["catch"](9);
            console.log(_context44.t0);
            return _context44.abrupt("return", bot.sendMessage(message.chat.id, '<b>Houve um erro ao executar este comando.</b>', options));
          case 28:
            _context44.next = 31;
            break;
          case 30:
            return _context44.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 31:
          case "end":
            return _context44.stop();
        }
      }
    }, _callee43, null, [[9, 24]]);
  }));
  return function (_x35, _x36) {
    return _ref32.apply(this, arguments);
  };
}());
bot.onText(/^\/manutencao/, /*#__PURE__*/function () {
  var _ref33 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee44(message, match) {
    var DBF, validar, autorizacao, options, _yield$bot$sendMessag5, message_id, _yield$DBF$store$setT, test_mode, success, storeTestModeMessage;
    return _regeneratorRuntime().wrap(function _callee44$(_context45) {
      while (1) {
        switch (_context45.prev = _context45.next) {
          case 0:
            _context45.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context45.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context45.sent;
            _context45.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context45.sent;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context45.next = 23;
              break;
            }
            _context45.next = 12;
            return bot.sendMessage(message.chat.id, "\uD83D\uDD04 <b> Configurando modo de testes...</b>", options);
          case 12:
            _yield$bot$sendMessag5 = _context45.sent;
            message_id = _yield$bot$sendMessag5.message_id;
            _context45.next = 16;
            return DBF.store().setTestMode();
          case 16:
            _yield$DBF$store$setT = _context45.sent;
            test_mode = _yield$DBF$store$setT.test_mode;
            success = _yield$DBF$store$setT.success;
            storeTestModeMessage = test_mode ? "\u2705 <b>Modo teste ativado com sucesso.</b>" : "\u2705 <b>Modo teste desativado com sucesso.</b>";
            if (success) {
              bot.editMessageText(storeTestModeMessage, {
                message_id: message_id,
                chat_id: message.chat.id,
                parse_mode: 'HTML'
              });
            } else {
              bot.editMessageText('<b>Falha ao executar este comando</b>', {
                message_id: message_id,
                chat_id: message.chat.id,
                parse_mode: 'HTML'
              });
            }
            _context45.next = 24;
            break;
          case 23:
            return _context45.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 24:
            _context45.next = 29;
            break;
          case 26:
            _context45.prev = 26;
            _context45.t0 = _context45["catch"](0);
            console.log(_context45.t0.message);
          case 29:
          case "end":
            return _context45.stop();
        }
      }
    }, _callee44, null, [[0, 26]]);
  }));
  return function (_x37, _x38) {
    return _ref33.apply(this, arguments);
  };
}());
bot.onText(/^\/falselive/, /*#__PURE__*/function () {
  var _ref34 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee45(message) {
    var DBF, validar, autorizacao, options, _yield$bot$sendMessag6, message_id, _require$readFileSync, _require$readFileSync2, falselive, falseLiveModeText;
    return _regeneratorRuntime().wrap(function _callee45$(_context46) {
      while (1) {
        switch (_context46.prev = _context46.next) {
          case 0:
            _context46.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context46.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context46.sent;
            _context46.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context46.sent;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            if (!autorizacao.success) {
              _context46.next = 20;
              break;
            }
            _context46.next = 12;
            return bot.sendMessage(message.chat.id, "\uD83D\uDD04 <b> Configurando modo de false live...</b>", options);
          case 12:
            _yield$bot$sendMessag6 = _context46.sent;
            message_id = _yield$bot$sendMessag6.message_id;
            _require$readFileSync = require('fs').readFileSync(__dirname + '/checker/presets.txt', 'utf-8').split('='), _require$readFileSync2 = _slicedToArray(_require$readFileSync, 2), falselive = _require$readFileSync2[1];
            if (falselive.trim() == 'false') {
              require('fs').writeFileSync(__dirname + '/checker/presets.txt', 'FALSE_LIVE = true');
            } else {
              require('fs').writeFileSync(__dirname + '/checker/presets.txt', 'FALSE_LIVE = false');
            }
            falseLiveModeText = falselive.trim() == 'false' ? "\u2705 <b>Modo false live ativado com sucesso.</b>" : "\u2705 <b>Modo false live desativado com sucesso.</b>";
            if (autorizacao.success) {
              bot.editMessageText(falseLiveModeText, {
                message_id: message_id,
                chat_id: message.chat.id,
                parse_mode: 'HTML'
              });
            } else {
              bot.editMessageText('<b>Falha ao executar este comando</b>', {
                message_id: message_id,
                chat_id: message.chat.id,
                parse_mode: 'HTML'
              });
            }
            _context46.next = 21;
            break;
          case 20:
            return _context46.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 21:
            _context46.next = 26;
            break;
          case 23:
            _context46.prev = 23;
            _context46.t0 = _context46["catch"](0);
            console.log(_context46.t0.message);
          case 26:
          case "end":
            return _context46.stop();
        }
      }
    }, _callee45, null, [[0, 23]]);
  }));
  return function (_x39) {
    return _ref34.apply(this, arguments);
  };
}());
bot.onText(/^\/checker/, /*#__PURE__*/function () {
  var _ref35 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee46(message) {
    var DBF, validar, autorizacao, options, Checker, checker, _yield$bot$sendMessag7, message_id, response;
    return _regeneratorRuntime().wrap(function _callee46$(_context47) {
      while (1) {
        switch (_context47.prev = _context47.next) {
          case 0:
            _context47.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context47.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context47.sent;
            _context47.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context47.sent;
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            }; //
            if (!autorizacao.success) {
              _context47.next = 35;
              break;
            }
            Checker = require('./checker');
            checker = new Checker(database);
            _context47.next = 14;
            return bot.sendMessage(message.chat.id, "\uD83D\uDD04 <b> Verificando status do checker...</b>", options);
          case 14:
            _yield$bot$sendMessag7 = _context47.sent;
            message_id = _yield$bot$sendMessag7.message_id;
            _context47.next = 18;
            return checker.testChecker();
          case 18:
            response = _context47.sent;
            if (!response.success) {
              _context47.next = 23;
              break;
            }
            bot.editMessageText("\uD83D\uDCC3 <b>Diagnostico do checker</b>\n\n\u2699\uFE0F <b>Status</b>: <code>Ativo</code>", {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
            _context47.next = 33;
            break;
          case 23:
            _context47.next = 25;
            return bot.editMessageText("\u2699\uFE0F <b>Status</b>: <code>Inativo</code>", {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
          case 25:
            _context47.next = 27;
            return Function.sleep(5000);
          case 27:
            _context47.next = 29;
            return bot.editMessageText("\uD83D\uDD04 <b>Tentando reativar checker...</b>", {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
          case 29:
            _context47.next = 31;
            return checker.testChecker();
          case 31:
            response = _context47.sent;
            bot.editMessageText("\uD83D\uDCC3 <b>Diagnostico do checker</b>\n\n\u2699\uFE0F <b>Status</b>: <code>Inativo > ".concat(response.success ? 'Ativo' : 'Inativo', "</code>"), {
              message_id: message_id,
              chat_id: message.chat.id,
              parse_mode: 'HTML'
            });
          case 33:
            _context47.next = 36;
            break;
          case 35:
            return _context47.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 36:
            _context47.next = 41;
            break;
          case 38:
            _context47.prev = 38;
            _context47.t0 = _context47["catch"](0);
            console.log(_context47.t0.message);
          case 41:
          case "end":
            return _context47.stop();
        }
      }
    }, _callee46, null, [[0, 38]]);
  }));
  return function (_x40) {
    return _ref35.apply(this, arguments);
  };
}());
bot.onText(/^\/lara/, /*#__PURE__*/function () {
  var _ref36 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee47(message) {
    var DBF, validar, autorizacao, _require3, editPaymentMessage, text, options;
    return _regeneratorRuntime().wrap(function _callee47$(_context48) {
      while (1) {
        switch (_context48.prev = _context48.next) {
          case 0:
            _context48.prev = 0;
            DBF = new DataBaseFunctions(database, message);
            _context48.next = 4;
            return DBF.user().verificarEadicionar();
          case 4:
            validar = _context48.sent;
            _context48.next = 7;
            return DBF.user().admin();
          case 7:
            autorizacao = _context48.sent;
            _require3 = require('./utils/settings'), editPaymentMessage = _require3.editPaymentMessage;
            text = message.text.replace('/lara', '').trim();
            options = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            }; //
            if (!autorizacao.success) {
              _context48.next = 17;
              break;
            }
            editPaymentMessage(text);
            _context48.next = 15;
            return bot.sendMessage(message.chat.id, "\u2705 <b>Lara alterada com sucesso.</b>", options);
          case 15:
            _context48.next = 18;
            break;
          case 17:
            return _context48.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, options));
          case 18:
            _context48.next = 23;
            break;
          case 20:
            _context48.prev = 20;
            _context48.t0 = _context48["catch"](0);
            console.log(_context48.t0.message);
          case 23:
          case "end":
            return _context48.stop();
        }
      }
    }, _callee47, null, [[0, 20]]);
  }));
  return function (_x41) {
    return _ref36.apply(this, arguments);
  };
}());
bot.onText(/\/relatorio (.*)/, /*#__PURE__*/function () {
  var _ref37 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee48(message, match) {
    var _yield$bot$getMe, botId, DBF, validar, _options3, relatoryDate, relatoryInfoDate, _match$1$split5, _match$1$split6, day, month, autorizacao, allTransactions, transactionsToday, newUsersToday, cards, cardsPurshasedToday, totalVendido, totalComprado, date, addZero, todayDate;
    return _regeneratorRuntime().wrap(function _callee48$(_context49) {
      while (1) {
        switch (_context49.prev = _context49.next) {
          case 0:
            _context49.next = 2;
            return bot.getMe();
          case 2:
            _yield$bot$getMe = _context49.sent;
            botId = _yield$bot$getMe.id;
            _context49.prev = 4;
            DBF = new DataBaseFunctions(database, message);
            _context49.next = 8;
            return DBF.user().verificarEadicionar();
          case 8:
            validar = _context49.sent;
            _options3 = {
              reply_to_message_id: message.message_id,
              parse_mode: 'html'
            };
            relatoryInfoDate = {};
            if (match[1].trim() == '/') {
              relatoryDate = "".concat(new Date().getUTCDate(), "/").concat(new Date().getUTCMonth());
              relatoryInfoDate.day = new Date().getUTCDate();
              relatoryInfoDate.month = new Date().getUTCMonth();
            } else {
              _match$1$split5 = match[1].split('/'), _match$1$split6 = _slicedToArray(_match$1$split5, 2), day = _match$1$split6[0], month = _match$1$split6[1];
              relatoryInfoDate.day = parseInt(day);
              relatoryInfoDate.month = parseInt(month) - 1;
              relatoryDate = "".concat(parseInt(day), "/").concat(parseInt(month) - 1);
            }
            if (validar.success) {
              _context49.next = 14;
              break;
            }
            return _context49.abrupt("return", bot.sendMessage(message.chat.id, "<b>Falha ao executar este comando.</b>\n<b>Poss\xEDves motivos:</b> <i>".concat(validar.message, "</i>"), {
              parse_mode: 'HTML'
            }));
          case 14:
            _context49.next = 16;
            return DBF.user().admin();
          case 16:
            autorizacao = _context49.sent;
            if (!autorizacao.success) {
              _context49.next = 39;
              break;
            }
            _context49.next = 20;
            return database.Transactions.find({
              status: 'CONCLUIDA'
            }, 'status value createdAt');
          case 20:
            allTransactions = _context49.sent;
            transactionsToday = allTransactions.filter(function (transaction) {
              var transactionDate = new Date(transaction.createdAt);
              var todayDate = new Date();
              var monthAndDayTransaction = "".concat(transactionDate.getUTCDate(), "/").concat(transactionDate.getUTCMonth());
              var monthAndDayToday = "".concat(todayDate.getUTCMonth(), "/").concat(todayDate.getUTCDate());
              console.log(monthAndDayTransaction);
              return monthAndDayTransaction == relatoryDate;
            });
            _context49.next = 24;
            return database.User.find({}, 'createdAt');
          case 24:
            newUsersToday = _context49.sent;
            newUsersToday = newUsersToday.filter(function (user) {
              return relatoryDate == "".concat(new Date(user.createdAt).getUTCDate(), "/").concat(new Date(user.createdAt).getUTCMonth());
            });
            _context49.next = 28;
            return database.Cards.find({
              restrict: true
            }).populate('level');
          case 28:
            cards = _context49.sent;
            cardsPurshasedToday = cards.filter(function (card) {
              return card.purshased != 0 && card.purshased != botId && "".concat(new Date(card.updatedAt).getUTCDate(), "/").concat(new Date(card.updatedAt).getUTCMonth()) == relatoryDate;
            });
            totalVendido = transactionsToday.length >= 1 ? transactionsToday.reduce(function (acc, curr) {
              return acc + curr.value;
            }, 0) : 0;
            totalComprado = cardsPurshasedToday.length >= 1 ? cardsPurshasedToday.reduce(function (acc, curr) {
              return acc + parseInt(curr.level.price);
            }, 0) : 0;
            console.log('total vendido hoje: ', 'R$' + totalVendido);
            date = new Date();
            addZero = function addZero(num) {
              return num < 10 ? "0".concat(num) : num;
            };
            todayDate = "".concat(date.getDate(), "/").concat(addZero(date.getMonth() + 1), "/").concat(date.getFullYear(), " ").concat(addZero(date.getHours()), ":").concat(addZero(date.getMinutes()), ":").concat(addZero(date.getSeconds()));
            bot.sendMessage(message.chat.id, "\uD83D\uDCCB <b>Relat\xF3rio - ".concat(addZero(relatoryInfoDate.day), "/").concat(addZero(relatoryInfoDate.month + 1), "/").concat(date.getFullYear(), "</b>\n\n<b>\uD83D\uDC64 Novos usu\xE1rios:</b> <code>").concat(newUsersToday.length, "</code>\n\uD83E\uDD1D <b>Vendas:</b> <code>").concat(transactionsToday.length, "</code>\n\uD83D\uDED2 <b>Compras:</b> <code>").concat(cardsPurshasedToday.length, "</code>\n\uD83D\uDCB0 <b>Total em vendas:</b> <code>R$").concat(totalVendido, "</code>\n\uD83D\uDCB8 <b>Total em compras:</b> <code>R$").concat(totalComprado, "</code>\n\n\uD83D\uDDD3 <b>Data de hoje: </b><code>").concat(todayDate, "</code>"), _options3);
            _context49.next = 40;
            break;
          case 39:
            return _context49.abrupt("return", bot.sendMessage(message.chat.id, autorizacao.message, _options3));
          case 40:
            _context49.next = 45;
            break;
          case 42:
            _context49.prev = 42;
            _context49.t0 = _context49["catch"](4);
            console.log(_context49.t0);
          case 45:
          case "end":
            return _context49.stop();
        }
      }
    }, _callee48, null, [[4, 42]]);
  }));
  return function (_x42, _x43) {
    return _ref37.apply(this, arguments);
  };
}());
/*
    bot.onTex(t/\/relatorio (.*)/, async (message, match) => {
        const { id: botId } = await bot.getMe()
        const { user } = new DataBaseFunctions(database, message)
        const { Transactions, User, Cards } = database

        const validate = await user().verificarEadicionar()
        const options = {
            reply_to_message_id: message.message_id,
            parse_mode: 'html'
        }
        const auth = await DBF.user().admin()

        if(!auth.success)
            return bot.sendMessage(
                message.chat.id, 
                auth.message, 
                options
            )

        const [, match] = match
        const config = new Object

        const transactions = await Transactions.find({ status: 'CONCLUIDA' },
            'status value createdAt'
        )
        const users = await User.find('createdAt')
        const cards = await Cards.find({ restrict: true })
                .populate('level')

        const breaks = {
            year(){

            },
            month(){

            },
            week(){

            },
            day(){

            }
        }

        if(match.includes('/')){

        }
    })
*/
bot.onText(/\/mix (.*)/, /*#__PURE__*/function () {
  var _ref39 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee49(_ref38) {
    var from, message_id, chat, input, _DataBaseFunctions2, user, auth, inputList, Mix, options, _iterator4, _step4, line, match, filterMatch, _filterMatch, description, quantity, levels, exchange_time, live_percentage, price, mix_id, mix, exists, MixModel, save;
    return _regeneratorRuntime().wrap(function _callee49$(_context50) {
      while (1) {
        switch (_context50.prev = _context50.next) {
          case 0:
            from = _ref38.from, message_id = _ref38.message_id, chat = _ref38.chat, input = _ref38.text;
            _DataBaseFunctions2 = new DataBaseFunctions(database, {
              from: from
            }), user = _DataBaseFunctions2.user;
            _context50.next = 4;
            return user().verificarEadicionar();
          case 4:
            _context50.next = 6;
            return user().admin();
          case 6:
            auth = _context50.sent;
            if (auth.success) {
              _context50.next = 9;
              break;
            }
            return _context50.abrupt("return");
          case 9:
            inputList = input.replace('/mix', '').split('\n');
            Mix = database.Mix; //return await Mix.deleteMany{(})
            options = {
              parse_mode: 'HTML',
              reply_to_message_id: message_id
            };
            _iterator4 = _createForOfIteratorHelper(inputList);
            _context50.prev = 13;
            _iterator4.s();
          case 15:
            if ((_step4 = _iterator4.n()).done) {
              _context50.next = 42;
              break;
            }
            line = _step4.value;
            match = /([\w\s]+)\(([0-9]+)\)\[([A-z,\s?]+)\]\:([\w\s?]+)\|([\d{1,100}\s?]+)\=([\d\s?\.?]+)\-([\w\s]+)/g.exec(line);
            if (match) {
              _context50.next = 20;
              break;
            }
            return _context50.abrupt("return", bot.sendMessage(chat.id, "<b>Formato incorreto.</b>", options));
          case 20:
            filterMatch = match.map(function (element) {
              var _element$trim;
              return element === null || element === void 0 ? void 0 : (_element$trim = element.trim) === null || _element$trim === void 0 ? void 0 : _element$trim.call(element);
            }).filter(function (element) {
              return element || undefined;
            });
            if (!(filterMatch.length != 8)) {
              _context50.next = 23;
              break;
            }
            return _context50.abrupt("return", bot.sendMessage(chat.id, "<b>Esta faltando algo. Revise o comando, e tente novamente.\n" + "Formato: <i>D (Q)[N, N]: TT | GL = P - ID</i>\n\n" + "D: Descricao (Numeros/Letras): Texto que ser\xE1 exibido no bot\xE3o\n" + "Q: Quantidade (Numeros): Quantidade da mix\n" + "N: Niveis (Letras): Niveis que ser\xE3o selecionados \n" + "TT: Tempo de troca (Numeros/Letras): Tempo de troca da mix\n" + "GL: Garantia de live (Numeros): Garantia de live da mix\n" + "P: Pre\xE7o (Numeros): Pre\xE7o da mix \n" + "ID: Identificador da mix (Numeros/Letras): Indetificador \xFAnico</b>\n\n" + "<b>Exemplo de uso: </b><code>/mix  100 Mix (100)[classic, standard]: 2 dias | 80 = 400 - Minha mix 1</code>\n\n" + "<b>Coloque os nomes dos niveis atenciosamente, pois um erro na escrita, ocasionar\xE1 a n\xE3o sele\xE7\xE3o de tal nivel.</b>" + "<b>Utilize sempre IDs unicos para cada mix, ao utilizar um j\xE1 existente, a mix anexada ao mesmo ser\xE1 sobrescrevida com as configura\xE7\xF5es atuais.</b>", options));
          case 23:
            _filterMatch = _slicedToArray(filterMatch, 8), description = _filterMatch[1], quantity = _filterMatch[2], levels = _filterMatch[3], exchange_time = _filterMatch[4], live_percentage = _filterMatch[5], price = _filterMatch[6], mix_id = _filterMatch[7];
            mix = {
              mix_id: mix_id,
              price: price,
              description: description,
              quantity: Number(quantity),
              levels: !levels.toLowerCase().includes('todos') ? levels.toUpperCase().split(',').map(function (level) {
                return level.trim();
              }) : [],
              exchange_time: exchange_time,
              live_percentage: Number(live_percentage)
            };
            _context50.next = 27;
            return Mix.exists({
              mix_id: mix_id
            });
          case 27:
            exists = _context50.sent;
            if (!exists) {
              _context50.next = 36;
              break;
            }
            _context50.next = 31;
            return Mix.findOneAndUpdate({
              mix_id: mix_id
            }, {
              price: price,
              description: description,
              quantity: Number(quantity),
              levels: !levels.toLowerCase().includes('todos') ? levels.toUpperCase().split(',').map(function (level) {
                return level.trim();
              }) : [],
              exchange_time: exchange_time,
              live_percentage: Number(live_percentage)
            });
          case 31:
            if (!(inputList.length == 1)) {
              _context50.next = 35;
              break;
            }
            return _context50.abrupt("return", bot.sendMessage(chat.id, "Mix atualizada com sucesso."));
          case 35:
            return _context50.abrupt("continue", 40);
          case 36:
            MixModel = new Mix(mix);
            _context50.next = 39;
            return MixModel.save();
          case 39:
            save = _context50.sent;
          case 40:
            _context50.next = 15;
            break;
          case 42:
            _context50.next = 47;
            break;
          case 44:
            _context50.prev = 44;
            _context50.t0 = _context50["catch"](13);
            _iterator4.e(_context50.t0);
          case 47:
            _context50.prev = 47;
            _iterator4.f();
            return _context50.finish(47);
          case 50:
            bot.sendMessage(chat.id, "Mix(s) adicionada(s) com sucesso.");
          case 51:
          case "end":
            return _context50.stop();
        }
      }
    }, _callee49, null, [[13, 44, 47, 50]]);
  }));
  return function (_x44) {
    return _ref39.apply(this, arguments);
  };
}());
function panel(_x45) {
  return _panel.apply(this, arguments);
}
function _panel() {
  _panel = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee57(message) {
    var _message$message$chat, _message$message;
    var DBF, auth, chat, keyboard, text, panelOther;
    return _regeneratorRuntime().wrap(function _callee57$(_context58) {
      while (1) {
        switch (_context58.prev = _context58.next) {
          case 0:
            DBF = new DataBaseFunctions(database, message);
            _context58.next = 3;
            return DBF.user().admin();
          case 3:
            auth = _context58.sent;
            chat = (_message$message$chat = message === null || message === void 0 ? void 0 : (_message$message = message.message) === null || _message$message === void 0 ? void 0 : _message$message.chat) !== null && _message$message$chat !== void 0 ? _message$message$chat : message === null || message === void 0 ? void 0 : message.chat;
            if (!(!auth.success && chat.type != 'private')) {
              _context58.next = 7;
              break;
            }
            return _context58.abrupt("return");
          case 7:
            keyboard = new InlineKeyboard().text('⚙️ Checker', "panel-checker")
            //.text('🏦 Pagamentos', 'panel-payments')
            .row().text('❌ Deletar', 'delete-message');
            text = "<b>Bem vindo ao painel de gest\xE3o</b>\n\n" + "<b>Clique na op\xE7\xE3o que desejada</>:";
            panelOther = {
              reply_markup: keyboard,
              parse_mode: 'HTML'
            };
            _context58.next = 12;
            return bot.sendMessage(chat.id, text, panelOther);
          case 12:
          case "end":
            return _context58.stop();
        }
      }
    }, _callee57);
  }));
  return _panel.apply(this, arguments);
}
bot.onText(/\/painel/, panel);
bot.on('callback_query', /*#__PURE__*/function () {
  var _ref40 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee55(callback) {
    var _require4, getConfig, setConfig, checkers, DBF, auth, cbData, chatId, messageId, capitalizeFirstLetter, checkerPanel, chooseChecker, createQuestion, changeCurrentChecker, _options4, translateKey, waitAnswer, _cbData$split, _cbData$split2, mainPanel, _cbData$split3, _cbData$split4, operation, queryOperations, operations, sendOperation;
    return _regeneratorRuntime().wrap(function _callee55$(_context56) {
      while (1) {
        switch (_context56.prev = _context56.next) {
          case 0:
            _require4 = require('./configManager'), getConfig = _require4.getConfig, setConfig = _require4.setConfig;
            checkers = require('./services/checkers');
            DBF = new DataBaseFunctions(database, callback);
            _context56.next = 5;
            return DBF.user().admin();
          case 5:
            auth = _context56.sent;
            cbData = callback.data;
            chatId = callback.message.chat.id;
            messageId = callback.message.message_id;
            if (!(cbData.includes('panel') && auth.success && callback.message.chat.type == 'private')) {
              _context56.next = 39;
              break;
            }
            capitalizeFirstLetter = function capitalizeFirstLetter(string) {
              return string.charAt(0).toUpperCase() + string.slice(1);
            };
            checkerPanel = /*#__PURE__*/function () {
              var _ref41 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee50() {
                var configs, keyboard, panelMessage, other;
                return _regeneratorRuntime().wrap(function _callee50$(_context51) {
                  while (1) {
                    switch (_context51.prev = _context51.next) {
                      case 0:
                        configs = getConfig('checkers');
                        keyboard = Object.keys(checkers).map(function (checker) {
                          return {
                            text: capitalizeFirstLetter(checker),
                            callback_data: "panel-checker-choose-".concat(checker)
                          };
                        }).spliter();
                        keyboard.push([{
                          text: 'Max. de tentativas',
                          callback_data: 'panel-checker-set-retrys'
                        }], [{
                          text: '🔙 Voltar',
                          callback_data: 'admin-panel'
                        }]);
                        panelMessage = "Configura\xE7\xF5es de checkers\n\n" + "\u2022 <b>Checker atual:</> <code>".concat(configs.currentChecker, "</> - <i>Checker atualmente em uso</>\n") + "\u2022 <b>Max. de tentativas:</> <code>".concat(configs.retrys, "</> - <i>M\xE1ximo de tentativas do testador em obter retorno, ap\xF3s uma instabilidade</>\n\n") + "<b>Lista de checkers abaixo</>";
                        other = _objectSpread(_objectSpread({}, _options4), {}, {
                          reply_markup: {
                            inline_keyboard: keyboard
                          }
                        });
                        _context51.next = 7;
                        return bot.editMessageText(panelMessage, other);
                      case 7:
                      case "end":
                        return _context51.stop();
                    }
                  }
                }, _callee50);
              }));
              return function checkerPanel() {
                return _ref41.apply(this, arguments);
              };
            }();
            chooseChecker = /*#__PURE__*/function () {
              var _ref43 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee51(_ref42) {
                var _ref44, checker, actions, configs, selectedChecker, subPanelMessage, minimalizeText, keyboard, isCurrentCheckerEmoji, other;
                return _regeneratorRuntime().wrap(function _callee51$(_context52) {
                  while (1) {
                    switch (_context52.prev = _context52.next) {
                      case 0:
                        _ref44 = _toArray(_ref42), checker = _ref44[0], actions = _ref44.slice(1);
                        configs = getConfig('checkers');
                        selectedChecker = getConfig("checkers.".concat(checker));
                        subPanelMessage = "Configura\xE7\xF5es para o checker <b>".concat(checker, "</>\n") + "".concat(selectedChecker.obs, "\n\n") + "<b>Clique sobre os bot\xF5es para alterar devida configura\xE7\xE3o</>";
                        minimalizeText = function minimalizeText(text) {
                          var length = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 15;
                          return text.length >= length ? "".concat(text.slice(0, length), "...") : text;
                        };
                        keyboard = Object.keys(selectedChecker).filter(function (key) {
                          return !['obs', 'set'].includes(key);
                        }).map(function (option) {
                          return {
                            text: "".concat(translateKey(option), ": ").concat(minimalizeText(selectedChecker[option])),
                            callback_data: "panel-checker-set-".concat(checker, "-").concat(option)
                          };
                        }).spliter();
                        isCurrentCheckerEmoji = configs.currentChecker == checker ? '✅' : '❌';
                        keyboard.push([{
                          text: "Checker em uso: ".concat(isCurrentCheckerEmoji),
                          callback_data: "panel-checker-state-currentChecker-".concat(checker)
                        }], [{
                          text: '🔙 Voltar',
                          callback_data: 'panel-checker'
                        }]);
                        other = _objectSpread(_objectSpread({}, _options4), {}, {
                          reply_markup: {
                            inline_keyboard: keyboard
                          }
                        });
                        _context52.next = 11;
                        return bot.editMessageText(subPanelMessage, other);
                      case 11:
                      case "end":
                        return _context52.stop();
                    }
                  }
                }, _callee51);
              }));
              return function chooseChecker(_x47) {
                return _ref43.apply(this, arguments);
              };
            }();
            createQuestion = /*#__PURE__*/function () {
              var _ref47 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee53(_ref46) {
                var _ref48, option, subOption, _ref49, _ref50, optionQuestion, path, answerMessage, other, answer;
                return _regeneratorRuntime().wrap(function _callee53$(_context54) {
                  while (1) {
                    switch (_context54.prev = _context54.next) {
                      case 0:
                        _ref48 = _slicedToArray(_ref46, 2), option = _ref48[0], subOption = _ref48[1];
                        _ref49 = subOption ? [subOption, "checkers.".concat(option, ".").concat(subOption)] : [option, "checkers.".concat(option)], _ref50 = _slicedToArray(_ref49, 2), optionQuestion = _ref50[0], path = _ref50[1];
                        answerMessage = "Envie o valor para <b>".concat(translateKey(optionQuestion), "</>:");
                        other = _objectSpread({}, _options4);
                        _context54.next = 6;
                        return bot.editMessageText(answerMessage, other);
                      case 6:
                        _context54.next = 8;
                        return waitAnswer();
                      case 8:
                        answer = _context54.sent;
                        other.reply_markup = new InlineKeyboard().text('🔙 Voltar', 'panel-checker');
                        console.log(path);
                        setConfig(path, answer);
                        _context54.next = 14;
                        return bot.editMessageText("<b>Altera\xE7\xE3o bem sucedida.</>", other);
                      case 14:
                      case "end":
                        return _context54.stop();
                    }
                  }
                }, _callee53);
              }));
              return function createQuestion(_x49) {
                return _ref47.apply(this, arguments);
              };
            }();
            changeCurrentChecker = /*#__PURE__*/function () {
              var _ref52 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee54(_ref51) {
                var _ref53, path, checker, _getConfig, currentChecker, other;
                return _regeneratorRuntime().wrap(function _callee54$(_context55) {
                  while (1) {
                    switch (_context55.prev = _context55.next) {
                      case 0:
                        _ref53 = _slicedToArray(_ref51, 2), path = _ref53[0], checker = _ref53[1];
                        _getConfig = getConfig("checkers"), currentChecker = _getConfig.currentChecker;
                        if (!(currentChecker == checker)) {
                          _context55.next = 6;
                          break;
                        }
                        _context55.next = 5;
                        return bot.answerCallbackQuery(callback.id, {
                          text: 'Checker já em uso.',
                          show_alert: true
                        });
                      case 5:
                        return _context55.abrupt("return", _context55.sent);
                      case 6:
                        setConfig("checkers.".concat(path), checker);
                        other = _objectSpread({}, _options4);
                        other.reply_markup = new InlineKeyboard().text('🔙 Voltar', "panel-checker-choose-".concat(checker));
                        _context55.next = 11;
                        return bot.editMessageText("<b>Altera\xE7\xE3o bem sucedida.</>", other);
                      case 11:
                      case "end":
                        return _context55.stop();
                    }
                  }
                }, _callee54);
              }));
              return function changeCurrentChecker(_x50) {
                return _ref52.apply(this, arguments);
              };
            }();
            if (!cbData.includes('admin-panel')) {
              _context56.next = 22;
              break;
            }
            _context56.next = 18;
            return bot.deleteMessage(chatId, messageId);
          case 18:
            _context56.t0 = _context56.sent;
            if (!_context56.t0) {
              _context56.next = 21;
              break;
            }
            _context56.t0 = panel(callback);
          case 21:
            return _context56.abrupt("return", _context56.t0);
          case 22:
            _options4 = {
              chat_id: chatId,
              message_id: messageId,
              parse_mode: 'HTML'
            };
            translateKey = function translateKey(key) {
              var keys = {
                token: 'Token',
                key: 'Chave',
                user: 'Usuario',
                pass: 'Senha',
                tester: 'Gate',
                retrys: 'Max. de tentativa'
              };
              return keys[key];
            };
            waitAnswer = function waitAnswer() {
              return new Promise(function (resolve) {
                return bot.once('text', /*#__PURE__*/function () {
                  var _ref45 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee52(msg) {
                    return _regeneratorRuntime().wrap(function _callee52$(_context53) {
                      while (1) {
                        switch (_context53.prev = _context53.next) {
                          case 0:
                            _context53.t1 = msg.chat.type == 'private' && msg.chat.id == chatId;
                            if (!_context53.t1) {
                              _context53.next = 5;
                              break;
                            }
                            _context53.next = 4;
                            return bot.deleteMessage(chatId, msg.message_id);
                          case 4:
                            _context53.t1 = _context53.sent;
                          case 5:
                            _context53.t0 = _context53.t1;
                            if (!_context53.t0) {
                              _context53.next = 8;
                              break;
                            }
                            _context53.t0 = resolve(msg.text);
                          case 8:
                            return _context53.abrupt("return", _context53.t0);
                          case 9:
                          case "end":
                            return _context53.stop();
                        }
                      }
                    }, _callee52);
                  }));
                  return function (_x48) {
                    return _ref45.apply(this, arguments);
                  };
                }());
              });
            };
            _cbData$split = cbData.split('-'), _cbData$split2 = _slicedToArray(_cbData$split, 2), mainPanel = _cbData$split2[1];
            if (!mainPanel.includes('checker')) {
              _context56.next = 37;
              break;
            }
            _cbData$split3 = cbData.split('-'), _cbData$split4 = _toArray(_cbData$split3), operation = _cbData$split4[2], queryOperations = _cbData$split4.slice(3);
            operations = {
              choose: chooseChecker,
              set: createQuestion,
              state: changeCurrentChecker
            };
            if (!operation) {
              _context56.next = 35;
              break;
            }
            sendOperation = operations[operation];
            _context56.next = 33;
            return sendOperation(queryOperations);
          case 33:
            _context56.next = 37;
            break;
          case 35:
            _context56.next = 37;
            return checkerPanel();
          case 37:
            _context56.next = 42;
            break;
          case 39:
            if (!cbData.includes('delete-message')) {
              _context56.next = 42;
              break;
            }
            _context56.next = 42;
            return bot.deleteMessage(chatId, messageId);
          case 42:
          case "end":
            return _context56.stop();
        }
      }
    }, _callee55);
  }));
  return function (_x46) {
    return _ref40.apply(this, arguments);
  };
}());
bot.on('polling_error', function (error) {
  return console.log(error);
});
bot.on('notification', /*#__PURE__*/function () {
  var _ref55 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee56(_ref54) {
    var subject, message, reference, admininstrators;
    return _regeneratorRuntime().wrap(function _callee56$(_context57) {
      while (1) {
        switch (_context57.prev = _context57.next) {
          case 0:
            subject = _ref54.subject, message = _ref54.message, reference = _ref54.reference;
            _context57.next = 3;
            return database.User.find({
              admin: true
            });
          case 3:
            admininstrators = _context57.sent;
            admininstrators.forEach(function (admin) {
              return bot.sendMessage(admin.id, "\uD83D\uDD14 Notifica\xE7\xE3o do sistema\n\n" + "Assunto: <code>".concat(subject, "</code>\n") + "Mensagem: <code>".concat(message, "</code>")(_templateObject || (_templateObject = _taggedTemplateLiteral(["Refer\xEAncia: <code>", ""])), reference), {
                parse_mode: 'HTML'
              });
            });
          case 5:
          case "end":
            return _context57.stop();
        }
      }
    }, _callee56);
  }));
  return function (_x51) {
    return _ref55.apply(this, arguments);
  };
}());
process.on('unhandledRejection', function (reason, promise) {
  console.log(reason);
  console.log(promise);
});
bot.on('channel_post', function (m) {
  return console.log(m);
});