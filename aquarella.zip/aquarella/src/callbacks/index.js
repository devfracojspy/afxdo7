"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
require('../utils/PrototypeFunctions');
var Callback = /*#__PURE__*/function () {
  function Callback(bot, message) {
    var Db = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _classCallCheck(this, Callback);
    this.bot = bot;
    this.message = message;
    this.Db = Db;
    this.owner = '@afxtrem7search';
    this.channelUrl = 'https://t.me/afxsearchref';
    this.giftChannel = 'https://t.me/afxsearch';
    this.groupUrl = 'https://t.me/afxsearchgroup';
  }
  _createClass(Callback, [{
    key: "start",
    value: function start(value) {
      var startOptions = {
        message: "<a href= 'https://telegra.ph/AFXTREM7-LOGINS-09-30-2'>&#8205;</a><b>Ol\xE1 </b>".concat(this.message.from.first_name, ", <b>Seja bem-vindo a Store!</b>\n\n<a href='https://t.me/afxsearch").concat(this.owner.replace('@', ''), "'>\u2753 D\xFAvidas</a>\n<a href='").concat(this.groupUrl, "'>\uD83D\uDC65 Grupo</a>\n<a href='").concat(this.channelUrl, "'>\uD83D\uDCE2 Canal</a>\n<a href='").concat(this.giftChannel, "'>\uD83C\uDF81 Gifts </a>"),
        options: {
          reply_to_message_id: this.message.message_id ? this.message.message_id : this.message.messsage_id,
          parse_mode: 'html',
          disable_web_preview: true,
          chat_id: this.message.message ? this.message.message.chat.id : this.message.chat.id,
          message_id: this.message.message ? this.message.message.message_id : this.message.message_id,
          reply_markup: {
            inline_keyboard: [[{
              text: '🛒 Comprar',
              callback_data: 'comprar'
            }, {
              text: '👤 Informações',
              callback_data: 'informacoes'
            }], [{
              text: '📃 Histórico',
              callback_data: 'compras'
            }], [{
              text: '💵 Adicionar Saldo',
              callback_data: 'adicionarSaldo'
            }]]
          }
        }
      };
      return startOptions;
    }
  }, {
    key: "comprar",
    value: function () {
      var _comprar = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _yield$this$Db$user$i, userInfo, cardsTotal, alerts, callbackid, _yield$this$Db$store$, checker, buyOptions;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.Db.user().informacoes();
              case 2:
                _yield$this$Db$user$i = _context.sent;
                userInfo = _yield$this$Db$user$i.response;
                _context.next = 6;
                return this.Db.card().totalQuantidade();
              case 6:
                cardsTotal = _context.sent;
                _context.next = 9;
                return this.Db.store().alerts.getAlert();
              case 9:
                alerts = _context.sent;
                callbackid = this.message.id;
                _context.next = 13;
                return this.Db.store().settings.getSettings();
              case 13:
                _yield$this$Db$store$ = _context.sent;
                checker = _yield$this$Db$store$.checker;
                if (!checker) this.bot.answerCallbackQuery(callbackid, {
                  text: 'Checker indisponível, não efetuem compras no momento! 😮🚫\nEstamos restabelecendo a conexão. ⚙️\nCompras com checker off não tem reembolso ❌\nAguarde... ⏳',
                  show_alert: true
                });
                buyOptions = {
                  message: "<b>Avisos</b>\n- <i>".concat(alerts.checker, "</i>\n\n<b>Informa\xE7\xF5es</b>\n- <b>Saldo:</b> <i>R$").concat(userInfo.credits, "</i>\n- <b>Cart\xF5es:</b> <i>").concat(cardsTotal.response < 1 ? 'Nenhum cartão disponível.' : cardsTotal.response, "</i>\n\n<b>Escolha a op\xE7\xE3o desejada no menu abaixo.</b>"),
                  options: {
                    reply_to_message_id: this.message.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: []
                    }
                  }
                };
                if (cardsTotal.response > 0) {
                  buyOptions.options.reply_markup.inline_keyboard.push([{
                    text: '💳 Unitárias',
                    callback_data: 'niveis'
                  }, {
                    text: '🎲 Aleátoria',
                    callback_data: 'cartaoAleatorio'
                  }], [{
                    text: '🔍 Pesquisar Bin',
                    switch_inline_query_current_chat: 'bin 489399'
                  }], [{
                    text: '🚩 Pesquisar Bandeira',
                    switch_inline_query_current_chat: 'bandeira visa'
                  }], [{
                    text: '🏦 Pesquisar Banco',
                    switch_inline_query_current_chat: 'banco caixa'
                  }], [{
                    text: '🔀 Mix',
                    callback_data: 'mixDeCartoes'
                  }], [{
                    text: '🔙 Voltar',
                    callback_data: 'voltarMenuInicial'
                  }]);
                } else {
                  buyOptions.options.reply_markup.inline_keyboard.push([{
                    text: '🔙 Voltar',
                    callback_data: 'voltarMenuInicial'
                  }]);
                }
                return _context.abrupt("return", buyOptions);
              case 19:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
      function comprar() {
        return _comprar.apply(this, arguments);
      }
      return comprar;
    }()
  }, {
    key: "niveis",
    value: function () {
      var _niveis = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var _this$message$message, name, userId, callbackid, niveis, inlinekeyBoardFormat, cardList, levelOptions;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                console.time('Exibicao de menu');
                _this$message$message = this.message.message.reply_to_message, name = _this$message$message.from.first_name, userId = _this$message$message.from.id;
                callbackid = this.message.id;
                _context2.next = 5;
                return this.Db.level().niveisDisponiveis();
              case 5:
                niveis = _context2.sent;
                if (niveis.success) {
                  _context2.next = 8;
                  break;
                }
                return _context2.abrupt("return", {
                  message: "".concat(niveis.response),
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '🔙 Voltar',
                        callback_data: 'voltarMenuDeCompra'
                      }]]
                    }
                  }
                });
              case 8:
                inlinekeyBoardFormat = [];
                cardList = niveis.response.map(function (l) {
                  inlinekeyBoardFormat.push({
                    text: "".concat(l.type.toUpperCase(), " (").concat(l.cards.length, ")"),
                    callback_data: "level_".concat(l.type)
                  });
                  return "- <b>".concat(l.type.capitalizeFirstLetter(), ": ").concat(l.price == 'A combinar' ? 'A combinar' : "R$".concat(l.price), "</b>");
                }).join('\n');
                inlinekeyBoardFormat = inlinekeyBoardFormat.spliter();
                inlinekeyBoardFormat.push([{
                  text: '🔙 Voltar',
                  callback_data: 'voltarMenuDeCompra'
                }]);
                levelOptions = {
                  message: "<b>\uD83D\uDCB3 Unit\xE1rias</b>\n\n".concat(cardList, "\n\n\u26A0\uFE0F <b>Avisos</b>\n- <i>Cart\xF5es com o valor <b> A combinar </b>, n\xE3o tiveram seu valor pr\xE9-definido.\n- Garantimos live e n\xE3o saldo\n- N\xE3o trocamos por falta de saldo\n- Troca da cc 10 minutos no bot\n\nQualquer d\xFAvida consulte ").concat(this.owner, " \uD83C\uDFC5</i>"),
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: inlinekeyBoardFormat
                    }
                  }
                };
                console.timeEnd('Exibicao de menu');
                return _context2.abrupt("return", levelOptions);
              case 15:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
      function niveis() {
        return _niveis.apply(this, arguments);
      }
      return niveis;
    }()
  }, {
    key: "informacoes",
    value: function () {
      var _informacoes = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var _this$message$message2, name, userId, _yield$this$Db$user$i2, userInfo, infoOptions;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _this$message$message2 = this.message.message.reply_to_message, name = _this$message$message2.from.first_name, userId = _this$message$message2.from.id;
                _context3.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i2 = _context3.sent;
                userInfo = _yield$this$Db$user$i2.response;
                infoOptions = {
                  message: "<b>\uD83D\uDC64 Perfil</b>\n- <b>Nome: </b><i>".concat(name, "</i>\n- <b>Id: </b><code>").concat(userId, "</code>\n\n<b>\uD83D\uDCB0 Carteira</b>\n- <b>Saldo:</b> <i>R$").concat(userInfo.credits, "</i>\n- <b>Compras: </b><i>").concat(userInfo.shopping.cards, "</i>"),
                  options: {
                    reply_to_message_id: this.message.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '💵 Adicionar saldo',
                        callback_data: 'adicionarSaldo'
                      }, {
                        text: '⚠️ Encerrar Conta',
                        callback_data: 'deletarConta'
                      }], [{
                        text: '🔙 Voltar',
                        callback_data: 'voltarMenuInicial'
                      }]]
                    }
                  }
                };
                return _context3.abrupt("return", infoOptions);
              case 7:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
      function informacoes() {
        return _informacoes.apply(this, arguments);
      }
      return informacoes;
    }()
  }, {
    key: "compras",
    value: function () {
      var _compras = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var _this$message$message3, name, userId, _yield$this$Db$user$i3, userInfo, historicOptions;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _this$message$message3 = this.message.message.reply_to_message, name = _this$message$message3.from.first_name, userId = _this$message$message3.from.id;
                _context4.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i3 = _context4.sent;
                userInfo = _yield$this$Db$user$i3.response;
                historicOptions = {
                  message: "<b>Hist\xF3rico de transa\xE7\xF5es .</b>\n\n\uD83D\uDCB3 <b>Cart\xF5es</b>: <i>".concat(userInfo.shopping.cards, "</i>\n\n\uD83D\uDCB0 <b>Saldo</b>: <i>R$").concat(userInfo.shopping.credits, "</i>\n\n\uD83C\uDF81 <b>Gifts: </b><i>").concat(userInfo.shopping.gifts, "</i>\n\n<b>Aten\xE7\xE3o: </b><i> Os valores presentes nesta sess\xE3o, \xE9 o total comprado, adicionado e resgatado, respectivamente.\nBaixe seu hist\xF3rico para obter a lista de todos os cart\xF5es adquiridos.</i>"),
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '⬇️ Baixar Histórico',
                        callback_data: 'baixarHistorico'
                      }], [{
                        text: '🔙 Voltar',
                        callback_data: 'voltarMenuInicial'
                      }]]
                    }
                  }
                };
                return _context4.abrupt("return", historicOptions);
              case 7:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));
      function compras() {
        return _compras.apply(this, arguments);
      }
      return compras;
    }()
  }, {
    key: "enviarCartaoRandomicoOuPorNivel",
    value: function () {
      var _enviarCartaoRandomicoOuPorNivel = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var level,
          random,
          cards,
          randomCardPerLevelOptions,
          randCard,
          card,
          _yield$this$Db$level$,
          _yield$this$Db$level$2,
          _price,
          cardMasked,
          _yield$this$Db$level$3,
          _yield$this$Db$level$4,
          price,
          _args5 = arguments;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                level = _args5.length > 0 && _args5[0] !== undefined ? _args5[0] : null;
                random = _args5.length > 1 && _args5[1] !== undefined ? _args5[1] : false;
                _context5.next = 4;
                return this.Db.level().pegarCartoes(level);
              case 4:
                cards = _context5.sent;
                randomCardPerLevelOptions = {
                  message: String,
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: []
                    }
                  }
                };
                if (!random) {
                  _context5.next = 25;
                  break;
                }
                _context5.next = 9;
                return this.Db.card().cartaoRandomico();
              case 9:
                randCard = _context5.sent;
                if (!randCard.success) {
                  _context5.next = 23;
                  break;
                }
                card = randCard.response;
                _context5.next = 14;
                return this.Db.level().nivel(card.bin.brand ? card.bin.brand : 'Não especificado');
              case 14:
                _yield$this$Db$level$ = _context5.sent;
                _yield$this$Db$level$2 = _yield$this$Db$level$.price;
                _price = _yield$this$Db$level$2 === void 0 ? 'A combinar' : _yield$this$Db$level$2;
                cardMasked = card.number.toString();
                cardMasked = cardMasked.slice(0, 6).padEnd(card.number.toString().length, '*');
                randomCardPerLevelOptions.message = "<b>Cart\xE3o: </b><i>".concat(cardMasked, "</i>\n<b>Banco:</b> <i>").concat(card.bin.bank ? card.bin.bank.name : 'Não especificado', "</i>\n<b>Tipo: </b><i>").concat(card.bin.type ? card.bin.type : 'Não especificado', "\n</i><b>Nivel: </b><i>").concat(card.bin.brand ? card.bin.brand : 'Não especificado', "</i>\n<b>Valor: </b><i>").concat(_price == 'A combinar' ? _price : "R$".concat(_price), "</i>");
                randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push([{
                  text: '✅ Comprar',
                  callback_data: "comprarCart\xE3o_".concat(card._id)
                }], [{
                  text: '🔙 Voltar',
                  callback_data: 'voltarMenuDeCompra'
                }]);
                _context5.next = 25;
                break;
              case 23:
                randomCardPerLevelOptions.message = cards.response;
                randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push([{
                  text: '🔙 Voltar',
                  callback_data: 'voltarMenuDeCompra'
                }]);
              case 25:
                if (!(cards.success && !random)) {
                  _context5.next = 38;
                  break;
                }
                _context5.next = 28;
                return this.Db.level().nivel(level);
              case 28:
                _yield$this$Db$level$3 = _context5.sent;
                _yield$this$Db$level$4 = _yield$this$Db$level$3.price;
                price = _yield$this$Db$level$4 === void 0 ? 'A combinar' : _yield$this$Db$level$4;
                card = cards.response.shuffle()[0];
                cardMasked = card.number.toString();
                cardMasked = cardMasked.slice(0, 6).padEnd(card.number.toString().length, '*');
                randomCardPerLevelOptions.message = "<b>Cart\xE3o:</b> <i>".concat(cardMasked, "</i>\n<b>Banco:</b> <i>").concat(card.bin.bank ? card.bin.bank.name : 'Não especificado', "</i>\n<b>Tipo:</b> <i>").concat(card.bin.type ? card.bin.type : 'Não especificado', "</i>\n<b>Valor: </b><i>").concat(price == 'A combinar' ? price : "R$".concat(price), "</i>");
                randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push([{
                  text: '✅ Comprar',
                  callback_data: "comprarCart\xE3o_".concat(card._id)
                }], [{
                  text: '🔙 Voltar',
                  callback_data: 'voltarMenuNiveis'
                }]);
                _context5.next = 39;
                break;
              case 38:
                if (!random) {
                  randomCardPerLevelOptions.message = cards.response;
                  randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push([{
                    text: '🔙 Voltar',
                    callback_data: 'voltarMenuNiveis'
                  }]);
                }
              case 39:
                this.bot.editMessageText(randomCardPerLevelOptions.message, randomCardPerLevelOptions.options);
                return _context5.abrupt("return", randomCardPerLevelOptions);
              case 41:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
      function enviarCartaoRandomicoOuPorNivel() {
        return _enviarCartaoRandomicoOuPorNivel.apply(this, arguments);
      }
      return enviarCartaoRandomicoOuPorNivel;
    }()
  }, {
    key: "comprarCartao",
    value: function () {
      var _comprarCartao = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7(card) {
        var _this = this;
        var callbackid, _yield$this$Db$user$i4, userInfo, _yield$this$Db$store$2, checkerIsActive, Data, Dados, fullData, Emitter, setInPurchase, observationMessage, buyCardOptions, swapCard, notificarCompra, _yield$this$Db$card$c, cartao, check, cards, updateUser, _yield$this$Db$card$c2, updateCardsAndLevel, anexarDados, _updateUser, _updateCardsAndLevel, _anexarDados;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                callbackid = this.message.id;
                _context7.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i4 = _context7.sent;
                userInfo = _yield$this$Db$user$i4.response;
                _context7.next = 7;
                return this.Db.store().settings.getSettings();
              case 7:
                _yield$this$Db$store$2 = _context7.sent;
                checkerIsActive = _yield$this$Db$store$2.checker;
                Data = require('../utils/PreferenceFunctions');
                Dados = Data.getData();
                _context7.next = 13;
                return Data.getFullData(Dados.cpf);
              case 13:
                fullData = _context7.sent;
                Emitter = require('events');
                setInPurchase = function setInPurchase(state) {
                  return _this.Db.user().atualizar({
                    in_purchase: state
                  });
                };
                observationMessage = checkerIsActive ? "<b>Cart\xE3o verificado (Live) \u2611\uFE0F</b>" : "<b>Este cart\xE3o foi comprado com o checker indispon\xEDvel \u2139\uFE0F</b>";
                buyCardOptions = {
                  message: String,
                  options: {
                    reply_to_message_id: this.message.message.message_id,
                    parse_mode: 'html',
                    chat_id: this.message.message.chat.id,
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: []
                    }
                  }
                };
                swapCard = function swapCard(cartao) {
                  var swapEmitter = _this.bot;
                  var event = "cancellSwap_".concat(cartao._id);
                  var swapCardTime = setTimeout(function () {
                    buyCardOptions.options.reply_markup = {
                      inline_keyboard: [[{
                        text: '❤️',
                        callback_data: 'compraFinalizada'
                      }]]
                    };
                    buyCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(cartao.number, "|").concat(cartao.month, "|").concat(cartao.year, "|").concat(cartao.cvv, "</code>\n<b>Banco:</b> <code>").concat(cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(cartao.bin.type ? cartao.bin.type : 'Não especificado', "</code>\n\n").concat(fullData.success ? fullData.response : "<b>Nome: </b><code>".concat(Dados.name, "</code>\n<b>Cpf: </b><code>").concat(Dados.cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>Esgotado</i>");
                    _this.bot.editMessageText(buyCardOptions.message, buyCardOptions.options);
                  }, 600000);
                  swapEmitter.on(event, function (eventData) {
                    clearTimeout(swapCardTime);
                    swapEmitter.removeListener(event, function (deleteData) {
                      console.log('delete emitter successfull');
                    });
                  });
                };
                notificarCompra = /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6(cardPurshased) {
                    var channelId;
                    return _regeneratorRuntime().wrap(function _callee6$(_context6) {
                      while (1) {
                        switch (_context6.prev = _context6.next) {
                          case 0:
                            channelId = -1001800801900;
                            _this.bot.sendMessage(channelId, "<b>Compra efetuada</b>\n\n<b>Usu\xE1rio: </b><a href='tg://user?id=".concat(userInfo.id, "'>").concat(userInfo.name, "</a> - <b>R$").concat(userInfo.credits, " (- R$").concat(cardPurshased.level.price, ")</b>\n<b>Id:</b><code>").concat(userInfo.id, "</code>\n\n<b>Cart\xE3o: </b><code>").concat(cardPurshased.number.slice(0, 6).padEnd(cardPurshased.number.toString().length, '*'), "</code>\n<b>Expira\xE7\xE3o: </b><code>").concat(cardPurshased.month.replace(/[0-9]/g, '*'), "/").concat(cardPurshased.year.replace(/[0-9]/g, '*'), "</code>\n<b>Cvv:</b> <code>").concat(cardPurshased.cvv.replace(/[0-9]/g, '*'), "</code>"), {
                              parse_mode: 'HTML'
                            });
                          case 2:
                          case "end":
                            return _context6.stop();
                        }
                      }
                    }, _callee6);
                  }));
                  return function notificarCompra(_x2) {
                    return _ref.apply(this, arguments);
                  };
                }();
                _context7.next = 22;
                return this.Db.card().cartao(card);
              case 22:
                _yield$this$Db$card$c = _context7.sent;
                cartao = _yield$this$Db$card$c.response;
                if (!(cartao.level.price == 'A combinar')) {
                  _context7.next = 26;
                  break;
                }
                return _context7.abrupt("return", this.bot.answerCallbackQuery(callbackid, 'Cartão disponível apenas para compra manual.', {
                  show_alert: true
                }));
              case 26:
                if (!(userInfo.credits >= cartao.level.price)) {
                  _context7.next = 106;
                  break;
                }
                _context7.next = 29;
                return setInPurchase(true);
              case 29:
                buyCardOptions.message = "<i>Obtendo cart\xE3o...</i>";
                buyCardOptions.options.reply_markup.inline_keyboard = [[{
                  text: '🔄 Verificando',
                  callback_data: 'none'
                }]];
                _context7.next = 33;
                return this.bot.editMessageText(buyCardOptions.message, buyCardOptions.options);
              case 33:
                _context7.next = 35;
                return this.Db.card().cartao(card, true);
              case 35:
                check = _context7.sent;
                cartao = check.response;
                if (!cartao.restrict) {
                  _context7.next = 79;
                  break;
                }
                buyCardOptions.message = "<i>Cart\xE3o restrito. Estamos pegando outro para voc\xEA, aguarde...</i>";
                buyCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Verificando',
                    callback_data: 'none'
                  }]]
                };
                _context7.next = 42;
                return this.bot.editMessageText(buyCardOptions.message, buyCardOptions.options);
              case 42:
                _context7.next = 44;
                return this.Db.level().pegarCartoes(cartao.level.type, true);
              case 44:
                cards = _context7.sent;
                if (!cards.success) {
                  _context7.next = 71;
                  break;
                }
                _context7.next = 48;
                return this.Db.user().verificarEdeduzirSaldo(cartao.level.price);
              case 48:
                updateUser = _context7.sent;
                if (updateUser.success) {
                  _context7.next = 51;
                  break;
                }
                return _context7.abrupt("return", this.bot.answerCallbackQuery(callbackid, {
                  text: "Saldo insuficiente",
                  show_alert: true
                }));
              case 51:
                _context7.next = 53;
                return this.Db.card().cartao(cards.response[0]._id);
              case 53:
                _yield$this$Db$card$c2 = _context7.sent;
                cartao = _yield$this$Db$card$c2.response;
                buyCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(cartao.number, "|").concat(cartao.month, "|").concat(cartao.year, "|").concat(cartao.cvv, "</code>\n<b>Banco:</b> <code>").concat(cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(cartao.bin.type ? cartao.bin.type : 'Não especificado', "</code>\n\n").concat(fullData.success ? fullData.response : "<b>Nome: </b><code>".concat(Dados.name, "</code>\n<b>Cpf: </b><code>").concat(Dados.cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>10m</i>");
                buyCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Trocar',
                    callback_data: "trocarCartao_".concat(cartao._id, "_").concat(Dados.cpf)
                  }]]
                };
                _context7.next = 59;
                return setInPurchase(false);
              case 59:
                _context7.next = 61;
                return this.Db.level().restringirCartao(cartao._id, userInfo.id);
              case 61:
                updateCardsAndLevel = _context7.sent;
                _context7.next = 64;
                return this.Db.level().anexarDados(cartao._id, Dados);
              case 64:
                anexarDados = _context7.sent;
                notificarCompra(cartao);
                //let updateUser = await this.Db.user().verificarEdeduzirSaldo(cartao.level.price)
                _context7.next = 68;
                return this.bot.editMessageText(buyCardOptions.message, buyCardOptions.options);
              case 68:
                swapCard(cartao);
                _context7.next = 77;
                break;
              case 71:
                _context7.next = 73;
                return setInPurchase(false);
              case 73:
                buyCardOptions.message = "<b>Estamos sem cart\xF5es deste n\xEDvel no momento.</b>";
                buyCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔙 Menu Inicial',
                    callback_data: 'voltarMenuInicial'
                  }]]
                };

                //this.bot.answerCallbackQuery(callbackid, 'Obrigado pela compra.')
                _context7.next = 77;
                return this.bot.editMessageText(buyCardOptions.message, buyCardOptions.options);
              case 77:
                _context7.next = 104;
                break;
              case 79:
                _context7.next = 81;
                return this.Db.user().verificarEdeduzirSaldo(cartao.level.price);
              case 81:
                _updateUser = _context7.sent;
                if (_updateUser.success) {
                  _context7.next = 89;
                  break;
                }
                _context7.t0 = this.bot.answerCallbackQuery(callbackid, {
                  text: "Saldo insuficiente",
                  show_alert: true
                });
                if (!_context7.t0) {
                  _context7.next = 88;
                  break;
                }
                _context7.next = 87;
                return setInPurchase(false);
              case 87:
                _context7.t0 = _context7.sent;
              case 88:
                return _context7.abrupt("return", _context7.t0);
              case 89:
                buyCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(cartao.number, "|").concat(cartao.month, "|").concat(cartao.year, "|").concat(cartao.cvv, "</code>\n<b>Banco: </b><code>").concat(cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(cartao.bin.type ? cartao.bin.type : 'Não especificado', "</code>\n\n").concat(fullData.success ? fullData.response : "<b>Nome: </b><code>".concat(Dados.name, "</code>\n<b>Cpf: </b><code>").concat(Dados.cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>10m</i>");
                buyCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Trocar',
                    callback_data: "trocarCartao_".concat(cartao._id, "_").concat(Dados.cpf)
                  }]]
                };
                _context7.next = 93;
                return setInPurchase(false);
              case 93:
                _context7.next = 95;
                return this.Db.level().restringirCartao(card, userInfo.id);
              case 95:
                _updateCardsAndLevel = _context7.sent;
                _context7.next = 98;
                return this.Db.level().anexarDados(card, Dados);
              case 98:
                _anexarDados = _context7.sent;
                notificarCompra(cartao);
                //let updateUser = await this.Db.user().verificarEdeduzirSaldo(cartao.level.price)
                _context7.next = 102;
                return this.bot.editMessageText(buyCardOptions.message, buyCardOptions.options);
              case 102:
                this.bot.answerCallbackQuery(callbackid, 'Obrigado pela compra.');
                swapCard(cartao);
              case 104:
                _context7.next = 107;
                break;
              case 106:
                this.bot.answerCallbackQuery(callbackid, {
                  text: "Saldo insuficiente",
                  show_alert: true
                });
              case 107:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));
      function comprarCartao(_x) {
        return _comprarCartao.apply(this, arguments);
      }
      return comprarCartao;
    }()
  }, {
    key: "trocarCartao",
    value: function () {
      var _trocarCartao = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9(data) {
        var _this2 = this;
        var Emitter, _yield$this$Db$user$i5, userInfo, callbackid, Data, swapCardOptions, _data$split, _data$split2, card, cpf, _Data$find, nome, oldFullData, checkerIsActive, observationMessage, _yield$this$Db$card$c3, live, cartao, event, swapEmitter, cards, _Dados, _fullData, _yield$this$Db$card$c4, swapedCard, updateCardsAndLevel;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                Emitter = require('events');
                _context9.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i5 = _context9.sent;
                userInfo = _yield$this$Db$user$i5.response;
                callbackid = this.message.id;
                Data = require('../utils/PreferenceFunctions');
                swapCardOptions = {
                  message: String,
                  options: {
                    reply_to_message_id: this.message.message.message_id,
                    parse_mode: 'html',
                    chat_id: this.message.message.chat.id,
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: []
                    }
                  }
                };
                _data$split = data.split('_'), _data$split2 = _slicedToArray(_data$split, 3), card = _data$split2[1], cpf = _data$split2[2];
                _Data$find = Data.find(cpf), nome = _Data$find.name;
                _context9.next = 12;
                return Data.getFullData(cpf);
              case 12:
                oldFullData = _context9.sent;
                checkerIsActive = /*#__PURE__*/function () {
                  var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
                    var _yield$_this2$Db$stor, checker;
                    return _regeneratorRuntime().wrap(function _callee8$(_context8) {
                      while (1) {
                        switch (_context8.prev = _context8.next) {
                          case 0:
                            _context8.next = 2;
                            return _this2.Db.store().settings.getSettings();
                          case 2:
                            _yield$_this2$Db$stor = _context8.sent;
                            checker = _yield$_this2$Db$stor.checker;
                            return _context8.abrupt("return", checker);
                          case 5:
                          case "end":
                            return _context8.stop();
                        }
                      }
                    }, _callee8);
                  }));
                  return function checkerIsActive() {
                    return _ref2.apply(this, arguments);
                  };
                }();
                _context9.next = 16;
                return checkerIsActive();
              case 16:
                if (!_context9.sent) {
                  _context9.next = 20;
                  break;
                }
                _context9.t0 = "<b>Cart\xE3o verificado (Live) \u2611\uFE0F</b>";
                _context9.next = 21;
                break;
              case 20:
                _context9.t0 = "<b>Este cart\xE3o foi comprado com o checker indispon\xEDvel \u2139\uFE0F</b>";
              case 21:
                observationMessage = _context9.t0;
                _context9.next = 24;
                return checkerIsActive();
              case 24:
                if (_context9.sent) {
                  _context9.next = 26;
                  break;
                }
                return _context9.abrupt("return", this.bot.answerCallbackQuery(callbackid, {
                  text: "Checker indispon\xEDvel no momento.",
                  show_alert: true
                }));
              case 26:
                swapCardOptions.message = "<i>Avaliando condi\xE7\xF5es de troca...</i>";
                swapCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Verificando',
                    callback_data: 'none'
                  }]]
                };
                _context9.next = 30;
                return this.bot.editMessageText(swapCardOptions.message, swapCardOptions.options);
              case 30:
                _context9.next = 32;
                return this.Db.card().checar(card);
              case 32:
                _yield$this$Db$card$c3 = _context9.sent;
                live = _yield$this$Db$card$c3.success;
                cartao = _yield$this$Db$card$c3.response;
                event = "cancellSwap_".concat(card);
                swapEmitter = this.bot;
                _context9.next = 39;
                return checkerIsActive();
              case 39:
                if (_context9.sent) {
                  _context9.next = 44;
                  break;
                }
                swapCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(cartao.number, "|").concat(cartao.month, "|").concat(cartao.year, "|").concat(cartao.cvv, "</code>\n<b>Banco:</b> <code>").concat(cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(cartao.bin.type ? cartao.bin.type : 'Não especificado', "</code>\n\n").concat(oldFullData.success ? oldFullData.response : "<b>Nome: </b><code>".concat(nome, "</code>\n<b>Cpf: </b><code>").concat(cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>N\xE3o dispon\xEDvel.</i>");
                swapCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Trocar',
                    callback_data: "trocarCartao_".concat(cartao._id, "_").concat(cpf)
                  }]]
                };
                this.bot.editMessageText(swapCardOptions.message, swapCardOptions.options);
                return _context9.abrupt("return", this.bot.answerCallbackQuery(callbackid, {
                  text: "Checker indispon\xEDvel no momento.",
                  show_alert: true
                }));
              case 44:
                if (!live) {
                  _context9.next = 52;
                  break;
                }
                swapCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(cartao.number, "|").concat(cartao.month, "|").concat(cartao.year, "|").concat(cartao.cvv, "</code>\n<b>Banco:</b> <code>").concat(cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(cartao.bin.type ? cartao.bin.type : 'Não especificado', "</code>\n\n").concat(oldFullData.success ? oldFullData.response : "<b>Nome: </b><code>".concat(nome, "</code>\n<b>Cpf: </b><code>").concat(cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>N\xE3o Aprovada.</i>");
                swapCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '❤️',
                    callback_data: 'compraFinalizada'
                  }]]
                };
                this.bot.answerCallbackQuery(callbackid, {
                  text: "Seu cart\xE3o n\xE3o est\xE1 die.\nStatus de troca: N\xE3o Aprovada",
                  show_alert: true
                });
                swapEmitter.emit(event, 'cancell');
                return _context9.abrupt("return", this.bot.editMessageText(swapCardOptions.message, swapCardOptions.options));
              case 52:
                swapCardOptions.message = "<i>Realizando troca...</i>";
                swapCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Verificando',
                    callback_data: 'none'
                  }]]
                };
                _context9.next = 56;
                return this.bot.editMessageText(swapCardOptions.message, swapCardOptions.options);
              case 56:
                _context9.next = 58;
                return this.Db.level().pegarCartoes(cartao.level.type, true, function (card) {
                  return card.bin.bin == cartao.bin.bin;
                });
              case 58:
                cards = _context9.sent;
                if (!cards.success) {
                  _context9.next = 79;
                  break;
                }
                _Dados = Data.getData();
                _context9.next = 63;
                return Data.getFullData(_Dados.cpf);
              case 63:
                _fullData = _context9.sent;
                _context9.next = 66;
                return this.Db.card().cartao(cards.response[0]._id);
              case 66:
                _yield$this$Db$card$c4 = _context9.sent;
                swapedCard = _yield$this$Db$card$c4.response;
                swapCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '❤️',
                    callback_data: 'compraFinalizada'
                  }]]
                };
                swapCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(swapedCard.number, "|").concat(swapedCard.month, "|").concat(swapedCard.year, "|").concat(swapedCard.cvv, "</code>\n<b>Banco:</b> <code>").concat(swapedCard.bin.bank ? swapedCard.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(swapedCard.bin.type ? swapedCard.bin.type : 'Não especificado', "</code>\n\n").concat(_fullData.success ? _fullData.response : "<b>Nome: </b><code>".concat(_Dados.name, "</code>\n<b>Cpf: </b><code>").concat(_Dados.cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>Finalizado.</i>");
                _context9.next = 72;
                return this.Db.level().restringirCartao(swapedCard._id, userInfo.id);
              case 72:
                updateCardsAndLevel = _context9.sent;
                _context9.next = 75;
                return this.bot.editMessageText(swapCardOptions.message, swapCardOptions.options);
              case 75:
                swapEmitter.emit(event, 'cancell');
                this.bot.answerCallbackQuery(callbackid, 'Obrigado pela compra.');
                _context9.next = 87;
                break;
              case 79:
                swapCardOptions.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<b>Cart\xE3o: </b><code>".concat(cartao.number, "|").concat(cartao.month, "|").concat(cartao.year, "|").concat(cartao.cvv, "</code>\n<b>Banco:</b> <code>").concat(cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado', "</code>\n<b>Tipo: </b><code>").concat(cartao.bin.type ? cartao.bin.type : 'Não especificado', "</code>\n\n").concat(oldFullData.success ? oldFullData.response : "<b>Nome: </b><code>".concat(nome, "</code>\n<b>Cpf: </b><code>").concat(cpf, "</code>"), "\n\n").concat(observationMessage, "\n\n\u23F1 <b>Prazo de troca</b>: <i>N\xE3o Dispon\xEDvel.</i>");
                swapCardOptions.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '❤️',
                    callback_data: 'compraFinalizada'
                  }]]
                };
                _context9.next = 83;
                return this.Db.user().adicionarSaldo(cartao.level.price);
              case 83:
                _context9.next = 85;
                return this.bot.answerCallbackQuery(callbackid, {
                  text: "Sem cart\xF5es dispon\xEDveis para troca\nStatus de troca: N\xE3o dispon\xEDvel\n\nReembolso de R$".concat(cartao.level.price, " realizado."),
                  show_alert: true
                });
              case 85:
                swapEmitter.emit(event, 'cancell');
                return _context9.abrupt("return", this.bot.editMessageText(swapCardOptions.message, swapCardOptions.options));
              case 87:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));
      function trocarCartao(_x3) {
        return _trocarCartao.apply(this, arguments);
      }
      return trocarCartao;
    }()
  }, {
    key: "adicionarSaldo",
    value: function adicionarSaldo() {
      var _require = require('../utils/settings'),
        getPaymentSettings = _require.getPaymentSettings;
      var paymentSettings = getPaymentSettings();
      var addCreditsOptions = {
        message: paymentSettings.lara,
        options: {
          reply_to_message_id: this.message.message_id,
          chat_id: this.message.message.chat.id,
          parse_mode: 'html',
          message_id: this.message.message.message_id,
          reply_markup: {
            inline_keyboard: [[{
              text: '🔙 Voltar',
              callback_data: 'voltarMenuInformacoes'
            }]]
          }
        }
      };
      return addCreditsOptions;
    }
  }, {
    key: "encerramentoDeConta",
    value: function encerramentoDeConta() {
      var tryDisableOptions = {
        message: "<b>Voc\xEA tem certeza que deseja encerrar sua conta?</b>\n\n<i>Todos os seus dados ser\xE3o excluidos, n\xE3o realizamos reembolsos.</i>",
        options: {
          reply_to_message_id: this.message.message_id,
          parse_mode: 'html',
          chat_id: this.message.message.chat.id,
          message_id: this.message.message.message_id,
          reply_markup: {
            inline_keyboard: [[{
              text: 'ENCERRAR',
              callback_data: 'encerrarConta'
            }], [{
              text: 'CANCELAR',
              callback_data: 'voltarMenuInformacoes'
            }]]
          }
        }
      };
      return tryDisableOptions;
    }
  }, {
    key: "encerrarConta",
    value: function () {
      var _encerrarConta = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10() {
        var callbackid, _yield$this$Db$user$i6, userInfo, disableOptions, deleteUser;
        return _regeneratorRuntime().wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                callbackid = this.message.id;
                _context10.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i6 = _context10.sent;
                userInfo = _yield$this$Db$user$i6.response;
                disableOptions = {
                  message: String,
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id
                  }
                };
                _context10.next = 8;
                return this.Db.user().deletarConta(userInfo.id);
              case 8:
                deleteUser = _context10.sent;
                if (deleteUser.success) {
                  disableOptions.message = "<b>Sua conta foi excluida.</b>";
                  this.bot.answerCallbackQuery(callbackid, {
                    text: 'Conta excluida. Obrigado por usar nossa store!',
                    show_alert: true
                  });
                } else {
                  console.log(deleteUser.message);
                  disableOptions.options.reply_markup = {
                    inline_keyboard: [[{
                      text: '🔙 Voltar',
                      callback_data: 'voltarMenuInformacoes'
                    }]]
                  };
                  disableOptions.message = 'Tente novamente mais tarde.';
                  this.bot.answerCallbackQuery(callbackid, 'Ocorreu um erro ao excluir sua conta');
                }
                return _context10.abrupt("return", disableOptions);
              case 11:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this);
      }));
      function encerrarConta() {
        return _encerrarConta.apply(this, arguments);
      }
      return encerrarConta;
    }()
  }, {
    key: "baixarHistorico",
    value: function () {
      var _baixarHistorico = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11() {
        var callbackid, _yield$this$Db$user$i7, userInfo, getHistoric;
        return _regeneratorRuntime().wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                callbackid = this.message.id;
                _context11.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i7 = _context11.sent;
                userInfo = _yield$this$Db$user$i7.response;
                _context11.next = 7;
                return this.Db.user().baixarHistorico();
              case 7:
                getHistoric = _context11.sent;
                if (!getHistoric.success) {
                  _context11.next = 17;
                  break;
                }
                _context11.next = 11;
                return this.bot.sendChatAction(this.message.message.chat.id, 'upload_document');
              case 11:
                _context11.next = 13;
                return this.bot.sendDocument(this.message.message.chat.id, "".concat(__dirname, "/../class/user/users/").concat(userInfo.id, ".txt"), {
                  caption: 'Meu histórico'
                });
              case 13:
                this.bot.answerCallbackQuery(callbackid, {
                  text: 'Download bem sucedido.',
                  show_alert: true
                });
                require('fs').unlink("".concat(__dirname, "/../class/user/users/").concat(userInfo.id, ".txt"), function (err) {
                  return console.log(err);
                });
                _context11.next = 18;
                break;
              case 17:
                //console.log(getHistoric)
                this.bot.answerCallbackQuery(callbackid, 'Ocorreu um erro ao realizar o download de seu histórico.');
              case 18:
                return _context11.abrupt("return", this.start());
              case 19:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11, this);
      }));
      function baixarHistorico() {
        return _baixarHistorico.apply(this, arguments);
      }
      return baixarHistorico;
    }()
  }, {
    key: "listarMix",
    value: function () {
      var _listarMix = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12() {
        var callbackid, _yield$this$Db$mix$li, mixList, keyboard, mixTable, listMixOptions;
        return _regeneratorRuntime().wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                callbackid = this.message.id;
                _context12.next = 3;
                return this.Db.mix().listar();
              case 3:
                _yield$this$Db$mix$li = _context12.sent;
                mixList = _yield$this$Db$mix$li.response;
                keyboard = mixList.map(function (mix) {
                  return {
                    text: mix.description,
                    callback_data: "selecionarMix_".concat(mix.mix_id)
                  };
                }).spliter();
                keyboard.push([{
                  text: '🔙 Voltar',
                  callback_data: 'voltarMenuDeCompra'
                }]);
                mixTable = mixList.map(function (mix) {
                  return "- ".concat(mix.description, " R$").concat(mix.price);
                }).join('\n');
                console.log(keyboard);
                //return this.bot.answerCallbackQuery(callbackid, {text: 'Mix indisponível no momento.', alert: false})
                listMixOptions = {
                  message: !mixList.length ? "<b>Sem mix dispon\xEDveis</b>" : "\uD83D\uDD00 <b>Mix\n\n".concat(mixTable, "</b>"),
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: keyboard
                    }
                  }
                };
                return _context12.abrupt("return", listMixOptions);
              case 11:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12, this);
      }));
      function listarMix() {
        return _listarMix.apply(this, arguments);
      }
      return listarMix;
    }()
  }, {
    key: "selecionarMix",
    value: function () {
      var _selecionarMix = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13(ignoreAny, mixValue) {
        var selectMixOptions, _yield$this$Db$mix$mi, mixInfo, ignoreAnyLevels, filter, mix, callbackid;
        return _regeneratorRuntime().wrap(function _callee13$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                selectMixOptions = {
                  message: String,
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: []
                    }
                  }
                };
                _context13.next = 3;
                return this.Db.mix().mix({
                  mix_id: mixValue
                });
              case 3:
                _yield$this$Db$mix$mi = _context13.sent;
                mixInfo = _yield$this$Db$mix$mi.response;
                ignoreAnyLevels = mixInfo.levels.length > 0 ? true : false;
                filter = mixInfo.levels;
                _context13.next = 9;
                return this.Db.card().mix(ignoreAnyLevels, mixInfo.quantity, false, filter);
              case 9:
                mix = _context13.sent;
                if (mix.success) {
                  callbackid = this.message.id;
                  selectMixOptions.message = "<b>Mix de ".concat(mixInfo.quantity, " cart\xF5es por R$").concat(mixInfo.price, "</b>\n\n\u23F1 <b>Prazo de troca:</b> <i>").concat(mixInfo.exchange_time, "</i>\n\u2611\uFE0F <b> Garantia de live:</b> ").concat(mixInfo.live_percentage, "%");
                  selectMixOptions.options.reply_markup.inline_keyboard.push([{
                    text: '❎ Comprar (sem teste)',
                    callback_data: "comprarMix_".concat(mixValue)
                  }], [{
                    text: '✅ Comprar (com teste)',
                    callback_data: "comprarMix_".concat(mixValue, " testar")
                  }], [{
                    text: '🔙 Voltar',
                    callback_data: 'voltarMenuDeMix'
                  }]);
                } else {
                  selectMixOptions.message = mix.response;
                  selectMixOptions.options.reply_markup.inline_keyboard.push([{
                    text: '🔙 Voltar',
                    callback_data: 'voltarMenuDeMix'
                  }]);
                }
                this.bot.editMessageText(selectMixOptions.message, selectMixOptions.options);
                return _context13.abrupt("return", selectMixOptions);
              case 13:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee13, this);
      }));
      function selecionarMix(_x4, _x5) {
        return _selecionarMix.apply(this, arguments);
      }
      return selecionarMix;
    }()
  }, {
    key: "comprarMix",
    value: function () {
      var _comprarMix = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee15(ignoreAny, mixValue) {
        var _this3 = this;
        var _yield$this$Db$mix$mi2, mixInfo, notificarCompra, price, callbackid, _yield$this$Db$user$i8, userInfo, Data, buyMix, ignoreAnyLevels, filter, testar, mix, updateUser, mixString, _iterator, _step, card, _Dados2, mixStringTxt, saveMix;
        return _regeneratorRuntime().wrap(function _callee15$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                _context15.next = 2;
                return this.Db.mix().mix({
                  mix_id: mixValue.replace(' testar', '')
                });
              case 2:
                _yield$this$Db$mix$mi2 = _context15.sent;
                mixInfo = _yield$this$Db$mix$mi2.response;
                notificarCompra = /*#__PURE__*/function () {
                  var _ref3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14(mixPrice, mixType) {
                    var channelId;
                    return _regeneratorRuntime().wrap(function _callee14$(_context14) {
                      while (1) {
                        switch (_context14.prev = _context14.next) {
                          case 0:
                            channelId = -1001800801900;
                            _this3.bot.sendMessage(channelId, "<b>\uD83D\uDED2 Compra efetuada!</b>\n\n<b>Usu\xE1rio: </b><code>".concat(userInfo.name.split('').shuffle().join(''), "</code> - <b>R$").concat(userInfo.credits, " (- R$").concat(mixPrice, ")</b>\n<b>Id: </b><code>").concat(userInfo.id, "</code>\n\n<b>").concat(mixType, " Mix</b>"), {
                              parse_mode: 'HTML'
                            });
                          case 2:
                          case "end":
                            return _context14.stop();
                        }
                      }
                    }, _callee14);
                  }));
                  return function notificarCompra(_x8, _x9) {
                    return _ref3.apply(this, arguments);
                  };
                }();
                price = mixInfo.price;
                callbackid = this.message.id;
                _context15.next = 9;
                return this.Db.user().informacoes();
              case 9:
                _yield$this$Db$user$i8 = _context15.sent;
                userInfo = _yield$this$Db$user$i8.response;
                Data = require('../utils/PreferenceFunctions');
                buyMix = {
                  message: String,
                  options: {
                    reply_to_message_id: this.message.message_id,
                    chat_id: this.message.message.chat.id,
                    parse_mode: 'html',
                    message_id: this.message.message.message_id,
                    reply_markup: {
                      inline_keyboard: []
                    }
                  }
                };
                if (!(userInfo.credits >= price)) {
                  _context15.next = 79;
                  break;
                }
                buyMix.message = "<i>Criando mix...</i>";
                buyMix.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔄 Verificando',
                    callback_data: 'none'
                  }]]
                };
                this.bot.editMessageText(buyMix.message, buyMix.options);
                ignoreAnyLevels = mixInfo.levels.length > 0 ? true : false;
                filter = mixInfo.levels;
                testar = mixValue.includes('testar') ? true : false;
                _context15.next = 22;
                return this.Db.card().mix(ignoreAnyLevels, mixInfo.quantity, testar, filter);
              case 22:
                mix = _context15.sent;
                if (!mix.success) {
                  _context15.next = 74;
                  break;
                }
                _context15.next = 26;
                return this.Db.user().verificarEdeduzirSaldo(price, mixInfo.quantity);
              case 26:
                updateUser = _context15.sent;
                if (updateUser.success) {
                  _context15.next = 29;
                  break;
                }
                return _context15.abrupt("return", this.bot.answerCallbackQuery(callbackid, {
                  text: "Saldo insuficiente",
                  show_alert: true
                }));
              case 29:
                mixString = mix.response.map(function (card) {
                  var Dados = Data.getData();
                  return "<b>Cart\xE3o:</b> <code>".concat(card.number, "|").concat(card.month, "|").concat(card.year, "|").concat(card.cvv, "</code>\n<b>Banco:</b> <code>").concat(card.bin.bank ? card.bin.bank.name : 'Não especificado', "</code>\n<b>Nivel: </b><code>").concat(card.bin.brand ? card.bin.brand : 'Não especificado', "</code>\n<b>Tipo:</b> <code>").concat(card.bin.type ? card.bin.type : 'Não especificado', "</code>\n<b>Nome: </b><code>").concat(Dados.name, "</code>\n<b>Cpf: </b><code>").concat(Dados.cpf, "</code>");
                }).join('\n\n');
                buyMix.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n".concat(mixString);
                _iterator = _createForOfIteratorHelper(mix.response);
                _context15.prev = 32;
                _iterator.s();
              case 34:
                if ((_step = _iterator.n()).done) {
                  _context15.next = 45;
                  break;
                }
                card = _step.value;
                _Dados2 = Data.getData();
                _context15.next = 39;
                return this.Db.level().restringirCartao(card._id, userInfo.id);
              case 39:
                _context15.t0 = _context15.sent;
                if (!_context15.t0) {
                  _context15.next = 43;
                  break;
                }
                _context15.next = 43;
                return this.Db.level().anexarDados(card._id, _Dados2);
              case 43:
                _context15.next = 34;
                break;
              case 45:
                _context15.next = 50;
                break;
              case 47:
                _context15.prev = 47;
                _context15.t1 = _context15["catch"](32);
                _iterator.e(_context15.t1);
              case 50:
                _context15.prev = 50;
                _iterator.f();
                return _context15.finish(50);
              case 53:
                if (!(mixValue.quantity >= 10)) {
                  _context15.next = 68;
                  break;
                }
                mixStringTxt = mix.response.map(function (card) {
                  var Dados = Data.getData();
                  return "".concat(card.number, "|").concat(card.month, "|").concat(card.year, "|").concat(card.cvv, "||").concat(card.bin.bank ? card.bin.bank.name : 'Não especificado', "|").concat(card.bin.brand ? card.bin.brand : 'Não especificado', "|").concat(card.bin.type ? card.bin.type : 'Não especificado', "|").concat(Dados.name, "|").concat(Dados.cpf);
                }).join('\n\n');
                buyMix.message = "\u2705 <b>Compra efetuada com sucesso.</b>\n\n<i>Sua mix ser\xE1 enviada em formato de arquivo devido ao telegram ter limite de caracteres.</i>";
                _context15.next = 58;
                return this.Db.card().saveMix(mixStringTxt, userInfo.id);
              case 58:
                saveMix = _context15.sent;
                if (!saveMix.success) {
                  _context15.next = 67;
                  break;
                }
                _context15.next = 62;
                return this.bot.sendChatAction(this.message.message.chat.id, 'upload_document');
              case 62:
                _context15.next = 64;
                return this.bot.sendDocument(this.message.message.chat.id, "".concat(__dirname, "/../class/card/mix/").concat(userInfo.id, ".txt"), {
                  caption: "Mix de ".concat(mixValue, " cart\xF5es")
                });
              case 64:
                require('fs').unlink("".concat(__dirname, "/../class/card/mix/").concat(userInfo.id, ".txt"), function (err) {
                  return console.log(err);
                });
                _context15.next = 68;
                break;
              case 67:
                return _context15.abrupt("return", this.bot.answerCallbackQuery(callbackid, {
                  text: 'Ocorreu um erro ao realizar o envio de sua mix. Baixe seu histórico para recuperá-la e contate-nos.',
                  alert: true
                }));
              case 68:
                buyMix.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '❤️',
                    callback_data: 'compraFinalizada'
                  }]]
                };
                //let updateUser = await this.Db.user().verificarEdeduzirSaldo(price, mixValue)
                this.bot.editMessageText(buyMix.message, buyMix.options);
                this.bot.answerCallbackQuery(callbackid, 'Obrigado pela compra.');
                notificarCompra(mixInfo.price, mixInfo.quantity);
                _context15.next = 77;
                break;
              case 74:
                buyMix.message = mix.response;
                buyMix.options.reply_markup = {
                  inline_keyboard: [[{
                    text: '🔙 Voltar',
                    callback_data: 'voltarMenuDeMix'
                  }]]
                };
                this.bot.editMessageText(buyMix.message, buyMix.options);
              case 77:
                _context15.next = 80;
                break;
              case 79:
                this.bot.answerCallbackQuery(callbackid, {
                  text: "Saldo insuficiente",
                  show_alert: true
                });
              case 80:
                return _context15.abrupt("return", buyMix);
              case 81:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee15, this, [[32, 47, 50, 53]]);
      }));
      function comprarMix(_x6, _x7) {
        return _comprarMix.apply(this, arguments);
      }
      return comprarMix;
    }() //
  }, {
    key: "compraFinzalizada",
    value: function () {
      var _compraFinzalizada = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee16() {
        var callbackid, messages;
        return _regeneratorRuntime().wrap(function _callee16$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                callbackid = this.message.id;
                messages = ['Obrigado pela compra.', 'Agradecemos a preferência.', 'Ótima escolha!', 'Boa sorte!', 'Obrigado, volte sempre!'];
                this.bot.answerCallbackQuery(callbackid, messages.shuffle()[0], {
                  show_alert: true
                });
              case 3:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee16, this);
      }));
      function compraFinzalizada() {
        return _compraFinzalizada.apply(this, arguments);
      }
      return compraFinzalizada;
    }()
  }, {
    key: "callbackType",
    value: function () {
      var _callbackType = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee18(data) {
        var _this4 = this;
        var isInPurchase, types, _yield$types$data, message, options;
        return _regeneratorRuntime().wrap(function _callee18$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                isInPurchase = /*#__PURE__*/function () {
                  var _ref4 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee17() {
                    var userInfos;
                    return _regeneratorRuntime().wrap(function _callee17$(_context17) {
                      while (1) {
                        switch (_context17.prev = _context17.next) {
                          case 0:
                            _context17.next = 2;
                            return _this4.Db.user().informacoes();
                          case 2:
                            userInfos = _context17.sent.response;
                            if (!userInfos.in_purchase) {
                              _context17.next = 7;
                              break;
                            }
                            _context17.next = 6;
                            return _this4.bot.answerCallbackQuery(_this4.message.id, {
                              show_alert: true,
                              text: 'Caro cliente, você so pode comprar unitária novamente após sair a cc solicitada anteriormente. ⚠️Aguarde...'
                            });
                          case 6:
                            return _context17.abrupt("return", false);
                          case 7:
                            return _context17.abrupt("return", true);
                          case 8:
                          case "end":
                            return _context17.stop();
                        }
                      }
                    }, _callee17);
                  }));
                  return function isInPurchase() {
                    return _ref4.apply(this, arguments);
                  };
                }();
                types = {
                  comprar: function comprar() {
                    return _this4.comprar();
                  },
                  informacoes: function informacoes() {
                    return _this4.informacoes();
                  },
                  compras: function compras() {
                    return _this4.compras();
                  },
                  niveis: function niveis() {
                    return _this4.niveis();
                  },
                  adicionarSaldo: function adicionarSaldo() {
                    return _this4.adicionarSaldo();
                  },
                  deletarConta: function deletarConta() {
                    return _this4.encerramentoDeConta();
                  },
                  encerrarConta: function encerrarConta() {
                    return _this4.encerrarConta();
                  },
                  baixarHistorico: function baixarHistorico() {
                    return _this4.baixarHistorico();
                  },
                  mixDeCartoes: function mixDeCartoes() {
                    return _this4.listarMix();
                  },
                  //voltar

                  voltarMenuInicial: function voltarMenuInicial() {
                    return _this4.start();
                  },
                  voltarMenuInformacoes: function voltarMenuInformacoes() {
                    return _this4.informacoes();
                  },
                  voltarMenuDeCompra: function voltarMenuDeCompra() {
                    return _this4.comprar();
                  },
                  voltarMenuNiveis: function voltarMenuNiveis() {
                    return _this4.niveis();
                  },
                  voltarMenuDeMix: function voltarMenuDeMix() {
                    return _this4.listarMix();
                  }
                };
                _context18.t0 = data.includes('level');
                if (!_context18.t0) {
                  _context18.next = 7;
                  break;
                }
                _context18.next = 6;
                return isInPurchase();
              case 6:
                _context18.t0 = _context18.sent;
              case 7:
                if (!_context18.t0) {
                  _context18.next = 9;
                  break;
                }
                this.enviarCartaoRandomicoOuPorNivel(data.split('_')[1]);
              case 9:
                _context18.t1 = data.includes('cartaoAleatorio');
                if (!_context18.t1) {
                  _context18.next = 14;
                  break;
                }
                _context18.next = 13;
                return isInPurchase();
              case 13:
                _context18.t1 = _context18.sent;
              case 14:
                if (!_context18.t1) {
                  _context18.next = 16;
                  break;
                }
                this.enviarCartaoRandomicoOuPorNivel(null, true);
              case 16:
                _context18.t2 = data.includes('comprarCartão');
                if (!_context18.t2) {
                  _context18.next = 21;
                  break;
                }
                _context18.next = 20;
                return isInPurchase();
              case 20:
                _context18.t2 = _context18.sent;
              case 21:
                if (!_context18.t2) {
                  _context18.next = 23;
                  break;
                }
                this.comprarCartao(data.split('_')[1]);
              case 23:
                if (data.includes('trocarCartao')) this.trocarCartao(data);
                if (data.includes('mixDeCartoes')) this.listarMix();
                if (data.includes('selecionarMix')) this.selecionarMix(true, data.split('_')[1]);
                if (data.includes('comprarMix')) this.comprarMix(true, data.split('_')[1]);
                if (data.includes('compraFinalizada')) this.compraFinzalizada();
                if (types[data]) {
                  _context18.next = 30;
                  break;
                }
                return _context18.abrupt("return");
              case 30:
                _context18.next = 32;
                return types[data]();
              case 32:
                _yield$types$data = _context18.sent;
                message = _yield$types$data.message;
                options = _yield$types$data.options;
                this.bot.editMessageText(message, options)["catch"](function (err) {
                  return err;
                });
              case 36:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee18, this);
      }));
      function callbackType(_x10) {
        return _callbackType.apply(this, arguments);
      }
      return callbackType;
    }()
  }]);
  return Callback;
}();
module.exports = Callback;