"use strict";

var _require = require("".concat(__dirname, "/../../utils/settings")),
  pixSettings = _require.pixSettings;
if (pixSettings().autoDisable && !pixSettings().disablePix) {
  pixSettings('disablePix', true);
} else if (pixSettings().autoDisable && pixSettings().disablePix) {
  pixSettings('disablePix', false);
}
process.exit(1);

//MAILTO=""
//30 2,12 * * 2,0 /bin/sh disablePix.sh